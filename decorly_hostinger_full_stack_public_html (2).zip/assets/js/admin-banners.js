/* DECORLY External Script: admin-banners.js */
location.replace('dashboard#banners')

document.addEventListener('click', function(e) {
  var pr = e.target.closest('[data-decorly-print]');
  if (pr) { e.preventDefault(); window.print(); }
});
