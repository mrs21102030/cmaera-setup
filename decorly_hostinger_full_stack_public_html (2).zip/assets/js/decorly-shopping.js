/* DECORLY MySQL Backend Bridge & Storefront UI Suite (Zero Dummy/Fallback Data) */
(function(){
  'use strict';

  const apiBase = location.pathname.includes('/admin/') ? '../api/' : 'api/';

  function getBoot() {
    if (!window.DECORLY_SERVER_BOOT || typeof window.DECORLY_SERVER_BOOT !== 'object') {
      window.DECORLY_SERVER_BOOT = {
        ok: false,
        products: [],
        categories: [],
        orders: [],
        customers: [],
        coupons: [],
        reviews: [],
        enquiries: [],
        blog_posts: [],
        settings: {},
        banner: null,
        user: null,
        admin: null
      };
    }
    return window.DECORLY_SERVER_BOOT;
  }

  function getStoreProducts() {
    const b = getBoot();
    return Array.isArray(b.products) ? b.products.filter(p => p.status !== 'Draft') : [];
  }

  function getStoreCategories() {
    const b = getBoot();
    return Array.isArray(b.categories) ? b.categories.filter(c => c.status !== 'Hidden') : [];
  }

  function readJSON(k, def=[]) {
    try { const a = JSON.parse(localStorage.getItem(k) || 'null'); return a ?? def; } catch { return def; }
  }
  function writeJSON(k, v) {
    try { localStorage.setItem(k, JSON.stringify(v)); return true; } catch { return false; }
  }

  window.DecorlyAPI = {
    async request(endpoint, method='GET', payload=null) {
      try {
        const opts = { method, credentials: 'same-origin', headers: { 'Accept': 'application/json' } };
        if (payload && method !== 'GET') {
          opts.headers['Content-Type'] = 'application/json';
          opts.body = JSON.stringify(payload);
        }
        const res = await fetch(apiBase + endpoint, opts);
        const data = await res.json().catch(() => null);
        return data;
      } catch (e) {
        return null;
      }
    },
    async bootstrap() {
      const data = await this.request('index.php?action=bootstrap');
      if (data && data.ok) {
        window.DECORLY_SERVER_BOOT = data;
        if (data.user) {
          writeJSON('decorly_current_user', data.user);
        } else {
          localStorage.removeItem('decorly_current_user');
        }
        syncHeaderCategoriesMenu();
        updateAccountHeaderButton();
        applyStoreFooterSettings();
        document.dispatchEvent(new CustomEvent('decorly:catalog-synced', { detail: data }));
      }
      return data;
    }
  };

  window.DecorlyShop = {
    products: () => getStoreProducts(),
    categories: () => getStoreCategories(),
    price: (slug) => {
      const p = getStoreProducts().find(x => x.slug === slug || String(x.id) === String(slug));
      if (!p) return 0;
      return Number(p.salePrice && p.salePrice < p.price ? p.salePrice : p.price) || 0;
    },
    product: (slug) => {
      return getStoreProducts().find(x => x.slug === slug || String(x.id) === String(slug)) || null;
    },
    money: n => 'Rs ' + Math.round(Number(n || 0)).toLocaleString('en-PK'),
    read: k => { const a = readJSON(k, []); return Array.isArray(a) ? a : []; },
    addToCart: item => {
      const cart = window.DecorlyShop.read('decorly_cart');
      const refProd = window.DecorlyShop.product(item.slug || item.id) || {};
      const id = item.id || item.slug || refProd.slug || '';
      const slug = item.slug || refProd.slug || String(id);
      const finish = item.finish || (refProd.finish ? String(refProd.finish).split(',')[0].trim() : 'Signature Finish');
      const unitPrice = Number(item.price) || window.DecorlyShop.price(slug) || Number(refProd.price) || 0;
      const existing = cart.find(x => String(x.id || x.slug) === String(id) && (x.finish || 'Signature Finish') === finish);
      if (existing) {
        existing.qty = Math.min(99, (Number(existing.qty || existing.quantity) || 1) + (Number(item.qty) || 1));
      } else {
        cart.push({
          id,
          slug,
          name: item.name || refProd.name || 'DECORLY Furniture',
          image: item.image || refProd.image || '',
          price: unitPrice,
          finish,
          qty: Math.max(1, Number(item.qty) || 1),
          url: 'product?slug=' + encodeURIComponent(slug)
        });
      }
      writeJSON('decorly_cart', cart);
      window.DecorlyShop.notify();
      document.dispatchEvent(new Event('decorly:updated'));
      showStoreToast(item.name || refProd.name || 'Furniture piece');
    },
    notify: () => {
      const cart = window.DecorlyShop.read('decorly_cart');
      const wish = window.DecorlyShop.read('decorly_wishlist');
      const totalQty = cart.reduce((n, x) => n + Math.max(1, Number(x.qty || x.quantity) || 1), 0);
      document.querySelectorAll('#cartCount,#legacy_cartCount,[data-cart-count]').forEach(e => { e.textContent = totalQty; });
      document.querySelectorAll('[data-wishlist-count]').forEach(e => { e.textContent = wish.length; e.hidden = !wish.length; });
      updateAccountHeaderButton();
    }
  };

  function showStoreToast(prodName) {
    let t = document.getElementById('decorly-store-toast');
    if (!t) {
      t = document.createElement('div');
      t.id = 'decorly-store-toast';
      document.body.appendChild(t);
    }
    t.innerHTML = `<div class="dst-row">
      <span class="dst-check">✓</span>
      <div class="dst-copy">
        <strong>${prodName}</strong>
        <span>Added to your DECORLY Shopping Bag</span>
      </div>
      <a href="cart" class="dst-btn">View Bag →</a>
    </div>`;
    t.classList.add('show');
    clearTimeout(window._storeToastTimer);
    window._storeToastTimer = setTimeout(() => t.classList.remove('show'), 3400);
  }

  // Update Header Sign In / My Account Button directly from PHP Session User
  function updateAccountHeaderButton() {
    const boot = getBoot();
    const currUser = boot.user || null;
    document.querySelectorAll('#headerSignInBtn, .decorly-header-signin-btn').forEach(btn => {
      if (currUser && (currUser.name || currUser.email)) {
        btn.setAttribute('href', 'my-account');
        btn.setAttribute('title', 'Signed in as ' + (currUser.name || currUser.email));
        btn.textContent = 'My Account';
        btn.classList.add('is-signed-in');
      } else {
        btn.setAttribute('href', 'login');
        btn.setAttribute('title', 'Sign In to your DECORLY Buyer Account');
        btn.textContent = 'Sign In';
        btn.classList.remove('is-signed-in');
      }
    });
  }

  // Dynamically sync header category navigation menus from MySQL categories
  function syncHeaderCategoriesMenu() {
    const cats = getStoreCategories();
    if (!cats.length) return;
    const groups = {
      Tables: cats.filter(c => (c.group || 'Tables').toLowerCase() === 'tables'),
      Racks: cats.filter(c => (c.group || '').toLowerCase() === 'racks'),
      Trolleys: cats.filter(c => (c.group || '').toLowerCase() === 'trolleys')
    };
    document.querySelectorAll('.decorly-cat-menu').forEach(menu => {
      let html = '';
      [['Tables', 'tables'], ['Racks', 'racks'], ['Trolleys', 'trolleys']].forEach(([label, slugGroup]) => {
        const list = groups[label] || [];
        if (!list.length) return;
        html += `<div class="decorly-cat-group">
          <a class="decorly-cat-parent" href="categories?group=${slugGroup}">${label} <span>›</span></a>
          <div class="decorly-cat-sub">
            ${list.map(c => `<a href="category?slug=${encodeURIComponent(c.slug)}">${c.name}</a>`).join('')}
          </div>
        </div>`;
      });
      html += `<a class="decorly-all-cat" href="categories">Explore All Categories ↗</a>`;
      menu.innerHTML = html;
    });
  }

  // Apply store contact settings from MySQL store_settings to footer
  function applyStoreFooterSettings() {
    const boot = getBoot();
    const gen = boot.settings && boot.settings.general ? boot.settings.general : null;
    if (!gen) return;
    document.querySelectorAll('.lf-contact a[href^="mailto:"]').forEach(a => {
      if (gen.supportEmail) {
        a.href = 'mailto:' + gen.supportEmail;
        a.textContent = gen.supportEmail;
      }
    });
    document.querySelectorAll('.lf-contact a[href^="tel:"]').forEach(a => {
      if (gen.storePhone) {
        a.href = 'tel:' + gen.storePhone.replace(/\s+/g, '');
        a.textContent = gen.storePhone;
      }
    });
  }

  function enhanceProductCards() {
    document.querySelectorAll('article.product, article.product-card, article.card, article.pc').forEach(card => {
      if (card.querySelector('.decorly-card-add-btn')) return;
      const link = card.querySelector('a[href*="product"]');
      if (!link) return;
      const href = link.getAttribute('href') || '';
      const slugMatch = href.split('slug=')[1];
      const itemSlug = slugMatch ? decodeURIComponent(slugMatch.split('&')[0]) : '';
      if (!itemSlug) return;
      const dbProd = window.DecorlyShop.product(itemSlug);
      const titleEl = card.querySelector('h3');
      const name = (dbProd && dbProd.name) || (titleEl ? titleEl.textContent.trim() : 'DECORLY Furniture');
      const imgEl = card.querySelector('img');
      const image = (dbProd && dbProd.image) || (imgEl ? imgEl.src : '');
      const price = window.DecorlyShop.price(itemSlug);

      const bottom = card.querySelector('.product-bottom, .product-foot, .card-foot, .info, .pf');
      if (bottom) {
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'decorly-card-add-btn';
        btn.innerHTML = '＋ Add to Bag';
        btn.addEventListener('click', e => {
          e.preventDefault();
          e.stopPropagation();
          window.DecorlyShop.addToCart({id: itemSlug, slug: itemSlug, name, image, price, qty: 1, url: 'product?slug=' + encodeURIComponent(itemSlug)});
          btn.innerHTML = '✓ Added';
          setTimeout(() => { btn.innerHTML = '＋ Add to Bag'; }, 1400);
        });
        bottom.appendChild(btn);
      }
      if (!card.querySelector('.ar-card-button')) {
        const infoBox = card.querySelector('.pi, .info, .product-info, .wish-detail') || card;
        const arBtn = document.createElement('button');
        arBtn.type = 'button';
        arBtn.className = 'ar-card-button';
        arBtn.dataset.ar = itemSlug;
        arBtn.setAttribute('aria-label', 'Open camera with ' + name);
        arBtn.innerHTML = '<span aria-hidden="true">⬡</span> Open Camera <span aria-hidden="true">↗</span>';
        infoBox.appendChild(arBtn);
      }
    });
  }

  // =========================================================================
  // DECORLY CAMERA PRODUCT VIEWER & LIVE ROOM COMPOSITE PHOTO CREATOR
  // =========================================================================
  function initDecorlyCameraViewer() {
    if (location.pathname.includes('/admin/') || document.getElementById('cameraFallback')) return;

    const wrapper = document.createElement('div');
    wrapper.innerHTML = `
<div class="ar-overlay" id="arOverlay" role="dialog" aria-modal="true" aria-labelledby="arTitle" aria-hidden="true">
  <div class="ar-panel">
    <div class="ar-head">
      <div>
        <div class="ar-eyebrow">DECORLY / CAMERA PREVIEW</div>
        <h2 id="arTitle">See it in your space.</h2>
      </div>
      <button class="ar-exit" id="arClose" type="button" aria-label="Close preview">×</button>
    </div>
    <div class="ar-stage">
      <img id="arViewer" alt="Furniture cutout preview">
      <span class="ar-stage-label">TRANSPARENT PRODUCT PREVIEW</span>
    </div>
    <div class="ar-bottom">
      <div class="ar-description">
        <strong id="arProduct">Furniture preview</strong>
        <p>Front-facing transparent product image. Open the camera preview to place it inside your room, then drag and resize it for a quick visual demo.</p>
        <p id="arStatus" role="status">Works on regular phones with browser camera access and HTTPS.</p>
      </div>
      <div style="display:flex;flex-direction:column;gap:8px;min-width:min(260px,100%)">
        <button class="ar-launch" id="camLaunch" type="button" style="background:#a97e4f">📷 Open Camera Preview</button>
      </div>
    </div>
  </div>
</div>
<div class="camera-fallback" id="cameraFallback" role="dialog" aria-modal="true" aria-label="Camera furniture preview" aria-hidden="true">
  <div class="cam-top">
    <div>
      <b id="camProduct">Furniture in your room</b>
      <small>DECORLY / CAMERA PREVIEW · IMAGE OVERLAY</small>
    </div>
    <button type="button" class="cam-close" id="camClose">✕ Close</button>
  </div>
  <div class="cam-scene" id="camScene">
    <video class="cam-video" id="camVideo" autoplay muted playsinline></video>
    <div class="cam-tint"></div>
    <div class="cam-placement" id="camPlacement">
      <img id="camPhoto" crossorigin="anonymous" alt="Furniture cutout">
    </div>
    <div class="cam-guides">Drag product to position · Use size slider below</div>
  </div>
  <div class="cam-bottom">
    <div class="cam-control-row">
      <label class="cam-size">Size <input id="camScale" type="range" min="45" max="190" value="100" aria-label="Furniture size"></label>
    </div>
    <div class="cam-control-row">
      <button type="button" id="camReset">Reset</button>
      <button type="button" id="camSwitch">Switch camera</button>
      <button type="button" class="cam-gold" id="camCapture">Save photo</button>
    </div>
    <div class="cam-status" id="camStatus" role="status">Camera preview only — drag to move and use the size slider for adjustment.</div>
  </div>
</div>`;
    while (wrapper.firstElementChild) {
      document.body.appendChild(wrapper.firstElementChild);
    }

    const arOverlay = document.getElementById('arOverlay');
    const arViewer = document.getElementById('arViewer');
    const arClose = document.getElementById('arClose');
    const camDialog = document.getElementById('cameraFallback');
    const camVideo = document.getElementById('camVideo');
    const camPlacement = document.getElementById('camPlacement');
    const camPhoto = document.getElementById('camPhoto');
    const camStatus = document.getElementById('camStatus');

    let arPreviousFocus = null;
    let currentImageProductId = null;
    let camStream = null, camFacing = 'environment', camId = null, camScale = 1, camX = 0, camY = 0, camPointer = null;

    function findProduct(key) {
      const k = String(key || '').trim();
      if (!k) return null;
      const prods = getStoreProducts();
      return prods.find(p =>
        String(p.slug) === k ||
        String(p.id) === k ||
        String(p.code) === k ||
        String(p.sku) === k
      ) || null;
    }

    function cutoutSrc(prodOrKey) {
      const p = typeof prodOrKey === 'object' && prodOrKey ? prodOrKey : findProduct(prodOrKey);
      if (p && p.image) return p.image;
      const num = parseInt(String(prodOrKey).replace(/\D+/g, ''), 10);
      if (num >= 1 && num <= 36) return `assets/images/products/prod-${100 + num}.png`;
      if (num >= 101 && num <= 136) return `assets/images/products/prod-${num}.png`;
      return 'assets/images/products/prod-101.png';
    }

    function camPosition() {
      camPlacement.style.left = `calc(50% + ${camX}px)`;
      camPlacement.style.top = `calc(58% + ${camY}px)`;
      camPlacement.style.transform = `translate(-50%,-50%) scale(${camScale})`;
    }

    function camResetPosition() {
      camScale = 1;
      camX = 0;
      camY = 0;
      document.getElementById('camScale').value = '100';
      camPosition();
    }

    async function requestCamera() {
      if (!navigator.mediaDevices?.getUserMedia) {
        throw Error('Browser camera access needs HTTPS (or localhost), and a supported browser.');
      }
      if (camStream) {
        camStream.getTracks().forEach(t => t.stop());
        camStream = null;
      }
      camStream = await navigator.mediaDevices.getUserMedia({
        audio: false,
        video: { facingMode: { ideal: camFacing }, width: { ideal: 1280 }, height: { ideal: 720 } }
      });
      camVideo.srcObject = camStream;
      await camVideo.play();
      camStatus.textContent = 'Camera ready. Drag the product to place it, then resize it from the slider below.';
    }

    async function openCameraFallback() {
      camId = currentImageProductId || camId;
      const product = findProduct(camId) || { name: 'DECORLY Furniture', image: cutoutSrc(camId) };
      document.getElementById('camProduct').textContent = product.name;
      camPhoto.src = cutoutSrc(product);
      camPhoto.alt = product.name + ' transparent furniture overlay';
      camResetPosition();
      camDialog.classList.add('open');
      camDialog.setAttribute('aria-hidden', 'false');
      document.body.style.overflow = 'hidden';
      camStatus.textContent = 'Opening your camera…';
      try {
        await requestCamera();
      } catch (e) {
        camStatus.textContent = 'Live camera unavailable (' + e.message + ') — you can still drag, resize, and click "Save photo" to create your preview picture!';
      }
    }

    function stopCameraFallback() {
      if (camStream) {
        camStream.getTracks().forEach(t => t.stop());
        camStream = null;
      }
      camVideo.srcObject = null;
      camDialog.classList.remove('open');
      camDialog.setAttribute('aria-hidden', 'true');
      camPhoto.removeAttribute('src');
      document.body.style.overflow = '';
    }

    window.openAR = function(idOrSlug) {
      const product = findProduct(idOrSlug);
      currentImageProductId = product ? product.slug : String(idOrSlug || 'prod-101');
      camId = currentImageProductId;
      openCameraFallback();
    };

    function closeAR() {
      if (camDialog.classList.contains('open')) stopCameraFallback();
      arOverlay.classList.remove('open');
      arOverlay.setAttribute('aria-hidden', 'true');
      arViewer.removeAttribute('src');
      document.body.style.overflow = '';
      arPreviousFocus?.focus?.();
    }

    arClose.addEventListener('click', closeAR);
    arOverlay.addEventListener('click', e => { if (e.target === arOverlay) closeAR(); });
    document.getElementById('camLaunch').addEventListener('click', openCameraFallback);
    document.getElementById('camClose').addEventListener('click', stopCameraFallback);
    document.getElementById('camScale').addEventListener('input', e => {
      camScale = Number(e.target.value) / 100;
      camPosition();
    });
    document.getElementById('camReset').addEventListener('click', camResetPosition);
    document.getElementById('camSwitch').addEventListener('click', async () => {
      camFacing = camFacing === 'environment' ? 'user' : 'environment';
      try {
        await requestCamera();
      } catch (e) {
        camStatus.textContent = 'Could not switch camera: ' + e.message;
      }
    });

    camPlacement.addEventListener('pointerdown', e => {
      camPointer = { id: e.pointerId, x: e.clientX, y: e.clientY, px: camX, py: camY };
      camPlacement.setPointerCapture(e.pointerId);
      e.preventDefault();
    });
    camPlacement.addEventListener('pointermove', e => {
      if (camPointer?.id !== e.pointerId) return;
      camX = camPointer.px + e.clientX - camPointer.x;
      camY = camPointer.py + e.clientY - camPointer.y;
      camPosition();
    });
    camPlacement.addEventListener('pointerup', () => camPointer = null);
    camPlacement.addEventListener('pointercancel', () => camPointer = null);
    camPhoto.addEventListener('error', () => {
      camStatus.textContent = 'Product cutout image could not load.';
    });

    // Capture composite PNG (works with live camera video OR studio room backdrop fallback)
    document.getElementById('camCapture').addEventListener('click', async () => {
      try {
        if (!camPhoto.complete || !camPhoto.naturalWidth) throw Error('Product image not ready');
        const c = document.createElement('canvas');
        const hasVideo = camVideo.videoWidth > 0 && camVideo.videoHeight > 0;
        c.width = hasVideo ? camVideo.videoWidth : 1280;
        c.height = hasVideo ? camVideo.videoHeight : 720;
        const ctx = c.getContext('2d');
        const sceneEl = document.getElementById('camScene');
        const vw = (hasVideo ? camVideo : sceneEl).getBoundingClientRect();
        const cw = c.width / Math.max(1, vw.width);
        const ch = c.height / Math.max(1, vw.height);

        if (hasVideo) {
          const sw = camVideo.videoWidth, sh = camVideo.videoHeight;
          const ratio = Math.max(vw.width / sw, vw.height / sh);
          const cropW = vw.width / ratio, cropH = vw.height / ratio;
          ctx.drawImage(camVideo, (sw - cropW) / 2, (sh - cropH) / 2, cropW, cropH, 0, 0, c.width, c.height);
        } else {
          const grad = ctx.createLinearGradient(0, 0, 0, c.height);
          grad.addColorStop(0, '#2a241f');
          grad.addColorStop(0.68, '#3b322b');
          grad.addColorStop(0.69, '#231d18');
          grad.addColorStop(1, '#16120f');
          ctx.fillStyle = grad;
          ctx.fillRect(0, 0, c.width, c.height);
        }

        const rp = camPlacement.getBoundingClientRect();
        const rs = vw;
        const imageRatio = camPhoto.naturalWidth / camPhoto.naturalHeight;
        const boxRatio = rp.width / rp.height;
        const displayW = boxRatio > imageRatio ? rp.height * imageRatio : rp.width;
        const displayH = boxRatio > imageRatio ? rp.height : rp.width / imageRatio;
        const drawX = (rp.left - rs.left + (rp.width - displayW) / 2) * cw;
        const drawY = (rp.top - rs.top + (rp.height - displayH) / 2) * ch;
        ctx.drawImage(camPhoto, drawX, drawY, displayW * cw, displayH * ch);

        const a = document.createElement('a');
        a.download = 'DECORLY-room-preview.png';
        a.href = c.toDataURL('image/png');
        a.click();
        camStatus.textContent = 'Room preview saved.';
      } catch (e) {
        camStatus.textContent = e.message;
      }
    });

    document.addEventListener('visibilitychange', () => {
      if (document.hidden && camDialog.classList.contains('open')) stopCameraFallback();
    });
    document.addEventListener('keydown', e => {
      if (e.key === 'Escape') {
        if (camDialog.classList.contains('open')) stopCameraFallback();
        if (arOverlay.classList.contains('open')) closeAR();
      }
    });

    // Global click delegation for all [data-ar] buttons
    document.addEventListener('click', e => {
      const arBtn = e.target.closest('[data-ar]');
      if (arBtn) {
        e.preventDefault();
        e.stopPropagation();
        const targetSlug = arBtn.dataset.ar || (window.DecorlyShop.products()[0]?.slug) || 'prod-101';
        window.openAR(targetSlug);
      }
    });
  }


  document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('.decorly-site-header a[href*="wishlist"],header a[href*="wishlist"]').forEach(a => {
      if (a.querySelector('[data-wishlist-count]')) return;
      a.classList.add('decorly-wishlist-link');
      a.insertAdjacentHTML('beforeend', '<span data-wishlist-count class="decorly-wish-badge" hidden>0</span>');
    });

    if (!document.querySelector('.decorly-top-fab') && !document.getElementById('bt') && !document.getElementById('backTop') && !location.pathname.includes('/admin/')) {
      const fab = document.createElement('button');
      fab.className = 'decorly-top-fab';
      fab.setAttribute('aria-label', 'Back to top');
      fab.innerHTML = '↑';
      fab.addEventListener('click', () => window.scrollTo({top: 0, behavior: 'smooth'}));
      document.body.appendChild(fab);
      window.addEventListener('scroll', () => fab.classList.toggle('show', window.scrollY > 380), {passive: true});
    }

    syncHeaderCategoriesMenu();
    updateAccountHeaderButton();
    applyStoreFooterSettings();
    initDecorlyCameraViewer();
    enhanceProductCards();

    ['productGrid', 'relatedGrid', 'pgd'].forEach(id => {
      const gridTarget = document.getElementById(id);
      if (gridTarget && window.MutationObserver) {
        new MutationObserver(() => enhanceProductCards()).observe(gridTarget, {childList: true});
      }
    });

    window.DecorlyShop.notify();
    window.DecorlyAPI.bootstrap();
  });

  addEventListener('storage', () => window.DecorlyShop.notify());
  document.addEventListener('decorly:updated', () => window.DecorlyShop.notify());
})();
