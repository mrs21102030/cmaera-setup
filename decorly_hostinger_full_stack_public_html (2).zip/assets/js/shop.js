(function(){
  var pre = document.getElementById('decorly-preloader');
  var bar = document.getElementById('decorlyLoaderBar');
  var pct = document.getElementById('decorlyLoaderPct');
  if(!pre) return;
  var p = 12, done = false;
  var iv = setInterval(function(){
    if(done) return;
    p += Math.max(4, Math.round((92 - p) * 0.28));
    if(p > 92) p = 92;
    if(bar) bar.style.width = p + '%';
    if(pct) pct.textContent = p + '%';
  }, 45);
  function finish(){
    if(done) return;
    done = true;
    clearInterval(iv);
    if(bar) bar.style.width = '100%';
    if(pct) pct.textContent = '100%';
    setTimeout(function(){
      pre.classList.add('is-loaded');
    }, 140);
  }
  if(document.readyState === 'complete' || document.readyState === 'interactive'){
    setTimeout(finish, 260);
  } else {
    window.addEventListener('DOMContentLoaded', function(){ setTimeout(finish, 280); });
    window.addEventListener('load', finish);
  }
  setTimeout(finish, 950);
})();

(function(){
  'use strict';
  const PAGE_MODE = 'shop'; // 'shop' | 'category' | 'search'
  const $ = id => document.getElementById(id);
  const safe = s => String(s ?? '').replace(/[&<>"']/g, x => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[x]));
  const money = p => 'Rs ' + Math.round(Number(p || 0)).toLocaleString('en-PK');

  function getBoot() {
    return window.DECORLY_SERVER_BOOT || { products: [], categories: [] };
  }

  let cats = [];
  let categoryName = {};
  let products = [];
  const qp = new URLSearchParams(location.search);
  const categorySlug = qp.get('slug') || 'coffee-tables';

  let state = {
    selected: PAGE_MODE === 'category' ? new Set([categorySlug]) : new Set(),
    q: qp.get('q') || qp.get('search') || '',
    max: 50000,
    featured: false,
    sort: 'featured',
    page: 1,
    size: 9,
    view: 'grid'
  };

  function storageGet(key) { try { return JSON.parse(localStorage.getItem(key) || '[]'); } catch { return []; } }
  function storageSet(key, v) { try { localStorage.setItem(key, JSON.stringify(v)); } catch {} }
  let wishlist = storageGet('decorly_wishlist');
  if (!Array.isArray(wishlist)) wishlist = [];

  function syncDataFromBoot() {
    const boot = getBoot();
    const rawCats = Array.isArray(boot.categories) ? boot.categories.filter(c => c.status !== 'Hidden') : [];
    const rawProds = Array.isArray(boot.products) ? boot.products.filter(p => p.status !== 'Draft') : [];

    cats = rawCats.map(c => [c.slug, c.name, c.image || '', c.desc || '', c.group || 'Tables']);
    categoryName = Object.fromEntries(cats.map(c => [c[0], c[1]]));

    const mappedProds = rawProds.map(ap => {
      const effPrice = Number(ap.salePrice && ap.salePrice < ap.price ? ap.salePrice : ap.price) || 0;
      return {
        id: ap.id,
        slug: ap.slug,
        name: ap.name,
        cat: ap.catSlug,
        categoryLabel: ap.category || categoryName[ap.catSlug] || 'Furniture',
        image: ap.image || '',
        badge: ap.badge || (ap.featured ? 'SIGNATURE EDIT' : 'DECORLY EDIT'),
        price: effPrice,
        origPrice: Number(ap.price) || effPrice,
        stock: Number(ap.stock ?? 10),
        featured: ap.badge === 'SIGNATURE EDIT' || ap.badge === 'BEST SELLER' || !!ap.featured,
        url: 'product?slug=' + encodeURIComponent(ap.slug)
      };
    });

    products = PAGE_MODE === 'category'
      ? mappedProds.filter(p => p.cat === categorySlug)
      : mappedProds;
  }

  function setupCategoryHeader() {
    if (PAGE_MODE !== 'category') return;
    const catEntry = cats.find(c => c[0] === categorySlug) || [categorySlug, categorySlug.replace(/-/g, ' '), '', '', 'Tables'];
    const titleStr = catEntry[1] || 'Collection';
    const words = titleStr.split(' ');
    const w1 = words[0] || 'Collection';
    const w2 = words.slice(1).join(' ') ? words.slice(1).join(' ') + '.' : '';
    const desc = catEntry[3] || `Explore ${titleStr} at DECORLY, handcrafted for modern Pakistani homes.`;
    const img = catEntry[2] || (products[0] && products[0].image) || '';

    document.title = `${titleStr} | DECORLY Furniture`;
    if ($('categoryTitle')) $('categoryTitle').innerHTML = `${safe(w1)} <em>${safe(w2)}</em>`;
    if ($('categoryIntro')) $('categoryIntro').textContent = desc;
    if ($('crumbName')) $('crumbName').textContent = titleStr;
    const idx = cats.findIndex(x => x[0] === categorySlug);
    if ($('heroIndex')) $('heroIndex').textContent = String(idx >= 0 ? idx + 1 : 1).padStart(2, '0') + ' / ' + String(Math.max(1, cats.length)).padStart(2, '0');
    if ($('heroBackground') && img) {
      $('heroBackground').style.backgroundImage = `linear-gradient(90deg,rgba(7,21,47,.55),rgba(7,21,47,.18)),url('${img}')`;
    }
    if ($('categoryShort')) $('categoryShort').textContent = titleStr.toLowerCase() + '.';
    if ($('curationText')) $('curationText').textContent = desc;
    if ($('curationThumbs') && img) {
      $('curationThumbs').innerHTML = `<a href="#browse"><img src="${safe(img)}" alt="${safe(titleStr)}" loading="lazy"></a>`;
    }
    if ($('editorialImg') && img) $('editorialImg').src = img;
    if ($('relatedCategories')) {
      $('relatedCategories').innerHTML = cats.filter(c => c[0] !== categorySlug).slice(0, 3).map(c =>
        `<a class="related-card" href="category?slug=${encodeURIComponent(c[0])}"><img loading="lazy" alt="${safe(c[1])}" src="${safe(c[2])}"><strong>${safe(c[1])} <span>↗</span></strong></a>`
      ).join('');
    }
  }

  function updateRail() {
    const rail = $('categoryRail');
    if (!rail) return;
    rail.innerHTML = cats.slice(0, 6).map(c =>
      `<a class="rail-item" href="category?slug=${encodeURIComponent(c[0])}" title="Explore ${safe(c[1])}"><img loading="lazy" src="${safe(c[2])}" alt="${safe(c[1])}"><span>${safe(c[1])} ↗</span></a>`
    ).join('');
  }

  function renderFilters() {
    const box = $('filterCategories');
    if (!box) return;
    if (PAGE_MODE === 'category') {
      box.innerHTML = `<span>✳</span> ${safe(categoryName[categorySlug] || categorySlug)}`;
      return;
    }
    box.innerHTML = cats.map(c =>
      `<label class="checkrow"><input type="checkbox" value="${safe(c[0])}" ${state.selected.has(c[0]) ? 'checked' : ''}><span>${safe(c[1])}</span></label>`
    ).join('');
    box.querySelectorAll('input').forEach(inp => inp.addEventListener('change', () => {
      inp.checked ? state.selected.add(inp.value) : state.selected.delete(inp.value);
      state.page = 1;
      render();
    }));
  }

  function filterItems() {
    let out = products.filter(p =>
      (!state.selected.size || state.selected.has(p.cat)) &&
      (!state.featured || p.featured) &&
      (!state.q || (`${p.name} ${p.categoryLabel}`).toLowerCase().includes(state.q.toLowerCase())) &&
      (Number(p.price || 0) <= state.max)
    );
    if (state.sort === 'az') out.sort((a, b) => a.name.localeCompare(b.name));
    if (state.sort === 'za') out.sort((a, b) => b.name.localeCompare(a.name));
    if (state.sort === 'priceup') out.sort((a, b) => a.price - b.price);
    if (state.sort === 'pricedown') out.sort((a, b) => b.price - a.price);
    return out;
  }

  function render() {
    const arr = filterItems();
    const pageMax = Math.max(1, Math.ceil(arr.length / state.size));
    state.page = Math.min(state.page, pageMax);

    if ($('results')) {
      $('results').textContent = `Showing ${arr.length ? ((state.page - 1) * state.size + 1) : 0}–${Math.min(arr.length, state.page * state.size)} of ${arr.length} designs`;
    }
    if ($('totalTag')) $('totalTag').textContent = `${products.length} DESIGNS IN CATALOG`;
    if ($('searchSummary')) {
      $('searchSummary').innerHTML = state.q
        ? `<span>SEARCH RESULTS FOR</span> <strong>“${safe(state.q)}”</strong> <small>${arr.length} match${arr.length === 1 ? '' : 'es'}</small>`
        : `<span>EXPLORE</span> <strong>All DECORLY designs (${products.length})</strong> <small>Live from MySQL Database</small>`;
    }

    const visible = arr.slice((state.page - 1) * state.size, state.page * state.size);
    const grid = $('productGrid');
    if (grid) {
      grid.className = 'grid' + (state.view === 'list' ? ' list-view' : '');
      grid.innerHTML = visible.length ? visible.map(p => {
        const on = wishlist.some(x => String(typeof x === 'object' ? x.id : x) === String(p.id));
        return `<article class="product">
          <div class="photo">
            <a href="${safe(p.url)}" aria-label="View ${safe(p.name)}"><img loading="lazy" src="${safe(p.image)}" alt="${safe(p.name)}"></a>
            <span class="badge">${safe(p.badge)}</span>
            <button type="button" class="heart ${on ? 'is-on' : ''}" data-id="${safe(p.id)}" aria-label="Toggle wishlist">${on ? '♥' : '♡'}</button>
            <a class="quick" href="${safe(p.url)}">VIEW DETAILS ↗</a>
          </div>
          <div class="info">
            <span class="catlabel">${safe(p.categoryLabel)}</span>
            <h3><a href="${safe(p.url)}">${safe(p.name)}</a></h3>
            <div class="product-bottom">
              <span class="pricing">${money(p.price)}</span>
              <a class="circle" href="${safe(p.url)}" aria-label="View details">↗</a>
            </div>
            <button class="ar-card-button" type="button" data-ar="${safe(p.slug)}" aria-label="Open camera with ${safe(p.name)}"><span aria-hidden="true">⬡</span> Open Camera <span aria-hidden="true">↗</span></button>
          </div>
        </article>`;
      }).join('') : `<div class="empty" style="grid-column:1/-1"><strong>No matching pieces found in database.</strong>Try another search or clear filters.</div>`;

      grid.querySelectorAll('.heart').forEach(b => b.onclick = () => {
        const id = b.dataset.id;
        const item = products.find(p => String(p.id) === id);
        if (!item) return;
        wishlist = wishlist.filter(x => String(typeof x === 'object' ? x.id : x) !== id);
        if (!b.classList.contains('is-on')) {
          wishlist.push({ id: item.id, slug: item.slug, name: item.name, image: item.image, url: item.url, price: item.price });
        }
        storageSet('decorly_wishlist', wishlist);
        document.dispatchEvent(new Event('decorly:updated'));
        render();
      });
    }

    if ($('pagination')) {
      $('pagination').innerHTML = Array.from({ length: pageMax }, (_, i) =>
        `<button class="${i + 1 === state.page ? 'current' : ''}" data-page="${i + 1}">${i + 1}</button>`
      ).join('');
      $('pagination').querySelectorAll('button').forEach(b => b.onclick = () => {
        state.page = +b.dataset.page;
        render();
        $('browse')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
      });
    }
  }

  function init() {
    syncDataFromBoot();
    const catParam = qp.get('category');
    if (catParam && PAGE_MODE !== 'category') {
      catParam.split(',').filter(Boolean).forEach(x => state.selected.add(x));
    }
    setupCategoryHeader();
    updateRail();
    renderFilters();
    if ($('searchInput')) $('searchInput').value = state.q;
    if ($('search') && PAGE_MODE === 'search') $('search').value = state.q;
    render();

    $('searchInput')?.addEventListener('input', e => { state.q = e.target.value.trim(); state.page = 1; render(); });
    $('featuredOnly')?.addEventListener('change', e => { state.featured = e.target.checked; state.page = 1; render(); });
    $('sort')?.addEventListener('change', e => { state.sort = e.target.value; state.page = 1; render(); });
    $('priceRange')?.addEventListener('input', e => {
      state.max = +e.target.value;
      if ($('maxPriceLabel')) $('maxPriceLabel').textContent = money(state.max);
      state.page = 1;
      render();
    });
    $('clearFilters')?.addEventListener('click', () => {
      state.selected = PAGE_MODE === 'category' ? new Set([categorySlug]) : new Set();
      state.q = '';
      state.max = 50000;
      state.featured = false;
      state.sort = 'featured';
      state.page = 1;
      if ($('searchInput')) $('searchInput').value = '';
      if ($('priceRange')) $('priceRange').value = 50000;
      if ($('maxPriceLabel')) $('maxPriceLabel').textContent = 'Rs 50,000';
      if ($('featuredOnly')) $('featuredOnly').checked = false;
      if ($('sort')) $('sort').value = 'featured';
      renderFilters();
      render();
    });
    document.querySelectorAll('[data-view]').forEach(b => b.onclick = () => {
      state.view = b.dataset.view;
      document.querySelectorAll('[data-view]').forEach(v => v.classList.toggle('active', v === b));
      render();
    });
    document.querySelectorAll('[data-term]').forEach(b => b.addEventListener('click', () => {
      state.q = b.dataset.term;
      state.page = 1;
      if ($('searchInput')) $('searchInput').value = state.q;
      render();
    }));
    $('filterToggle')?.addEventListener('click', () => {
      const open = $('filterPanel')?.classList.toggle('open');
      $('filterToggle').setAttribute('aria-expanded', String(!!open));
    });
    $('backTop')?.addEventListener('click', () => scrollTo({ top: 0, behavior: 'smooth' }));

    const hd = document.querySelector('.decorly-site-header'), menu = document.querySelector('.decorly-site-mobile');
    if (hd && menu) {
      const btn = hd.querySelector('#mbtn');
      if (btn) btn.addEventListener('click', () => {
        const open = menu.classList.toggle('o');
        btn.textContent = open ? '×' : '☰';
        btn.setAttribute('aria-expanded', String(open));
      });
    }
    document.addEventListener('submit', event => {
      const form = event.target;
      if (!form || form.id !== 'searchForm') return;
      event.preventDefault();
      const field = form.querySelector('input[type="search"],input[name="q"],#search');
      const q = field ? field.value.trim() : '';
      location.href = 'search' + (q ? '?q=' + encodeURIComponent(q) : '');
    }, true);
  }

  document.addEventListener('decorly:catalog-synced', () => {
    syncDataFromBoot();
    setupCategoryHeader();
    updateRail();
    renderFilters();
    render();
  });

  init();
})();
