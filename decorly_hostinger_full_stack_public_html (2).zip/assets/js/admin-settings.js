/* DECORLY External Script: admin-settings.js */
location.replace('dashboard#settings')

document.addEventListener('click', function(e) {
  var pr = e.target.closest('[data-decorly-print]');
  if (pr) { e.preventDefault(); window.print(); }
});
