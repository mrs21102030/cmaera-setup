(function(){
  var pre = document.getElementById('decorly-preloader');
  var bar = document.getElementById('decorlyLoaderBar');
  var pct = document.getElementById('decorlyLoaderPct');
  if(!pre) return;
  var p = 12, done = false;
  var iv = setInterval(function(){
    if(done) return;
    p += Math.max(4, Math.round((92 - p) * 0.28));
    if(p > 92) p = 92;
    if(bar) bar.style.width = p + '%';
    if(pct) pct.textContent = p + '%';
  }, 45);
  function finish(){
    if(done) return;
    done = true;
    clearInterval(iv);
    if(bar) bar.style.width = '100%';
    if(pct) pct.textContent = '100%';
    setTimeout(function(){
      pre.classList.add('is-loaded');
    }, 140);
  }
  if(document.readyState === 'complete' || document.readyState === 'interactive'){
    setTimeout(finish, 260);
  } else {
    window.addEventListener('DOMContentLoaded', function(){ setTimeout(finish, 280); });
    window.addEventListener('load', finish);
  }
  setTimeout(finish, 950);
})();

(function(){
  'use strict';
  const $ = s => document.querySelector(s);
  const $$ = s => [...document.querySelectorAll(s)];
  const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const money = n => 'Rs ' + Math.round(Number(n || 0)).toLocaleString('en-PK');

  let activeCat = 'all';

  function getBoot() {
    return window.DECORLY_SERVER_BOOT || { products: [], categories: [], banner: null };
  }

  function renderHomepageFromDB() {
    const boot = getBoot();
    const cats = (Array.isArray(boot.categories) ? boot.categories : []).filter(c => c.status !== 'Hidden');
    const prods = (Array.isArray(boot.products) ? boot.products : []).filter(p => p.status !== 'Draft');
    const catMap = Object.fromEntries(cats.map(c => [c.slug, c.name]));

    // Apply Banner from MySQL if published
    if (boot.banner && boot.banner.status === 'Published') {
      const heroTitle = $('.hero-copy h1');
      const heroDesc = $('.hero-copy p');
      const heroEb = $('.hero-copy .eyebrow');
      if (heroEb && boot.banner.eyebrow) heroEb.textContent = boot.banner.eyebrow;
      if (heroDesc && boot.banner.desc) heroDesc.textContent = boot.banner.desc;
    }

    // 1. Main Category Groups (#cg)
    const cg = $('#cg');
    if (cg) {
      const groupDefs = [
        { slug: 'tables', name: 'Tables', match: c => (c.group || 'Tables').toLowerCase() === 'tables' },
        { slug: 'racks', name: 'Racks', match: c => (c.group || '').toLowerCase() === 'racks' },
        { slug: 'trolleys', name: 'Trolleys', match: c => (c.group || '').toLowerCase() === 'trolleys' }
      ];
      cg.innerHTML = groupDefs.map((g, i) => {
        const rep = cats.find(g.match) || cats[i] || {};
        const img = rep.image || '';
        const count = prods.filter(p => {
          const catObj = cats.find(c => c.slug === p.catSlug);
          return catObj ? g.match(catObj) : false;
        }).length;
        return `<a class="cc rv in" href="categories?group=${g.slug}">
          <img alt="${esc(g.name)}" loading="lazy" decoding="async" src="${esc(img)}">
          <small>COLLECTION / 0${i+1} · ${count} DESIGNS</small>
          <div><h3>${esc(g.name)}</h3><i>↗</i></div>
        </a>`;
      }).join('');
    }

    // 2. Category Filter Tabs (#tabs)
    const tabsEl = $('#tabs');
    if (tabsEl) {
      tabsEl.innerHTML = `<button class="tab ${activeCat === 'all' ? 'on' : ''}" data-c="all">All designs (${prods.length})</button>` +
        cats.map(c => `<button class="tab ${activeCat === c.slug ? 'on' : ''}" data-c="${esc(c.slug)}">${esc(c.name)}</button>`).join('');
      tabsEl.querySelectorAll('.tab').forEach(b => {
        b.onclick = () => {
          activeCat = b.dataset.c;
          tabsEl.querySelectorAll('.tab').forEach(t => t.classList.remove('on'));
          b.classList.add('on');
          filterProducts();
        };
      });
    }

    // 3. Product Showcase Grid (#pgd) — 100% from MySQL `products` table
    const pgd = $('#pgd');
    if (pgd) {
      if (!prods.length) {
        pgd.innerHTML = `<div class="empty" style="grid-column:1/-1;text-align:center;padding:48px 20px;background:#fff;border-radius:18px;border:1px solid #e6e2d8">
          <h3 style="margin:0 0 8px;color:#102346">No products currently in database</h3>
          <p style="margin:0;color:#6c737f">Add products from the Admin Dashboard or phpMyAdmin to display them here.</p>
        </div>`;
      } else {
        pgd.innerHTML = prods.map(p => {
          const url = 'product?slug=' + encodeURIComponent(p.slug);
          const effPrice = Number(p.salePrice && p.salePrice < p.price ? p.salePrice : p.price) || 0;
          const catTitle = catMap[p.catSlug] || p.category || 'Furniture';
          return `<article class="pc rv in" data-f="${esc(p.catSlug)}" data-n="${esc((p.name + ' ' + catTitle).toLowerCase())}">
            <a class="pp" href="${esc(url)}">
              <img alt="${esc(p.name)}" loading="lazy" decoding="async" src="${esc(p.image)}">
              <span class="pb2">${esc(p.badge || (p.featured ? 'Signature pick' : 'DECORLY Edit'))}</span>
              <span class="pv">VIEW PRODUCT ↗</span>
            </a>
            <div class="pi">
              <span>${esc(catTitle)}</span>
              <h3><a href="${esc(url)}">${esc(p.name)}</a></h3>
              <div class="pf">
                <strong>${money(effPrice)}</strong>
                <a href="${esc(url)}" aria-label="Explore ${esc(p.name)}">↗</a>
              </div>
              <button class="ar-card-button" type="button" data-ar="${esc(p.slug)}" aria-label="Open camera with ${esc(p.name)}"><span aria-hidden="true">⬡</span> Open Camera <span aria-hidden="true">↗</span></button>
            </div>
          </article>`;
        }).join('');
      }
      filterProducts();
    }

    // 4. Editorial Category Highlights (#eds) — 100% from MySQL `categories` table
    const eds = $('#eds');
    if (eds) {
      const highlightCats = cats.slice(0, 4);
      eds.innerHTML = highlightCats.map((c, i) => {
        const d = i % 2 === 0;
        const num = String(i + 1).padStart(2, '0');
        const words = String(c.name || 'Collection').split(' ');
        const firstWord = words[0] || '';
        const restWords = words.slice(1).join(' ') || 'Collection';
        return `<section class="ed ${d ? 'd' : 'l'}">
          <div class="w eg">
            <div class="ev rv in">
              <img class="em" alt="${esc(c.name)}" loading="lazy" decoding="async" src="${esc(c.image)}">
              <div class="st2">DECORLY<br>COLLECTION<br>${num}</div>
            </div>
            <div class="ec rv in">
              <span class="eb">THE CURATED EDIT — ${num}</span>
              <h2>${esc(firstWord)} <em>${esc(restWords)}</em></h2>
              <p>${esc(c.desc || ('Discover our ' + c.name.toLowerCase() + ' selection, crafted for contemporary Pakistani homes.'))}</p>
              <a class="btn ${d ? 'bg1' : 'bg2'}" href="category?slug=${encodeURIComponent(c.slug)}">EXPLORE ${esc(c.name.toUpperCase())} <s>↗</s></a>
              <div class="ix">${num} / ${String(highlightCats.length).padStart(2, '0')} • DECORLY DESIGN EDIT</div>
            </div>
          </div>
        </section>`;
      }).join('');
    }
  }

  function filterProducts() {
    const q = ($('#search')?.value || '').trim().toLowerCase();
    let shown = 0;
    $$('#pgd .pc').forEach(card => {
      const ok = (activeCat === 'all' || card.dataset.f === activeCat) &&
                 (!q || (card.dataset.n || '').includes(q));
      card.classList.toggle('x', !ok);
      if (ok) {
        shown++;
        card.classList.add('in');
      }
    });
    const rm = $('#rm');
    if (rm) {
      rm.textContent = shown
        ? `Showing ${shown} live furniture design${shown === 1 ? '' : 's'} from the DECORLY MySQL catalog.`
        : 'No matching products found in the database for this filter.';
    }
  }

  // Menu, FAQ, Search, Scroll
  const mbtn = $('#mbtn'), mm = $('#mm');
  if (mbtn && mm) {
    mbtn.onclick = () => {
      const o = mm.classList.toggle('o');
      mbtn.textContent = o ? '×' : '☰';
    };
  }
  $$('.fq-q').forEach(q => {
    q.onclick = () => {
      const o = q.getAttribute('aria-expanded') !== 'true';
      $$('.fq-q').forEach(b => {
        b.setAttribute('aria-expanded', 'false');
        if (b.nextElementSibling) b.nextElementSibling.style.height = '0px';
      });
      if (o) {
        q.setAttribute('aria-expanded', 'true');
        if (q.nextElementSibling) q.nextElementSibling.style.height = q.nextElementSibling.scrollHeight + 'px';
      }
    };
  });

  $('#searchForm')?.addEventListener('submit', e => {
    e.preventDefault();
    const q = ($('#search')?.value || '').trim();
    location.href = 'search' + (q ? '?q=' + encodeURIComponent(q) : '');
  });

  // Render on load and whenever MySQL catalog syncs
  renderHomepageFromDB();
  document.addEventListener('decorly:catalog-synced', renderHomepageFromDB);

  const io = window.IntersectionObserver ? new IntersectionObserver(es => es.forEach(x => {
    if (x.isIntersecting) { x.target.classList.add('in'); io.unobserve(x.target); }
  }), { threshold: 0.1, rootMargin: '0px 0px -40px 0px' }) : null;
  $$('.rv').forEach(e => io ? io.observe(e) : e.classList.add('in'));

  const hd = $('#hd'), pg = $('#pg'), bt = $('#bt'), mw = $('#mw');
  let tk = false, docH = 1, vh = innerHeight;
  function measure() { docH = Math.max(1, document.documentElement.scrollHeight - innerHeight); vh = innerHeight; }
  measure();
  addEventListener('resize', measure, { passive: true });
  addEventListener('load', measure);
  function onS() {
    if (tk) return;
    tk = true;
    requestAnimationFrame(() => {
      tk = false;
      const y = scrollY;
      if (pg) pg.style.transform = `scaleX(${Math.min(1, y / docH)})`;
      if (hd) hd.classList.toggle('sc', y > 30);
      if (bt) bt.classList.toggle('v', y > 500);
      if (mw) {
        const r = mw.getBoundingClientRect();
        if (r.bottom > 0 && r.top < vh) mw.style.transform = `translate3d(${((r.top / vh) * -14).toFixed(2)}vw,0,0)`;
      }
    });
  }
  addEventListener('scroll', onS, { passive: true });
  onS();
  if (bt) bt.onclick = () => { window.__lenis ? window.__lenis.scrollTo(0, { duration: 1.2 }) : scrollTo({ top: 0, behavior: 'smooth' }); };

  // GSAP Hero Story
  if (window.gsap && window.ScrollTrigger) {
    gsap.registerPlugin(ScrollTrigger);
    ScrollTrigger.config({ ignoreMobileResize: true });
    gsap.config({ force3D: true, nullTargetWarn: false });
    const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
    const fine = matchMedia('(min-width: 761px) and (pointer:fine)').matches;
    let lenis = null;
    if (fine && !reduce && window.Lenis) {
      lenis = new Lenis({ lerp: 0.1, smoothWheel: true });
      window.__lenis = lenis;
      lenis.on('scroll', ScrollTrigger.update);
      gsap.ticker.add(t => lenis.raf(t * 1000));
      gsap.ticker.lagSmoothing(0);
    }
  }
})();
