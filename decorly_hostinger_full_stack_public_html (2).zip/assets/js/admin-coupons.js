/* DECORLY External Script: admin-coupons.js */
location.replace('dashboard#coupons')

document.addEventListener('click', function(e) {
  var pr = e.target.closest('[data-decorly-print]');
  if (pr) { e.preventDefault(); window.print(); }
});
