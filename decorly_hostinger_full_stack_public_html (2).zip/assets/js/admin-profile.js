/* DECORLY External Script: admin-profile.js */
location.replace('dashboard#profile')

document.addEventListener('click', function(e) {
  var pr = e.target.closest('[data-decorly-print]');
  if (pr) { e.preventDefault(); window.print(); }
});
