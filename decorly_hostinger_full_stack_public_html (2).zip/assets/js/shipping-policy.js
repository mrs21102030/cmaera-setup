/* DECORLY External Script: shipping-policy.js */
(function(){
  var pre = document.getElementById('decorly-preloader');
  var bar = document.getElementById('decorlyLoaderBar');
  var pct = document.getElementById('decorlyLoaderPct');
  if(!pre) return;
  var p = 12, done = false;
  var iv = setInterval(function(){
    if(done) return;
    p += Math.max(4, Math.round((92 - p) * 0.28));
    if(p > 92) p = 92;
    if(bar) bar.style.width = p + '%';
    if(pct) pct.textContent = p + '%';
  }, 45);
  function finish(){
    if(done) return;
    done = true;
    clearInterval(iv);
    if(bar) bar.style.width = '100%';
    if(pct) pct.textContent = '100%';
    setTimeout(function(){
      pre.classList.add('is-loaded');
    }, 140);
  }
  if(document.readyState === 'complete' || document.readyState === 'interactive'){
    setTimeout(finish, 260);
  } else {
    window.addEventListener('DOMContentLoaded', function(){ setTimeout(finish, 280); });
    window.addEventListener('load', finish);
  }
  setTimeout(finish, 950);
})();

(()=>{'use strict';const btn=document.getElementById('menuBtn'),mob=document.getElementById('mobileMenu');if(btn&&mob){btn.addEventListener('click',()=>{const on=mob.classList.toggle('open');btn.setAttribute('aria-expanded',String(on))});mob.querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>{mob.classList.remove('open');btn.setAttribute('aria-expanded','false')}));document.addEventListener('keydown',e=>{if(e.key==='Escape'&&mob.classList.contains('open')){mob.classList.remove('open');btn.setAttribute('aria-expanded','false');btn.focus()}})}const sf=document.getElementById('searchForm');if(sf)sf.addEventListener('submit',e=>{e.preventDefault();const v=document.getElementById('search')?.value.trim()||'';location.href='search'+(v?'?q='+encodeURIComponent(v):'')});const progress=document.getElementById('progress');let busy=false;addEventListener('scroll',()=>{if(busy)return;busy=true;requestAnimationFrame(()=>{if(progress)progress.style.width=100*scrollY/Math.max(1,document.documentElement.scrollHeight-innerHeight)+'%';busy=false})},{passive:true});const faqSearch=document.getElementById('faqSearch');if(faqSearch){const tabs=[...document.querySelectorAll('.dp-tab')];const items=[...document.querySelectorAll('.dp-qa')];const empty=document.getElementById('faqEmpty');let topic='all';const filter=()=>{let shown=0;const query=faqSearch.value.trim().toLowerCase();items.forEach(it=>{const ok=(topic==='all'||it.dataset.faqTopic===topic)&&it.textContent.toLowerCase().includes(query);it.hidden=!ok;if(ok)shown++});empty.hidden=shown>0};faqSearch.addEventListener('input',filter);tabs.forEach(tab=>tab.addEventListener('click',()=>{topic=tab.dataset.topic;tabs.forEach(t=>t.setAttribute('aria-pressed',String(t===tab)));filter()}));filter()}try{const cart=JSON.parse(localStorage.getItem('decorly_cart')||'[]');const ct=document.getElementById('cartCount');if(ct&&Array.isArray(cart)){ct.textContent=cart.reduce((sum,p)=>sum+Number(p.qty||p.quantity||1),0)}}catch(e){} })();

/* DECORLY cross-page product search — uses the approved search results page */
(function(){
  document.addEventListener('submit',function(event){
    var form=event.target;
    if(!form || form.id!=='searchForm')return;
    event.preventDefault();
    event.stopImmediatePropagation();
    var field=form.querySelector('input[type="search"],input[name="q"],#search');
    var q=field?field.value.trim():'';
    window.location.href='search'+(q?'?q='+encodeURIComponent(q):'');
  },true);
})();

(()=>{const hd=document.querySelector('.decorly-site-header'),menu=document.querySelector('.decorly-site-mobile');if(!hd||!menu)return;
const btn=hd.querySelector('#mbtn');if(btn)btn.addEventListener('click',()=>{const open=menu.classList.toggle('o');btn.textContent=open?'×':'☰';btn.setAttribute('aria-expanded',String(open))});
menu.querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>{menu.classList.remove('o');if(btn){btn.textContent='☰';btn.setAttribute('aria-expanded','false')}}));
document.addEventListener('keydown',e=>{if(e.key==='Escape'){menu.classList.remove('o');if(btn){btn.textContent='☰';btn.setAttribute('aria-expanded','false')}}});
const form=hd.querySelector('form.sf');if(form)form.addEventListener('submit',e=>{e.preventDefault();const v=form.querySelector('input[name=q]')?.value.trim()||'';location.href='search'+(v?'?q='+encodeURIComponent(v):'')});
const mf=menu.querySelector('form');if(mf)mf.addEventListener('submit',e=>{e.preventDefault();const q=mf.querySelector('input[name=q]')?.value.trim()||'';location.href='search'+(q?'?q='+encodeURIComponent(q):'')});
const cart=hd.querySelector('#cartCount');function count(){if(!cart)return;try{const items=JSON.parse(localStorage.getItem('decorly_cart')||'[]');cart.textContent=Array.isArray(items)?items.reduce((n,p)=>n+(Number(p.quantity??p.qty)||1),0):0}catch(e){cart.textContent='0'}}count();window.addEventListener('storage',count);
})();

document.addEventListener('click', function(e) {
  var pr = e.target.closest('[data-decorly-print]');
  if (pr) { e.preventDefault(); window.print(); }
});
