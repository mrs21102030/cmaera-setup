(function(){
  var pre = document.getElementById('decorly-preloader');
  var bar = document.getElementById('decorlyLoaderBar');
  var pct = document.getElementById('decorlyLoaderPct');
  if(!pre) return;
  var p = 12, done = false;
  var iv = setInterval(function(){
    if(done) return;
    p += Math.max(4, Math.round((92 - p) * 0.28));
    if(p > 92) p = 92;
    if(bar) bar.style.width = p + '%';
    if(pct) pct.textContent = p + '%';
  }, 45);
  function finish(){
    if(done) return;
    done = true;
    clearInterval(iv);
    if(bar) bar.style.width = '100%';
    if(pct) pct.textContent = '100%';
    setTimeout(function(){
      pre.classList.add('is-loaded');
    }, 140);
  }
  if(document.readyState === 'complete' || document.readyState === 'interactive'){
    setTimeout(finish, 260);
  } else {
    window.addEventListener('DOMContentLoaded', function(){ setTimeout(finish, 280); });
    window.addEventListener('load', finish);
  }
  setTimeout(finish, 950);
})();

(function(){
  'use strict';
  const $ = id => document.getElementById(id);
  const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));

  function renderArticle() {
    const boot = window.DECORLY_SERVER_BOOT || {};
    const posts = (Array.isArray(boot.blog_posts) ? boot.blog_posts : []).filter(p => p.status !== 'Draft');
    const slug = new URLSearchParams(location.search).get('slug') || (posts[0] && posts[0].slug) || '';
    const p = posts.find(x => x.slug === slug) || posts[0];
    if (!p) return;

    document.title = p.title + ' | DECORLY Journal';
    if ($('articleTitle')) $('articleTitle').textContent = p.title;
    if ($('articleCategory')) $('articleCategory').textContent = 'DECORLY JOURNAL / ' + String(p.category || 'EDITORIAL').toUpperCase();
    if ($('articleDescription')) $('articleDescription').textContent = p.excerpt || '';
    if ($('articleHeroImg')) {
      $('articleHeroImg').src = p.image || '';
      $('articleHeroImg').alt = p.title;
    }
    if ($('articleLead')) $('articleLead').textContent = p.excerpt || '';
    if ($('articleMeta')) $('articleMeta').textContent = `${String(p.category || 'JOURNAL').toUpperCase()} · BY ${String(p.author || 'DECORLY TEAM').toUpperCase()} · ${p.updated || ''}`;
    if ($('articleContent')) {
      $('articleContent').innerHTML = `<h2>${esc(p.title)}</h2><p>${esc(p.content || p.excerpt || '')}</p>`;
    }
    if ($('relatedBlogGrid')) {
      $('relatedBlogGrid').innerHTML = posts.filter(x => x.slug !== p.slug).slice(0, 3).map(x => `
        <a class="blog-card visible" href="single-blog?slug=${encodeURIComponent(x.slug)}">
          <figure><img loading="lazy" src="${esc(x.image)}" alt="${esc(x.title)}"></figure>
          <div class="blog-card-body">
            <span class="blog-cat">${esc(x.category)}</span>
            <h2>${esc(x.title)}</h2>
            <p>${esc(x.excerpt)}</p>
            <span class="blog-read">READ ARTICLE ↗</span>
          </div>
        </a>
      `).join('');
    }
  }

  renderArticle();
  document.addEventListener('decorly:catalog-synced', renderArticle);
})();
