(function(){
  var pre = document.getElementById('decorly-preloader');
  var bar = document.getElementById('decorlyLoaderBar');
  var pct = document.getElementById('decorlyLoaderPct');
  if(!pre) return;
  var p = 12, done = false;
  var iv = setInterval(function(){
    if(done) return;
    p += Math.max(4, Math.round((92 - p) * 0.28));
    if(p > 92) p = 92;
    if(bar) bar.style.width = p + '%';
    if(pct) pct.textContent = p + '%';
  }, 45);
  function finish(){
    if(done) return;
    done = true;
    clearInterval(iv);
    if(bar) bar.style.width = '100%';
    if(pct) pct.textContent = '100%';
    setTimeout(function(){
      pre.classList.add('is-loaded');
    }, 140);
  }
  if(document.readyState === 'complete' || document.readyState === 'interactive'){
    setTimeout(finish, 260);
  } else {
    window.addEventListener('DOMContentLoaded', function(){ setTimeout(finish, 280); });
    window.addEventListener('load', finish);
  }
  setTimeout(finish, 950);
})();

(function(){
  'use strict';
  const $ = id => document.getElementById(id);
  const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));

  function renderCategoriesPage() {
    const boot = window.DECORLY_SERVER_BOOT || {};
    const allCats = (Array.isArray(boot.categories) ? boot.categories : []).filter(c => c.status !== 'Hidden');
    const groupParam = (new URLSearchParams(location.search).get('group') || '').toLowerCase();

    let cats = allCats;
    if (groupParam) {
      cats = allCats.filter(c => (c.group || 'Tables').toLowerCase() === groupParam);
      const title = groupParam.charAt(0).toUpperCase() + groupParam.slice(1);
      if ($('categoriesHeading')) $('categoriesHeading').innerHTML = 'Explore <em>' + esc(title) + '.</em>';
      document.title = title + ' Collections | DECORLY';
    }

    const term = ($('catSearch')?.value || '').trim().toLowerCase();
    const sortVal = $('catSort')?.value || 'default';

    let visible = cats.filter(c => !term || (`${c.name} ${c.subs || ''} ${c.desc || ''}`).toLowerCase().includes(term));
    if (sortVal === 'az') visible.sort((a, b) => a.name.localeCompare(b.name));
    if (sortVal === 'za') visible.sort((a, b) => b.name.localeCompare(a.name));

    document.querySelectorAll('.cat-count, .cat-hero-kicker').forEach(el => {
      el.textContent = String(allCats.length).padStart(2, '0') + ' CURATED COLLECTIONS';
    });

    const featGrid = document.querySelector('.cat-feature-grid');
    if (featGrid && allCats.length) {
      featGrid.innerHTML = allCats.slice(0, 4).map((c, i) => `
        <a class="cat-feature visible" href="category?slug=${encodeURIComponent(c.slug)}">
          <img alt="${esc(c.name)}" loading="lazy" src="${esc(c.image)}"/>
          <div class="cat-feature-content">
            <small>DECORLY EDIT / 0${i + 1}</small>
            <div class="cat-feature-row"><h3>${esc(c.name)}</h3><span aria-hidden="true" class="cat-arrow">↗</span></div>
          </div>
        </a>
      `).join('');
    }

    const grid = $('allCatGrid');
    if (grid) {
      grid.innerHTML = visible.map((c, idx) => `
        <a class="cat-card visible" data-slug="${esc(c.slug)}" href="category?slug=${encodeURIComponent(c.slug)}">
          <div class="cat-card-photo">
            <img alt="Browse ${esc(c.name)}" loading="lazy" src="${esc(c.image)}"/>
            <span class="cat-index">${String(idx + 1).padStart(2, '0')} / ${String(visible.length).padStart(2, '0')}</span>
          </div>
          <div class="cat-card-info">
            <div>
              <small>${esc((c.group || 'FURNITURE').toUpperCase())} COLLECTION</small>
              <h3>${esc(c.name)}</h3>
              <p>${esc(c.subs || c.desc || 'Explore collection')}</p>
            </div>
            <span aria-hidden="true" class="cat-arrow">↗</span>
          </div>
        </a>
      `).join('');
    }
    if ($('catEmpty')) $('catEmpty').style.display = visible.length ? 'none' : 'block';
  }

  $('catSearch')?.addEventListener('input', renderCategoriesPage);
  $('catSort')?.addEventListener('change', renderCategoriesPage);
  $('catClear')?.addEventListener('click', () => {
    if ($('catSearch')) $('catSearch').value = '';
    if ($('catSort')) $('catSort').value = 'default';
    renderCategoriesPage();
  });

  renderCategoriesPage();
  document.addEventListener('decorly:catalog-synced', renderCategoriesPage);

  const hd = document.querySelector('.decorly-site-header'), menu = document.querySelector('.decorly-site-mobile');
  if (hd && menu) {
    const btn = hd.querySelector('#mbtn');
    if (btn) btn.addEventListener('click', () => {
      const open = menu.classList.toggle('o');
      btn.textContent = open ? '×' : '☰';
    });
  }
  document.addEventListener('submit', event => {
    const form = event.target;
    if (!form || form.id !== 'searchForm') return;
    event.preventDefault();
    const field = form.querySelector('input[type="search"],input[name="q"],#search');
    const q = field ? field.value.trim() : '';
    location.href = 'search' + (q ? '?q=' + encodeURIComponent(q) : '');
  }, true);
})();
