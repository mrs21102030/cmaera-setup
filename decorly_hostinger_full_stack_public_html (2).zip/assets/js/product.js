(function(){
  var pre = document.getElementById('decorly-preloader');
  var bar = document.getElementById('decorlyLoaderBar');
  var pct = document.getElementById('decorlyLoaderPct');
  if(!pre) return;
  var p = 12, done = false;
  var iv = setInterval(function(){
    if(done) return;
    p += Math.max(4, Math.round((92 - p) * 0.28));
    if(p > 92) p = 92;
    if(bar) bar.style.width = p + '%';
    if(pct) pct.textContent = p + '%';
  }, 45);
  function finish(){
    if(done) return;
    done = true;
    clearInterval(iv);
    if(bar) bar.style.width = '100%';
    if(pct) pct.textContent = '100%';
    setTimeout(function(){
      pre.classList.add('is-loaded');
    }, 140);
  }
  if(document.readyState === 'complete' || document.readyState === 'interactive'){
    setTimeout(finish, 260);
  } else {
    window.addEventListener('DOMContentLoaded', function(){ setTimeout(finish, 280); });
    window.addEventListener('load', finish);
  }
  setTimeout(finish, 950);
})();

(function(){
  'use strict';
  const $ = id => document.getElementById(id);
  const escapeHtml = str => String(str ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const load = (key, otherwise=[]) => { try { const v = JSON.parse(localStorage.getItem(key)); return Array.isArray(v) ? v : otherwise; } catch { return otherwise; } };
  const save = (key, v) => { try { localStorage.setItem(key, JSON.stringify(v)); return true; } catch { return false; } };
  const money = n => 'Rs ' + Math.round(Number(n || 0)).toLocaleString('en-PK');

  const qp = new URLSearchParams(location.search);
  const reqSlug = qp.get('slug') || (qp.get('name') || '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');

  let products = [];
  let product = null;
  let qty = 1, idx = 0, selected = '', gallery = [], lightboxOpen = false, toastTimer;

  function syncProductFromBoot() {
    const boot = window.DECORLY_SERVER_BOOT || {};
    const rawProds = (Array.isArray(boot.products) ? boot.products : []).filter(p => p.status !== 'Draft');
    products = rawProds.map(ap => {
      const gal = Array.isArray(ap.galleryList) && ap.galleryList.length
        ? ap.galleryList
        : String(ap.gallery || ap.image || '').split(',').map(s => s.trim()).filter(Boolean);
      const finishes = String(ap.finish || 'As shown').split(',').map(s => s.trim()).filter(Boolean);
      return {
        id: ap.id,
        slug: ap.slug,
        name: ap.name,
        cat: ap.catSlug,
        categoryName: ap.category || 'Furniture',
        image: ap.image || (gal[0] || ''),
        gallery: gal.length ? gal : [ap.image || ''],
        finish: finishes[0] || 'As shown',
        finishes: finishes.length ? finishes : ['As shown'],
        price: Number(ap.salePrice && ap.salePrice < ap.price ? ap.salePrice : ap.price) || 0,
        origPrice: Number(ap.price) || 0,
        stock: Number(ap.stock ?? 10),
        dimensions: ap.dimensions || 'Standard',
        material: ap.material || 'Powder-Coated Steel & Tempered Glass',
        warranty: ap.warranty || '1 Year Structural Warranty',
        sku: ap.sku || ap.slug,
        short: ap.short || '',
        description: ap.description || ''
      };
    });
    product = products.find(p => p.slug === reqSlug || String(p.id) === reqSlug) || (reqSlug ? null : products[0]) || null;
  }

  function toast(s) {
    clearTimeout(toastTimer);
    if (!$('toast')) return;
    $('toast').textContent = s;
    $('toast').classList.add('show');
    toastTimer = setTimeout(() => $('toast').classList.remove('show'), 3200);
  }

  function getWish() { return load('decorly_wishlist'); }
  function isWished() { return product && getWish().some(p => String(typeof p === 'object' ? p.id : p) === String(product.id) || (typeof p === 'object' && p.slug === product.slug)); }
  function wishUI() {
    if (!$('wishlistBtn') || !product) return;
    const on = isWished();
    $('wishlistBtn').classList.toggle('is-on', on);
    $('wishlistBtn').setAttribute('aria-pressed', String(on));
    $('wishlistBtn').textContent = on ? '♥' : '♡';
  }

  function photo(i) {
    if (!gallery.length) return;
    idx = (i + gallery.length) % gallery.length;
    if ($('mainPhoto')) {
      $('mainPhoto').src = gallery[idx];
      $('mainPhoto').alt = `${product ? product.name : 'Product'}, photo ${idx + 1}`;
    }
    $('thumbList')?.querySelectorAll('.thumb').forEach((b, n) => b.classList.toggle('active', n === idx));
    if (lightboxOpen && $('lightboxPhoto')) {
      $('lightboxPhoto').src = gallery[idx];
      if ($('lightboxCount')) $('lightboxCount').textContent = `${idx + 1} / ${gallery.length}`;
    }
  }

  function gallerySet(p) {
    gallery = [...new Set([...(Array.isArray(p.gallery) ? p.gallery : []), p.image].filter(Boolean))];
    idx = 0;
    if ($('thumbList')) {
      $('thumbList').innerHTML = gallery.map((src, i) =>
        `<button class="thumb ${i ? '' : 'active'}" type="button" data-i="${i}"><img src="${escapeHtml(src)}" alt="Photo ${i + 1}" loading="lazy"></button>`
      ).join('');
      $('thumbList').querySelectorAll('button').forEach(b => b.addEventListener('click', () => photo(+b.dataset.i)));
    }
    photo(0);
  }

  function renderRelated() {
    if (!$('relatedGrid') || !product) return;
    const related = products.filter(p => p.slug !== product.slug)
      .sort((a, b) => Number(b.cat === product.cat) - Number(a.cat === product.cat))
      .slice(0, 4);
    $('relatedGrid').innerHTML = related.map(p => {
      const url = `product?slug=${encodeURIComponent(p.slug)}`;
      return `<article class="product-card visible">
        <a class="product-photo" href="${url}">
          <img src="${escapeHtml(p.image)}" alt="${escapeHtml(p.name)}" loading="lazy">
          <span class="product-badge">Discover</span>
          <span class="product-hover">VIEW PRODUCT ↗</span>
        </a>
        <div class="product-info">
          <span>${escapeHtml(p.categoryName)}</span>
          <h3><a href="${url}">${escapeHtml(p.name)}</a></h3>
          <div class="product-foot"><strong>${money(p.price)}</strong><a href="${url}">↗</a></div>
          <button class="ar-card-button" type="button" data-ar="${escapeHtml(p.slug)}" aria-label="Open camera with ${escapeHtml(p.name)}"><span aria-hidden="true">⬡</span> Open Camera <span aria-hidden="true">↗</span></button>
        </div>
      </article>`;
    }).join('');
  }

  function render() {
    syncProductFromBoot();
    if (!product) {
      if ($('productName')) $('productName').textContent = 'Product Not Found in Database';
      if ($('productLead')) $('productLead').textContent = 'This item may have been removed by the store administrator.';
      if ($('productPrice')) $('productPrice').textContent = 'Unavailable';
      if ($('availability')) $('availability').textContent = 'Removed from catalog';
      return;
    }

    document.title = product.name + ' | DECORLY';
    if ($('breadProduct')) $('breadProduct').textContent = product.name;
    if ($('breadCat')) {
      $('breadCat').textContent = product.categoryName;
      $('breadCat').href = `category?slug=${encodeURIComponent(product.cat)}`;
    }
    if ($('productCategory')) $('productCategory').textContent = product.categoryName.toUpperCase();
    if ($('productName')) $('productName').textContent = product.name;
    if ($('modelId')) $('modelId').textContent = 'SKU: ' + product.sku;
    if ($('productLead')) $('productLead').textContent = product.short || product.description;
    if ($('productPrice')) $('productPrice').textContent = money(product.price);
    if ($('availability')) {
      $('availability').textContent = product.stock > 0
        ? `✓ In Stock (${product.stock} pcs available) — Nationwide Delivery Across Pakistan`
        : '✕ Currently Out of Stock';
    }
    if ($('descriptionText')) $('descriptionText').textContent = product.description || product.short;
    if ($('specList')) {
      $('specList').innerHTML = [
        ['Collection', product.categoryName],
        ['Finish Options', product.finishes.join(', ')],
        ['Dimensions', product.dimensions],
        ['Material', product.material],
        ['Warranty', product.warranty],
        ['Product SKU', product.sku]
      ].map(([k, v]) => `<div><dt>${escapeHtml(k)}</dt><dd>${escapeHtml(v)}</dd></div>`).join('');
    }

    const finishes = product.finishes.length ? product.finishes : ['As shown'];
    selected = finishes[0];
    if ($('finishSelection')) $('finishSelection').textContent = selected;
    if ($('finishOptions')) {
      $('finishOptions').innerHTML = finishes.map((f, i) =>
        `<button type="button" class="finish-btn ${i === 0 ? 'selected' : ''}" data-finish="${escapeHtml(f)}">${escapeHtml(f)}</button>`
      ).join('');
      $('finishOptions').querySelectorAll('button').forEach(b => b.onclick = () => {
        selected = b.dataset.finish;
        if ($('finishSelection')) $('finishSelection').textContent = selected;
        $('finishOptions').querySelectorAll('button').forEach(x => x.classList.toggle('selected', b === x));
      });
    }

    gallerySet(product);
    if ($('editorialImage')) $('editorialImage').src = gallery[1] || gallery[0] || product.image;
    if ($('productArBtn')) { $('productArBtn').dataset.ar = product.slug; $('productArBtn').setAttribute('aria-label', 'Open camera with ' + product.name); }
    wishUI();
    renderRelated();
  }

  $('qtyMinus')?.addEventListener('click', () => { qty = Math.max(1, qty - 1); if ($('qtyNumber')) $('qtyNumber').textContent = qty; });
  $('qtyPlus')?.addEventListener('click', () => { qty = Math.min(20, qty + 1); if ($('qtyNumber')) $('qtyNumber').textContent = qty; });

  $('addCart')?.addEventListener('click', () => {
    if (!product) return;
    window.DecorlyShop?.addToCart({
      id: product.id,
      slug: product.slug,
      name: product.name,
      image: product.image,
      price: product.price,
      finish: selected,
      qty,
      url: `product?slug=${encodeURIComponent(product.slug)}`
    });
    if ($('actionFeedback')) $('actionFeedback').textContent = `${qty} item${qty > 1 ? 's' : ''} added to your shopping bag.`;
    toast('Added to your cart');
  });

  $('wishlistBtn')?.addEventListener('click', () => {
    if (!product) return;
    let w = getWish();
    if (isWished()) {
      w = w.filter(p => !(String(typeof p === 'object' ? p.id : p) === String(product.id) || (typeof p === 'object' && p.slug === product.slug)));
      toast('Removed from wishlist');
    } else {
      w.push({ id: product.id, slug: product.slug, name: product.name, image: product.image, price: product.price, url: `product?slug=${encodeURIComponent(product.slug)}` });
      toast('Saved to wishlist');
    }
    save('decorly_wishlist', w);
    document.dispatchEvent(new Event('decorly:updated'));
    wishUI();
  });

  $('photoStage')?.addEventListener('click', () => {
    if (!$('lightbox')) return;
    lightboxOpen = true;
    $('lightbox').hidden = false;
    document.body.style.overflow = 'hidden';
    photo(idx);
  });
  const closeLb = () => {
    if (!$('lightbox')) return;
    lightboxOpen = false;
    $('lightbox').hidden = true;
    document.body.style.overflow = '';
  };
  $('lightboxClose')?.addEventListener('click', closeLb);
  $('lightboxPrev')?.addEventListener('click', () => photo(idx - 1));
  $('lightboxNext')?.addEventListener('click', () => photo(idx + 1));

  document.querySelectorAll('.detail-toggle').forEach(b => b.addEventListener('click', () => {
    const p = $(b.getAttribute('aria-controls'));
    if (!p) return;
    const opening = p.hidden;
    p.hidden = !opening;
    b.setAttribute('aria-expanded', String(opening));
    const sp = b.querySelector('span');
    if (sp) sp.textContent = opening ? '−' : '+';
  }));

  render();
  document.addEventListener('decorly:catalog-synced', render);

  const hd = document.querySelector('.decorly-site-header'), menu = document.querySelector('.decorly-site-mobile');
  if (hd && menu) {
    const btn = hd.querySelector('#mbtn');
    if (btn) btn.addEventListener('click', () => {
      const open = menu.classList.toggle('o');
      btn.textContent = open ? '×' : '☰';
    });
  }
  document.addEventListener('submit', event => {
    const form = event.target;
    if (!form || form.id !== 'searchForm') return;
    event.preventDefault();
    const field = form.querySelector('input[type="search"],input[name="q"],#search');
    const q = field ? field.value.trim() : '';
    location.href = 'search' + (q ? '?q=' + encodeURIComponent(q) : '');
  }, true);
})();
