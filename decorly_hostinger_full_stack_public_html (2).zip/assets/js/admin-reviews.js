/* DECORLY External Script: admin-reviews.js */
location.replace('dashboard#reviews')

document.addEventListener('click', function(e) {
  var pr = e.target.closest('[data-decorly-print]');
  if (pr) { e.preventDefault(); window.print(); }
});
