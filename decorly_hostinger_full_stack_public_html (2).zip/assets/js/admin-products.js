/* DECORLY External Script: admin-products.js */
location.replace('dashboard#products')

document.addEventListener('click', function(e) {
  var pr = e.target.closest('[data-decorly-print]');
  if (pr) { e.preventDefault(); window.print(); }
});
