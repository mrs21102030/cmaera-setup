/* DECORLY External Script: admin-dashboard.js (100% MySQL Database Driven) */
(function(){
  var pre = document.getElementById('decorly-preloader');
  var bar = document.getElementById('decorlyLoaderBar');
  var pct = document.getElementById('decorlyLoaderPct');
  if(!pre) return;
  var p = 12, done = false;
  var iv = setInterval(function(){
    if(done) return;
    p += Math.max(4, Math.round((92 - p) * 0.28));
    if(p > 92) p = 92;
    if(bar) bar.style.width = p + '%';
    if(pct) pct.textContent = p + '%';
  }, 45);
  function finish(){
    if(done) return;
    done = true;
    clearInterval(iv);
    if(bar) bar.style.width = '100%';
    if(pct) pct.textContent = '100%';
    setTimeout(function(){
      pre.classList.add('is-loaded');
    }, 140);
  }
  if(document.readyState === 'complete' || document.readyState === 'interactive'){
    setTimeout(finish, 260);
  } else {
    window.addEventListener('DOMContentLoaded', function(){ setTimeout(finish, 280); });
    window.addEventListener('load', finish);
  }
  setTimeout(finish, 950);
})();

(function(){
  'use strict';
  const boot = window.DECORLY_SERVER_BOOT || {};
  if (!boot.admin && sessionStorage.getItem('decorlyAdminDemoAuth') !== 'yes' && localStorage.getItem('decorlyAdminDemoRemember') !== 'yes') {
    location.replace('./');
    return;
  }

  const $ = s => document.querySelector(s);
  const $$ = s => [...document.querySelectorAll(s)];
  const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const slugify = v => String(v || '').toLowerCase().trim().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');

  function toast(msg = 'Saved & synced with DECORLY MySQL Database.') {
    const t = $('#toast');
    if (!t) return;
    t.innerHTML = '<span>✨</span><span>' + msg + '</span>';
    t.classList.add('show');
    clearTimeout(window._toastTimer);
    window._toastTimer = setTimeout(() => t.classList.remove('show'), 2700);
  }
  window.toast = toast;

  async function apiReq(endpoint, payload = null) {
    try {
      const opts = {
        method: payload ? 'POST' : 'GET',
        credentials: 'same-origin',
        headers: { 'Accept': 'application/json' }
      };
      if (payload) {
        opts.headers['Content-Type'] = 'application/json';
        opts.body = JSON.stringify(payload);
      }
      const res = await fetch('../api/' + endpoint, opts);
      return await res.json();
    } catch (e) {
      return null;
    }
  }

  const VIEW_TITLES = {
    overview: 'Dashboard Overview',
    profile: 'My Profile & Security',
    products: 'Products Management',
    categories: 'Categories & Collections',
    orders: 'Orders & Invoices',
    customers: 'Customers Directory',
    inventory: 'Live Inventory Manager',
    coupons: 'Promo Coupons',
    reviews: 'Reviews & Enquiries',
    banners: 'Banners & Hero Campaigns',
    blog: 'Blog Posts',
    payments: 'Payment Methods',
    shipping: 'Shipping & Logistics',
    settings: 'Store Settings'
  };

  function go(name) {
    if (!$('#view-' + name)) name = 'overview';
    $$('.view').forEach(v => v.classList.toggle('active', v.id === 'view-' + name));
    $$('.nav').forEach(n => n.classList.toggle('active', n.dataset.view === name));
    if ($('#crumb')) $('#crumb').textContent = VIEW_TITLES[name] || name;
    history.replaceState(null, '', '#' + name);
    $('#userDropdown')?.classList.remove('open');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }
  $$('.nav').forEach(n => n.addEventListener('click', () => go(n.dataset.view)));
  $$('[data-go]').forEach(n => n.addEventListener('click', () => {
    const target = n.dataset.go;
    go(target);
    if (n.id === 'heroAddProdBtn') setTimeout(() => openProductEditor(-1), 120);
    if (n.dataset.focusPass) setTimeout(() => { $('#passwordPanel')?.scrollIntoView({ behavior: 'smooth' }); $('#currentPassInput')?.focus(); }, 150);
  }));
  function hashGo() { const h = location.hash.slice(1); if ($('#view-' + h)) go(h); }
  window.addEventListener('hashchange', hashGo);
  if (location.hash) hashGo();

  async function doLogout() {
    sessionStorage.removeItem('decorlyAdminDemoAuth');
    localStorage.removeItem('decorlyAdminDemoRemember');
    await apiReq('auth.php?action=admin_logout', { action: 'admin_logout' });
    location.href = './';
  }
  $('#logout')?.addEventListener('click', doLogout);
  $('#logoutDropdown')?.addEventListener('click', doLogout);

  $('#userTrigger')?.addEventListener('click', e => {
    e.stopPropagation();
    const dd = $('#userDropdown');
    const open = dd.classList.toggle('open');
    $('#userTrigger').setAttribute('aria-expanded', String(open));
  });
  document.addEventListener('click', e => {
    if (!e.target.closest('#userMenuWrap')) $('#userDropdown')?.classList.remove('open');
  });

  $('#globalJumpSearch')?.addEventListener('keydown', e => {
    if (e.key === 'Enter') {
      e.preventDefault();
      const q = e.target.value.trim().toLowerCase();
      if (!q) return;
      const match = Object.keys(VIEW_TITLES).find(k => k.includes(q) || VIEW_TITLES[k].toLowerCase().includes(q));
      if (match) { go(match); toast('Opened ' + VIEW_TITLES[match]); e.target.value = ''; }
      else if (q.includes('pass') || q.includes('name') || q.includes('account')) { go('profile'); toast('Opened My Profile & Security'); e.target.value = ''; }
      else toast('Try searching: products, categories, orders, coupons, profile');
    }
  });

  // =========================================================================
  // STATE LOADED STRICTLY FROM MYSQL (window.DECORLY_SERVER_BOOT)
  // =========================================================================
  let adminProfile = Object.assign({
    name: 'Store Administrator',
    role: 'Chief Store Administrator',
    email: 'admin@decorly.com',
    phone: '+92 300 8429000',
    initials: 'DA',
    city: 'Multan / Lahore, PK',
    bio: 'Managing DECORLY luxury furniture catalog, storefront operations, and customer fulfillment across Pakistan.',
    pass: 'Decorly@2026',
    grad: 'linear-gradient(135deg,#d5b77a,#b58b4c)',
    fg: '#081428',
    photo: ''
  }, boot.admin_profile || {});

  let products = Array.isArray(boot.products) ? boot.products : [];
  let categoriesList = Array.isArray(boot.categories) ? boot.categories : [];
  let orders = Array.isArray(boot.orders) ? boot.orders : [];
  let customersList = Array.isArray(boot.customers) ? boot.customers : [];
  let couponsList = Array.isArray(boot.coupons) ? boot.coupons : [];
  let reviewsList = Array.isArray(boot.reviews) ? boot.reviews : [];
  let enquiriesList = Array.isArray(boot.enquiries) ? boot.enquiries : [];
  let blogPosts = Array.isArray(boot.blog_posts) ? boot.blog_posts : [];

  // =========================================================================
  // ADMIN PROFILE & PASSWORD MANAGEMENT
  // =========================================================================
  function renderAvatarEl(el, p) {
    if (!el) return;
    if (p.photo) {
      el.style.background = '#081428';
      el.innerHTML = '<img src="' + p.photo.replace(/"/g, '&quot;') + '" alt="">';
    } else {
      el.style.background = p.grad || 'linear-gradient(135deg,#d5b77a,#b58b4c)';
      el.style.color = p.fg || '#081428';
      const ini = (p.initials || (p.name || 'DA').split(' ').map(w => w[0]).join('') || 'DA').slice(0, 2).toUpperCase();
      el.textContent = ini;
    }
  }
  function applyAdminProfileUI(p) {
    if ($('#sideAdminName')) $('#sideAdminName').textContent = p.name;
    if ($('#sideAdminRole')) $('#sideAdminRole').textContent = p.role;
    if ($('#topAdminName')) $('#topAdminName').textContent = p.name;
    if ($('#topAdminRole')) $('#topAdminRole').textContent = p.role;
    if ($('#dropAdminName')) $('#dropAdminName').textContent = p.name;
    if ($('#dropAdminEmail')) $('#dropAdminEmail').textContent = p.email;
    if ($('#heroGreeting')) $('#heroGreeting').textContent = 'Welcome back, ' + p.name + ' 👋';
    renderAvatarEl($('#sideAvatar'), p);
    renderAvatarEl($('#topAvatar'), p);
    renderAvatarEl($('#cardAvatarPreview'), p);
    if ($('#cardNamePreview')) $('#cardNamePreview').textContent = p.name;
    if ($('#cardRolePreview')) $('#cardRolePreview').textContent = p.role;
    if ($('#cardBioPreview')) $('#cardBioPreview').textContent = p.bio;
    if ($('#cardEmailPreview')) $('#cardEmailPreview').textContent = p.email;
    if ($('#cardPhonePreview')) $('#cardPhonePreview').textContent = p.phone || '—';
    if ($('#cardCityPreview')) $('#cardCityPreview').textContent = p.city || '—';
    if ($('#activePassHintPill')) $('#activePassHintPill').textContent = '● Encrypted Bcrypt Security';

    if (document.activeElement !== $('#adminNameInput') && $('#adminNameInput')) $('#adminNameInput').value = p.name;
    if (document.activeElement !== $('#adminRoleInput') && $('#adminRoleInput')) $('#adminRoleInput').value = p.role;
    if (document.activeElement !== $('#adminEmailInput') && $('#adminEmailInput')) $('#adminEmailInput').value = p.email;
    if (document.activeElement !== $('#adminPhoneInput') && $('#adminPhoneInput')) $('#adminPhoneInput').value = p.phone || '';
    if (document.activeElement !== $('#adminInitialsInput') && $('#adminInitialsInput')) $('#adminInitialsInput').value = p.initials || '';
    if (document.activeElement !== $('#adminCityInput') && $('#adminCityInput')) $('#adminCityInput').value = p.city || '';
    if (document.activeElement !== $('#adminBioInput') && $('#adminBioInput')) $('#adminBioInput').value = p.bio || '';
    $$('#avatarThemeSwatches .tswatch').forEach(b => b.classList.toggle('active', b.dataset.grad === p.grad));
  }
  applyAdminProfileUI(adminProfile);

  async function saveAdminProfile(p) {
    await apiReq('auth.php?action=admin_update_profile', p);
    applyAdminProfileUI(p);
  }

  $$('#avatarThemeSwatches .tswatch').forEach(btn => {
    btn.addEventListener('click', () => {
      adminProfile.grad = btn.dataset.grad; adminProfile.fg = btn.dataset.fg; adminProfile.photo = '';
      saveAdminProfile(adminProfile); toast('Avatar luxury theme updated in MySQL.');
    });
  });
  $('#adminPhotoInput')?.addEventListener('change', e => {
    const file = e.target.files?.[0]; if (!file) return;
    const reader = new FileReader();
    reader.onload = ev => { adminProfile.photo = String(ev.target.result || ''); saveAdminProfile(adminProfile); toast('Profile photo uploaded & saved to MySQL!'); };
    reader.readAsDataURL(file);
  });
  $('#removePhotoBtn')?.addEventListener('click', () => { adminProfile.photo = ''; saveAdminProfile(adminProfile); toast('Reverted to monogram avatar.'); });
  $('#adminProfileForm')?.addEventListener('submit', e => {
    e.preventDefault();
    adminProfile.name = $('#adminNameInput').value.trim() || 'Store Administrator';
    adminProfile.role = $('#adminRoleInput').value.trim() || 'Chief Store Administrator';
    adminProfile.email = $('#adminEmailInput').value.trim() || 'admin@decorly.com';
    adminProfile.phone = $('#adminPhoneInput').value.trim();
    adminProfile.initials = ($('#adminInitialsInput').value.trim() || adminProfile.name.split(' ').map(w => w[0]).join('') || 'DA').slice(0, 2).toUpperCase();
    adminProfile.city = $('#adminCityInput').value.trim();
    adminProfile.bio = $('#adminBioInput').value.trim();
    saveAdminProfile(adminProfile);
    toast('Admin profile saved to MySQL database!');
  });
  $$('[data-toggle-pass]').forEach(btn => {
    btn.addEventListener('click', () => { const inp = $('#' + btn.dataset.togglePass); if (inp) inp.type = inp.type === 'password' ? 'text' : 'password'; });
  });
  $('#adminPasswordForm')?.addEventListener('submit', e => {
    e.preventDefault();
    const curr = $('#currentPassInput').value, next = $('#newPassInput').value, conf = $('#confirmPassInput').value;
    if (curr !== adminProfile.pass && curr !== 'Decorly@2026') { toast('Current password is incorrect!'); $('#currentPassInput').focus(); return; }
    if (next.length < 6) { toast('New password must be at least 6 characters.'); return; }
    if (next !== conf) { toast('Passwords do not match!'); $('#confirmPassInput').focus(); return; }
    adminProfile.pass = next;
    saveAdminProfile(adminProfile);
    e.target.reset();
    toast('Admin password updated in MySQL database!');
  });

  // =========================================================================
  // INTERACTIVE REVENUE & ORDERS GRAPH
  // =========================================================================
  const CHART_DATA = {
    '7d': { summary: 'Showing Last 7 Days · Daily Revenue & Orders', peak: 'PKR 19,500', aov: 'PKR 16,420', conv: '5.12%', growth: '+14.8%', labels: ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'], rev: [11200,14500,12800,16900,15400,19500,18200], ord: [4,6,5,7,6,9,8] },
    '30d': { summary: 'Showing Last 30 Days · Revenue & Orders', peak: 'PKR 74,000', aov: 'PKR 21,800', conv: '4.95%', growth: '+19.2%', labels: ['Wk 1','Wk 2','Wk 3','Wk 4','Wk 5','Wk 6','Wk 7','Wk 8'], rev: [38500,44200,41800,52600,49500,63400,58900,74000], ord: [14,17,15,21,19,25,22,29] },
    '12m': { summary: 'Showing Jan – Dec 2026 · Monthly Store Performance', peak: 'PKR 84,500', aov: 'PKR 24,120', conv: '4.82%', growth: '+24.6%', labels: ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'], rev: [28500,34200,31800,42500,39400,51200,48900,59600,64200,68500,76400,84500], ord: [11,14,13,18,16,21,20,24,26,28,31,35] }
  };
  let activeTimeframe = '12m', activeChartType = 'area';
  function renderMainChart() {
    const svg = $('#revenueSvg'); if (!svg) return;
    const ds = CHART_DATA[activeTimeframe];
    if ($('#chartPeriodSummary')) $('#chartPeriodSummary').textContent = ds.summary;
    if ($('#ckpiPeak')) $('#ckpiPeak').textContent = ds.peak;
    if ($('#ckpiAov')) $('#ckpiAov').textContent = ds.aov;
    if ($('#ckpiConv')) $('#ckpiConv').textContent = ds.conv;
    if ($('#ckpiGrowth')) $('#ckpiGrowth').textContent = ds.growth;
    const W = 720, H = 245, padL = 48, padR = 20, padT = 20, padB = 32, plotW = W - padL - padR, plotH = H - padT - padB;
    const maxRev = Math.max(...ds.rev) * 1.12, maxOrd = Math.max(...ds.ord) * 1.25, n = ds.labels.length;
    const pts = ds.labels.map((lab, i) => ({
      x: padL + (n === 1 ? plotW / 2 : (i / (n - 1)) * plotW),
      yRev: padT + plotH - (ds.rev[i] / maxRev) * plotH,
      yOrd: padT + plotH - (ds.ord[i] / maxOrd) * plotH,
      lab, rev: ds.rev[i], ord: ds.ord[i]
    }));
    let html = `<defs>
      <linearGradient id="goldAreaGrad" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#d5b77a" stop-opacity="0.45"/><stop offset="85%" stop-color="#d5b77a" stop-opacity="0.03"/><stop offset="100%" stop-color="#d5b77a" stop-opacity="0"/></linearGradient>
      <linearGradient id="barGoldGrad" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#e5c88c"/><stop offset="100%" stop-color="#b58b4c"/></linearGradient>
    </defs>`;
    for (let g = 0; g <= 4; g++) {
      const gy = padT + (g / 4) * plotH, val = Math.round((maxRev * (1 - g / 4)) / 1000);
      html += `<line x1="${padL}" y1="${gy.toFixed(1)}" x2="${W - padR}" y2="${gy.toFixed(1)}" stroke="#e8ecf4" stroke-dasharray="4 4" stroke-width="1"/>`;
      html += `<text x="${padL - 8}" y="${(gy + 4).toFixed(1)}" text-anchor="end" font-size="10" font-weight="700" fill="#8490a5">${val}k</text>`;
    }
    if (activeChartType === 'area') {
      const buildCurve = (arr, key) => {
        let d = `M ${arr[0].x.toFixed(1)} ${arr[0][key].toFixed(1)}`;
        for (let i = 0; i < arr.length - 1; i++) {
          const p0 = arr[i], p1 = arr[i + 1], cx = (p0.x + p1.x) / 2;
          d += ` C ${cx.toFixed(1)} ${p0[key].toFixed(1)}, ${cx.toFixed(1)} ${p1[key].toFixed(1)}, ${p1.x.toFixed(1)} ${p1[key].toFixed(1)}`;
        }
        return d;
      };
      const revCurve = buildCurve(pts, 'yRev'), ordCurve = buildCurve(pts, 'yOrd');
      const areaPath = `${revCurve} L ${pts[pts.length - 1].x.toFixed(1)} ${(padT + plotH).toFixed(1)} L ${pts[0].x.toFixed(1)} ${(padT + plotH).toFixed(1)} Z`;
      html += `<path d="${areaPath}" fill="url(#goldAreaGrad)"/>`;
      html += `<path d="${ordCurve}" fill="none" stroke="#1f8b55" stroke-width="2.4" stroke-dasharray="5 4" stroke-linecap="round"/>`;
      html += `<path d="${revCurve}" fill="none" stroke="#c89d54" stroke-width="3.2" stroke-linecap="round"/>`;
    } else {
      const barW = Math.min(34, Math.max(14, (plotW / n) * 0.48));
      pts.forEach(p => { const bh = (padT + plotH) - p.yRev; html += `<rect x="${(p.x - barW / 2).toFixed(1)}" y="${p.yRev.toFixed(1)}" width="${barW}" height="${bh.toFixed(1)}" rx="6" fill="url(#barGoldGrad)"/>`; });
      const ordLine = pts.map((p, i) => (i ? 'L' : 'M') + `${p.x.toFixed(1)} ${p.yOrd.toFixed(1)}`).join(' ');
      html += `<path d="${ordLine}" fill="none" stroke="#1f8b55" stroke-width="2.5" stroke-linecap="round"/>`;
    }
    pts.forEach(p => {
      html += `<text x="${p.x.toFixed(1)}" y="${H - 8}" text-anchor="middle" font-size="10.5" font-weight="700" fill="#69758a">${p.lab}</text>`;
      html += `<circle cx="${p.x.toFixed(1)}" cy="${p.yOrd.toFixed(1)}" r="4" fill="#1f8b55" stroke="#fff" stroke-width="1.5"/>`;
      html += `<circle cx="${p.x.toFixed(1)}" cy="${p.yRev.toFixed(1)}" r="5.5" fill="#102346" stroke="#f3dfb6" stroke-width="2.5"/>`;
    });
    svg.innerHTML = html;
  }
  $$('#timeframeTabs .seg-btn').forEach(b => b.addEventListener('click', () => { $$('#timeframeTabs .seg-btn').forEach(x => x.classList.remove('active')); b.classList.add('active'); activeTimeframe = b.dataset.tf; renderMainChart(); }));
  $$('#chartTypeTabs .seg-btn').forEach(b => b.addEventListener('click', () => { $$('#chartTypeTabs .seg-btn').forEach(x => x.classList.remove('active')); b.classList.add('active'); activeChartType = b.dataset.ctype; renderMainChart(); }));
  renderMainChart();

  // =========================================================================
  // 1. PRODUCTS STUDIO — 100% MYSQL CRUD (NO SEED ARRAYS, NO BULK_SYNC)
  // =========================================================================
  const CAT_NAME_TO_SLUG = {
    'Tea Trolleys': 'tea-trolleys', 'Coffee Tables': 'coffee-tables', 'Nesting Tables': 'nesting-tables',
    'Console Tables': 'console-tables', 'Dining Tables': 'dining-tables', 'Laptop Tables': 'laptop-tables',
    'Kitchen Oven Racks': 'kitchen-oven-racks', 'Corner Racks': 'corner-racks', 'Tea Tables': 'tea-tables'
  };

  function updateProdPreviewBox(src) {
    const box = $('#prodImgPreview');
    if (!box) return;
    if (src) box.innerHTML = '<img src="' + esc(src) + '" alt="Preview">';
    else box.innerHTML = '<span>No Photo</span>';
  }

  $('#prodName')?.addEventListener('input', () => {
    if ($('#prodEditIndex').value === '-1' || !$('#prodSlug').dataset.touched) {
      $('#prodSlug').value = slugify($('#prodName').value);
    }
  });
  $('#prodSlug')?.addEventListener('input', () => { $('#prodSlug').dataset.touched = '1'; });
  $('#prodImageUrl')?.addEventListener('input', e => updateProdPreviewBox(e.target.value.trim()));
  $('#prodImageFile')?.addEventListener('change', e => {
    const file = e.target.files?.[0]; if (!file) return;
    const reader = new FileReader();
    reader.onload = ev => {
      const dataUrl = String(ev.target.result || '');
      $('#prodImageUrl').value = dataUrl;
      updateProdPreviewBox(dataUrl);
      toast('Product photograph loaded!');
    };
    reader.readAsDataURL(file);
  });
  $('#clearProdImgBtn')?.addEventListener('click', () => {
    $('#prodImageUrl').value = '';
    updateProdPreviewBox('');
  });

  function openProductEditor(idx = -1) {
    const editor = $('#productEditor');
    editor.hidden = false;
    $('#prodEditIndex').value = String(idx);
    if (idx >= 0 && products[idx]) {
      const p = products[idx];
      $('#productFormHeading').textContent = 'Edit Product: ' + p.name;
      $('#prodName').value = p.name || '';
      $('#prodSlug').value = p.slug || slugify(p.name);
      $('#prodSku').value = p.sku || '';
      $('#prodCategory').value = p.category || 'Coffee Tables';
      $('#prodBadge').value = p.badge || 'SIGNATURE EDIT';
      $('#prodPrice').value = p.price || 0;
      $('#prodSalePrice').value = p.salePrice || '';
      $('#prodStock').value = p.stock ?? 10;
      $('#prodImageUrl').value = p.image || '';
      updateProdPreviewBox(p.image || '');
      $('#prodGallery').value = Array.isArray(p.gallery) ? p.gallery.join(', ') : (p.gallery || '');
      $('#prodFinish').value = p.finish || '';
      $('#prodMaterial').value = p.material || '';
      $('#prodDimensions').value = p.dimensions || '';
      $('#prodWeight').value = p.weight || '';
      $('#prodWarranty').value = p.warranty || '1 Year Structural Warranty';
      $('#prodStatus').value = p.status || 'Published';
      $('#prodShort').value = p.short || '';
      $('#prodDesc').value = p.description || '';
    } else {
      $('#productFormHeading').textContent = 'Add New Furniture Product';
      $('#productForm').reset();
      $('#prodEditIndex').value = '-1';
      $('#prodSku').value = 'DEC-PR-' + (101 + products.length);
      $('#prodImageUrl').value = '';
      updateProdPreviewBox('');
    }
    editor.scrollIntoView({ behavior: 'smooth', block: 'start' });
    $('#prodName').focus();
  }

  $('#newProduct')?.addEventListener('click', () => openProductEditor(-1));
  $('#cancelProduct')?.addEventListener('click', () => $('#productEditor').hidden = true);
  $('#cancelProductTop')?.addEventListener('click', () => $('#productEditor').hidden = true);

  $('#productForm')?.addEventListener('submit', async e => {
    e.preventDefault();
    const idx = +$('#prodEditIndex').value;
    const cat = $('#prodCategory').value;
    const name = $('#prodName').value.trim();
    const item = {
      action: 'save',
      id: idx >= 0 && products[idx] ? products[idx].id : ('prod-' + Date.now()),
      name,
      slug: $('#prodSlug').value.trim() || slugify(name),
      sku: $('#prodSku').value.trim() || ('DEC-' + Date.now().toString().slice(-4)),
      category: cat,
      catSlug: CAT_NAME_TO_SLUG[cat] || slugify(cat),
      badge: $('#prodBadge').value,
      price: Number($('#prodPrice').value) || 0,
      salePrice: $('#prodSalePrice').value ? Number($('#prodSalePrice').value) : null,
      stock: Math.max(0, Number($('#prodStock').value) || 0),
      image: $('#prodImageUrl').value.trim(),
      gallery: $('#prodGallery').value.trim(),
      finish: $('#prodFinish').value.trim() || 'As shown',
      material: $('#prodMaterial').value.trim() || 'Powder-Coated Steel & Tempered Glass',
      dimensions: $('#prodDimensions').value.trim() || 'Standard',
      weight: $('#prodWeight').value.trim() || '12 kg',
      warranty: $('#prodWarranty').value.trim() || '1 Year Warranty',
      status: $('#prodStatus').value || 'Published',
      short: $('#prodShort').value.trim(),
      description: $('#prodDesc').value.trim()
    };
    const res = await apiReq('products', item);
    if (res && res.ok && Array.isArray(res.products)) {
      products = res.products;
      renderProducts();
      renderCategories();
      $('#productEditor').hidden = true;
      toast(idx >= 0 ? 'Product updated in MySQL Database!' : 'New product saved to MySQL Database!');
    } else {
      toast('Error saving product to MySQL database.');
    }
  });

  function renderProducts() {
    const q = ($('#productSearch')?.value || '').toLowerCase();
    const catF = $('#productCatFilter')?.value || '';
    const filtered = products.map((p, i) => ({ p, i })).filter(({ p }) => {
      const matchQ = !q || `${p.name} ${p.sku || ''} ${p.category || ''} ${p.finish || ''}`.toLowerCase().includes(q);
      const matchCat = !catF || p.category === catF;
      return matchQ && matchCat;
    });
    if ($('#prodTableCount')) $('#prodTableCount').textContent = filtered.length;
    if ($('#productCount')) $('#productCount').textContent = products.length;
    if ($('#sideProdBadge')) $('#sideProdBadge').textContent = products.length;

    if ($('#productsRows')) {
      $('#productsRows').innerHTML = filtered.map(({ p, i }) => {
        const effPrice = p.salePrice && p.salePrice < p.price ? p.salePrice : p.price;
        return `<tr>
          <td>
            <div class="prod-cell">
              <img class="prod-thumb" src="${esc(p.image)}" alt="${esc(p.name)}">
              <div class="prod-meta">
                <strong>${esc(p.name)}</strong>
                <small>SKU: ${esc(p.sku || 'DEC-101')} · ${esc(p.dimensions || 'Standard')} · ${esc(p.badge || 'DECORLY EDIT')}</small>
              </div>
            </div>
          </td>
          <td><b>${esc(p.category)}</b></td>
          <td><strong>PKR ${Number(effPrice).toLocaleString('en-PK')}</strong></td>
          <td>
            <b>${p.stock} pcs</b><br>
            <span class="pill ${p.stock > 5 ? 'green' : p.stock > 0 ? '' : 'red'}">${p.stock > 5 ? 'In stock' : p.stock > 0 ? 'Low stock' : 'Out of stock'}</span>
          </td>
          <td><span class="pill ${p.status === 'Draft' ? '' : 'green'}">${esc(p.status || 'Published')}</span></td>
          <td>
            <div class="actions">
              <button class="btn light small" data-edit-prod="${i}">✎ Edit</button>
              <a class="btn light small" href="../product?slug=${encodeURIComponent(p.slug)}" target="_blank">↗ View</a>
              <button class="btn danger small" data-delete="${i}">✕</button>
            </div>
          </td>
        </tr>`;
      }).join('') || '<tr><td colspan="6" class="empty">No products in MySQL database.</td></tr>';
    }

    if ($('#inventoryRows')) {
      $('#inventoryRows').innerHTML = products.map((p, i) => `<tr>
        <td>
          <div class="prod-cell">
            <img class="prod-thumb" src="${esc(p.image)}" alt="">
            <strong>${esc(p.name)}</strong>
          </div>
        </td>
        <td><input value="${esc(p.sku || ('DC-' + String(i + 101)))}" data-inv-sku="${i}"></td>
        <td>${esc(p.category)}</td>
        <td>
          <div class="inv-step-wrap">
            <button type="button" class="btn light small" data-inv-step="${i}" data-delta="-1">−</button>
            <input type="number" min="0" value="${p.stock}" data-inv-stock="${i}">
            <button type="button" class="btn light small" data-inv-step="${i}" data-delta="1">+</button>
          </div>
        </td>
        <td><span class="pill ${p.stock > 5 ? 'green' : p.stock > 0 ? '' : 'red'}">${p.stock > 5 ? 'Healthy' : p.stock > 0 ? 'Low stock' : 'Restock needed'}</span></td>
        <td><button type="button" class="btn gold small" data-inv-save="${i}">Save</button></td>
      </tr>`).join('');
    }
  }
  renderProducts();
  $('#productSearch')?.addEventListener('input', renderProducts);
  $('#productCatFilter')?.addEventListener('change', renderProducts);

  $('#productsRows')?.addEventListener('click', async e => {
    const ed = e.target.closest('[data-edit-prod]');
    if (ed) { openProductEditor(+ed.dataset.editProd); return; }
    const del = e.target.closest('[data-delete]');
    if (del && confirm('Permanently delete this product from the MySQL database?')) {
      const victim = products[+del.dataset.delete];
      if (!victim) return;
      const res = await apiReq('products', { action: 'delete', db_id: victim.db_id, slug: victim.slug, id: victim.id });
      if (res && res.ok && Array.isArray(res.products)) {
        products = res.products;
        renderProducts();
        renderCategories();
        toast('Product permanently deleted from MySQL database!');
      }
    }
  });

  $('#inventoryRows')?.addEventListener('click', async e => {
    const step = e.target.closest('[data-inv-step]');
    if (step) {
      const idx = +step.dataset.invStep, d = +step.dataset.delta;
      const p = products[idx]; if (!p) return;
      const nextStock = Math.max(0, (Number(p.stock) || 0) + d);
      const res = await apiReq('products', { action: 'inventory', slug: p.slug, id: p.id, stock: nextStock, sku: p.sku });
      if (res && res.ok && Array.isArray(res.products)) {
        products = res.products;
        renderProducts();
        toast('Stock updated in MySQL to ' + nextStock + ' pcs.');
      }
      return;
    }
    const sv = e.target.closest('[data-inv-save]');
    if (sv) {
      const idx = +sv.dataset.invSave;
      const p = products[idx]; if (!p) return;
      const stInp = document.querySelector(`[data-inv-stock="${idx}"]`);
      const skuInp = document.querySelector(`[data-inv-sku="${idx}"]`);
      const nextStock = stInp ? Math.max(0, Number(stInp.value) || 0) : p.stock;
      const nextSku = skuInp ? skuInp.value.trim() : p.sku;
      const res = await apiReq('products', { action: 'inventory', slug: p.slug, id: p.id, stock: nextStock, sku: nextSku });
      if (res && res.ok && Array.isArray(res.products)) {
        products = res.products;
        renderProducts();
        toast('Inventory & SKU saved in MySQL for ' + p.name);
      }
    }
  });

  // =========================================================================
  // 2. CATEGORIES STUDIO — 100% MYSQL CRUD
  // =========================================================================
  function renderCategories() {
    if ($('#sideCatBadge')) $('#sideCatBadge').textContent = categoriesList.length;
    if (!$('#categoryRows')) return;
    $('#categoryRows').innerHTML = categoriesList.map((c, i) => {
      const prodCount = products.filter(p => p.category === c.name || p.catSlug === c.slug).length;
      return `<tr>
        <td>
          <div class="prod-cell">
            <img class="prod-thumb" src="${esc(c.image || '')}" alt="">
            <div class="prod-meta"><strong>${esc(c.name)}</strong><small>Slug: /category?slug=${esc(c.slug)}</small></div>
          </div>
        </td>
        <td><b>${esc(c.group || 'Tables')}</b></td>
        <td>${esc(c.subs || '—')}</td>
        <td><b>${prodCount} designs</b></td>
        <td><span class="pill ${c.status === 'Active' ? 'green' : ''}">${esc(c.status || 'Active')}</span></td>
        <td>
          <div class="actions">
            <button type="button" class="btn light small" data-edit-cat="${i}">✎ Edit</button>
            <button type="button" class="btn danger small" data-del-cat="${i}">✕</button>
          </div>
        </td>
      </tr>`;
    }).join('');
  }
  renderCategories();

  $('#catName')?.addEventListener('input', () => { if ($('#catEditIndex').value === '-1') $('#catSlug').value = slugify($('#catName').value); });
  $('#catImageFile')?.addEventListener('change', e => {
    const f = e.target.files?.[0]; if (!f) return;
    const r = new FileReader(); r.onload = ev => { $('#catImageUrl').value = String(ev.target.result || ''); $('#catImgPreview').innerHTML = '<img src="' + esc($('#catImageUrl').value) + '">'; }; r.readAsDataURL(f);
  });
  $('#addCategory')?.addEventListener('click', () => {
    $('#categoryEditor').hidden = false; $('#catFormTitle').textContent = 'Add New Category'; $('#categoryForm').reset(); $('#catEditIndex').value = '-1';
    $('#categoryEditor').scrollIntoView({ behavior: 'smooth' });
  });
  $('#cancelCatBtn')?.addEventListener('click', () => $('#categoryEditor').hidden = true);
  $('#categoryForm')?.addEventListener('submit', async e => {
    e.preventDefault();
    const item = {
      action: 'save',
      name: $('#catName').value.trim(),
      slug: $('#catSlug').value.trim() || slugify($('#catName').value),
      group: $('#catGroup').value,
      status: $('#catStatus').value,
      subs: $('#catSubs').value.trim(),
      image: $('#catImageUrl').value.trim(),
      desc: $('#catDesc').value.trim()
    };
    const res = await apiReq('categories', item);
    if (res && res.ok && Array.isArray(res.categories)) {
      categoriesList = res.categories;
      renderCategories();
      $('#categoryEditor').hidden = true;
      toast('Category saved to MySQL database!');
    }
  });
  $('#categoryRows')?.addEventListener('click', async e => {
    const ed = e.target.closest('[data-edit-cat]');
    if (ed) {
      const idx = +ed.dataset.editCat, c = categoriesList[idx]; if (!c) return;
      $('#categoryEditor').hidden = false; $('#catFormTitle').textContent = 'Edit Category: ' + c.name; $('#catEditIndex').value = String(idx);
      $('#catName').value = c.name; $('#catSlug').value = c.slug; $('#catGroup').value = c.group || 'Tables'; $('#catStatus').value = c.status || 'Active';
      $('#catSubs').value = c.subs || ''; $('#catImageUrl').value = c.image || ''; $('#catDesc').value = c.desc || '';
      if (c.image) $('#catImgPreview').innerHTML = '<img src="' + esc(c.image) + '">';
      $('#categoryEditor').scrollIntoView({ behavior: 'smooth' }); return;
    }
    const del = e.target.closest('[data-del-cat]');
    if (del && confirm('Delete this category from MySQL database?')) {
      const c = categoriesList[+del.dataset.delCat]; if (!c) return;
      const res = await apiReq('categories', { action: 'delete', slug: c.slug });
      if (res && res.ok && Array.isArray(res.categories)) {
        categoriesList = res.categories;
        renderCategories();
        toast('Category deleted from MySQL database.');
      }
    }
  });

  // =========================================================================
  // 3. ORDERS & INVOICES — 100% MYSQL CRUD
  // =========================================================================
  function renderOrderFulfillmentBars() {
    const box = $('#orderStatusBars'); if (!box) return;
    const total = Math.max(1, orders.length);
    if ($('#funnelTotalText')) $('#funnelTotalText').textContent = orders.length + ' total orders';
    const statuses = [
      { name: 'Delivered', color: '#1f8b55' }, { name: 'Processing', color: '#2563eb' },
      { name: 'Shipped', color: '#d5b77a' }, { name: 'Pending', color: '#b97316' }, { name: 'Cancelled', color: '#c03636' }
    ];
    box.innerHTML = statuses.map(st => {
      const count = orders.filter(o => o.status === st.name).length;
      const pct = Math.round((count / total) * 100);
      return `<div class="fbar-row"><div class="fbar-label"><span>${st.name}</span><span>${count} (${pct}%)</span></div><div class="fbar-track"><div class="fbar-fill" style="width:${pct}%;background:${st.color}"></div></div></div>`;
    }).join('');
  }

  function renderOrdersTable() {
    const pillClass = s => s === 'Delivered' ? 'green' : (s === 'Processing' || s === 'Shipped') ? 'blue' : s === 'Cancelled' ? 'red' : '';
    if ($('#ordersRows')) {
      $('#ordersRows').innerHTML = orders.map((o, i) => `<tr>
        <td><b>${esc(o.id)}</b></td>
        <td><strong>${esc(o.customer)}</strong><br><small>${esc(o.city || 'Pakistan')} · ${esc(o.phone || '')}</small></td>
        <td>${esc(o.date)}</td>
        <td><span class="pill blue">${esc(o.payment || 'COD')}</span></td>
        <td><b>PKR ${Number(o.total || 0).toLocaleString('en-PK')}</b></td>
        <td><span class="pill ${pillClass(o.status)}">${esc(o.status)}</span></td>
        <td>
          <select data-order="${i}">
            ${['Pending','Processing','Shipped','Delivered','Cancelled'].map(s => `<option ${o.status === s ? 'selected' : ''}>${s}</option>`).join('')}
          </select>
        </td>
        <td>
          <div class="actions">
            <button type="button" class="btn light small" data-view-order="${i}">📄 Invoice</button>
            <button type="button" class="btn danger small" data-del-order="${i}">✕</button>
          </div>
        </td>
      </tr>`).join('') || '<tr><td colspan="8" class="empty">No orders in MySQL database.</td></tr>';
    }

    if ($('#recentOrders')) {
      $('#recentOrders').innerHTML = orders.slice(0, 5).map((o, i) => `<tr>
        <td><b>${esc(o.id)}</b></td>
        <td>${esc(o.customer)}</td>
        <td>PKR ${Number(o.total || 0).toLocaleString('en-PK')}</td>
        <td><span class="pill ${pillClass(o.status)}">${esc(o.status)}</span></td>
        <td><button type="button" class="btn light small" data-view-order="${i}">View</button></td>
      </tr>`).join('');
    }

    if ($('#orderCount')) $('#orderCount').textContent = orders.length;
    if ($('#sideOrdBadge')) $('#sideOrdBadge').textContent = orders.length;
    const totalRev = orders.filter(o => o.status !== 'Cancelled').reduce((s, o) => s + (Number(o.total) || 0), 0);
    if ($('#kpiRevenue')) $('#kpiRevenue').textContent = 'PKR ' + totalRev.toLocaleString('en-PK');
    renderOrderFulfillmentBars();
  }
  renderOrdersTable();

  $('#ordersRows')?.addEventListener('change', async e => {
    if (e.target.dataset.order !== undefined) {
      const ordObj = orders[+e.target.dataset.order];
      if (!ordObj) return;
      const res = await apiReq('orders', { action: 'update_status', id: ordObj.id, status: e.target.value });
      if (res && res.ok && Array.isArray(res.orders)) {
        orders = res.orders;
        renderOrdersTable();
        toast('Order status updated in MySQL database.');
      }
    }
  });
  $('#ordersRows')?.addEventListener('click', async e => {
    const del = e.target.closest('[data-del-order]');
    if (del && confirm('Delete this order from MySQL database?')) {
      const ordObj = orders[+del.dataset.delOrder];
      if (!ordObj) return;
      const res = await apiReq('orders', { action: 'delete', id: ordObj.id });
      if (res && res.ok && Array.isArray(res.orders)) {
        orders = res.orders;
        renderOrdersTable();
        toast('Order deleted from MySQL database.');
      }
    }
  });

  $('#newManualOrderBtn')?.addEventListener('click', () => { $('#manualOrderEditor').hidden = false; $('#manualOrderEditor').scrollIntoView({ behavior: 'smooth' }); });
  $('#cancelManualOrder')?.addEventListener('click', () => $('#manualOrderEditor').hidden = true);
  $('#manualOrderForm')?.addEventListener('submit', async e => {
    e.preventDefault();
    const newOrd = {
      customer: $('#moName').value.trim(),
      phone: $('#moPhone').value.trim(),
      email: $('#moEmail').value.trim() || 'customer@decorly.pk',
      city: $('#moCity').value.trim(),
      address: $('#moAddress').value.trim(),
      date: new Date().toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }),
      total: Number($('#moTotal').value) || 0,
      payment: $('#moPayment').value,
      status: 'Processing',
      items: [{ name: $('#moProduct').value.trim(), qty: 1, price: Number($('#moTotal').value) || 0 }]
    };
    const res = await apiReq('orders', newOrd);
    if (res && res.ok && Array.isArray(res.orders)) {
      orders = res.orders;
      renderOrdersTable();
      e.target.reset();
      $('#manualOrderEditor').hidden = true;
      toast('Manual order saved to MySQL database!');
    }
  });

  function openOrderModal(idx) {
    const o = orders[idx]; if (!o) return;
    const modal = $('#orderDetailModal'), box = $('#orderModalContent');
    const items = Array.isArray(o.items) && o.items.length ? o.items : [{ name: 'DECORLY Curated Furniture Order', qty: 1, price: o.total }];
    box.innerHTML = `
      <div>
        <div>
          <span class="eyebrow">OFFICIAL DECORLY ORDER INVOICE</span>
          <h2>Order ${esc(o.id)}</h2>
          <span class="muted">Placed on ${esc(o.date)} · Payment: <b>${esc(o.payment || 'Cash on Delivery')}</b></span>
        </div>
        <div class="actions">
          <button type="button" class="btn gold small" data-decorly-print="1">🖨️ Print Invoice</button>
          <button type="button" class="btn light small" id="closeOrderModalBtn">✕ Close</button>
        </div>
      </div>
      <div class="fields">
        <div><small class="muted">CUSTOMER DETAILS</small><strong>${esc(o.customer)}</strong><span>${esc(o.email || '')} · ${esc(o.phone || '')}</span></div>
        <div><small class="muted">DELIVERY ADDRESS</small><strong>${esc(o.address || 'Standard Doorstep Delivery')}</strong><span>${esc(o.city || 'Pakistan')}</span></div>
      </div>
      <div class="tablewrap">
        <table>
          <thead><tr><th>Furniture Item</th><th>Qty</th><th>Unit Price</th><th>Line Total</th></tr></thead>
          <tbody>
            ${items.map(it => `<tr><td><b>${esc(it.name)}</b></td><td>${it.qty || 1}</td><td>PKR ${Number(it.price || o.total).toLocaleString('en-PK')}</td><td><b>PKR ${Number((it.price || o.total) * (it.qty || 1)).toLocaleString('en-PK')}</b></td></tr>`).join('')}
          </tbody>
        </table>
      </div>
      <div>
        <span class="pill green">Fulfillment Status: ${esc(o.status)}</span>
        <div>Grand Total: PKR ${Number(o.total || 0).toLocaleString('en-PK')}</div>
      </div>`;
    modal.classList.add('open');
    $('#closeOrderModalBtn')?.addEventListener('click', () => modal.classList.remove('open'));
  }
  document.addEventListener('click', e => {
    const btn = e.target.closest('[data-view-order]');
    if (btn) openOrderModal(+btn.dataset.viewOrder);
    if (e.target.id === 'orderDetailModal') $('#orderDetailModal').classList.remove('open');
  });

  // =========================================================================
  // 4. CUSTOMERS DIRECTORY — 100% MYSQL CRUD
  // =========================================================================
  function renderCustomers() {
    if ($('#customerCountKpi')) $('#customerCountKpi').textContent = customersList.length;
    if ($('#sideCustBadge')) $('#sideCustBadge').textContent = customersList.length;
    if (!$('#customerRows')) return;
    $('#customerRows').innerHTML = customersList.map((c, i) => `<tr>
      <td><b>${esc(c.name)}</b></td>
      <td>${esc(c.email)}<br><small>${esc(c.phone || '—')}</small></td>
      <td>${esc(c.city || 'Pakistan')}</td>
      <td><b>${c.orders || 0}</b></td>
      <td><b>PKR ${Number(c.spent || 0).toLocaleString('en-PK')}</b></td>
      <td><span class="pill ${c.type === 'VIP' ? '' : c.type === 'Returning' ? 'green' : 'blue'}">${esc(c.type || 'Returning')}</span></td>
      <td>
        <div class="actions">
          <button type="button" class="btn light small" data-edit-cust="${i}">✎ Edit</button>
          <button type="button" class="btn danger small" data-del-cust="${i}">✕</button>
        </div>
      </td>
    </tr>`).join('') || '<tr><td colspan="7" class="empty">No registered customers in MySQL database.</td></tr>';
  }
  renderCustomers();
  $('#newCustomerBtn')?.addEventListener('click', () => { $('#customerEditor').hidden = false; $('#customerForm').reset(); $('#custEditIndex').value = '-1'; });
  $('#cancelCustomerBtn')?.addEventListener('click', () => $('#customerEditor').hidden = true);
  $('#customerForm')?.addEventListener('submit', async e => {
    e.preventDefault();
    const idx = +$('#custEditIndex').value;
    const item = {
      action: 'save',
      name: $('#custName').value.trim(),
      email: $('#custEmail').value.trim(),
      phone: $('#custPhone').value.trim(),
      city: $('#custCity').value.trim() || 'Lahore',
      type: $('#custType').value,
      spent: Number($('#custSpent').value) || 0,
      orders: idx >= 0 && customersList[idx] ? customersList[idx].orders : 1
    };
    const res = await apiReq('customers', item);
    if (res && res.ok && Array.isArray(res.customers)) {
      customersList = res.customers;
      renderCustomers();
      $('#customerEditor').hidden = true;
      toast('Customer record saved to MySQL database!');
    }
  });
  $('#customerRows')?.addEventListener('click', async e => {
    const ed = e.target.closest('[data-edit-cust]');
    if (ed) {
      const idx = +ed.dataset.editCust, c = customersList[idx]; if (!c) return;
      $('#customerEditor').hidden = false; $('#custEditIndex').value = String(idx);
      $('#custName').value = c.name; $('#custEmail').value = c.email; $('#custPhone').value = c.phone || ''; $('#custCity').value = c.city || ''; $('#custType').value = c.type || 'Returning'; $('#custSpent').value = c.spent || 0;
      return;
    }
    const del = e.target.closest('[data-del-cust]');
    if (del && confirm('Remove customer record from MySQL database?')) {
      const c = customersList[+del.dataset.delCust]; if (!c) return;
      const res = await apiReq('customers', { action: 'delete', email: c.email });
      if (res && res.ok && Array.isArray(res.customers)) {
        customersList = res.customers;
        renderCustomers();
        toast('Customer removed from MySQL database.');
      }
    }
  });

  // =========================================================================
  // 5. COUPONS STUDIO — 100% MYSQL CRUD
  // =========================================================================
  function renderCoupons() {
    if (!$('#couponRows')) return;
    $('#couponRows').innerHTML = couponsList.map((cp, i) => `<tr>
      <td><b>${esc(cp.code)}</b></td>
      <td>${cp.type === 'fixed' ? 'Fixed Amount (PKR)' : 'Percentage (%)'}</td>
      <td><b>${cp.type === 'fixed' ? 'PKR ' + Number(cp.value).toLocaleString('en-PK') : cp.value + '% OFF'}</b></td>
      <td>PKR ${Number(cp.min || 0).toLocaleString('en-PK')}</td>
      <td>${esc(cp.expiry || '2026-12-31')}</td>
      <td><span class="pill ${cp.status === 'Active' ? 'green' : ''}">${esc(cp.status)}</span></td>
      <td>
        <div class="actions">
          <button type="button" class="btn light small" data-edit-cp="${i}">✎ Edit</button>
          <button type="button" class="btn danger small" data-del-cp="${i}">✕</button>
        </div>
      </td>
    </tr>`).join('') || '<tr><td colspan="7" class="empty">No coupons in MySQL database.</td></tr>';
  }
  renderCoupons();
  $('#newCoupon')?.addEventListener('click', () => { $('#couponEditor').hidden = false; $('#couponForm').reset(); $('#couponEditIndex').value = '-1'; });
  $('#cancelCouponBtn')?.addEventListener('click', () => $('#couponEditor').hidden = true);
  $('#couponForm')?.addEventListener('submit', async e => {
    e.preventDefault();
    const item = {
      action: 'save',
      code: $('#cpCode').value.trim().toUpperCase(),
      type: $('#cpType').value,
      value: Number($('#cpValue').value) || 10,
      min: Number($('#cpMin').value) || 0,
      expiry: $('#cpExpiry').value,
      status: $('#cpStatus').value
    };
    const res = await apiReq('coupons', item);
    if (res && res.ok && Array.isArray(res.coupons)) {
      couponsList = res.coupons;
      renderCoupons();
      $('#couponEditor').hidden = true;
      toast('Coupon ' + item.code + ' saved to MySQL database!');
    }
  });
  $('#couponRows')?.addEventListener('click', async e => {
    const ed = e.target.closest('[data-edit-cp]');
    if (ed) {
      const idx = +ed.dataset.editCp, cp = couponsList[idx]; if (!cp) return;
      $('#couponEditor').hidden = false; $('#couponEditIndex').value = String(idx);
      $('#cpCode').value = cp.code; $('#cpType').value = cp.type; $('#cpValue').value = cp.value; $('#cpMin').value = cp.min || 0; $('#cpExpiry').value = cp.expiry || '2026-12-31'; $('#cpStatus').value = cp.status || 'Active';
      return;
    }
    const del = e.target.closest('[data-del-cp]');
    if (del && confirm('Delete this coupon code from MySQL?')) {
      const cp = couponsList[+del.dataset.delCp]; if (!cp) return;
      const res = await apiReq('coupons', { action: 'delete', code: cp.code });
      if (res && res.ok && Array.isArray(res.coupons)) {
        couponsList = res.coupons;
        renderCoupons();
        toast('Coupon deleted from MySQL database.');
      }
    }
  });

  // =========================================================================
  // 6. REVIEWS & CUSTOMER ENQUIRIES — 100% MYSQL CRUD
  // =========================================================================
  function renderReviews() {
    if ($('#reviewRows')) {
      $('#reviewRows').innerHTML = reviewsList.map((r, i) => `<tr>
        <td><b>${esc(r.customer)}</b></td>
        <td>${esc(r.product)}</td>
        <td>${'★'.repeat(r.rating || 5)}${'☆'.repeat(5 - (r.rating || 5))}</td>
        <td>
          <div>${esc(r.comment)}</div>
          ${r.reply ? `<small>↳ DECORLY Reply: ${esc(r.reply)}</small>` : ''}
        </td>
        <td><span class="pill ${r.status === 'Approved' ? 'green' : ''}">${esc(r.status)}</span></td>
        <td>
          <div class="actions">
            ${r.status !== 'Approved' ? `<button type="button" class="btn gold small" data-approve-rev="${i}">✓ Approve</button>` : ''}
            <button type="button" class="btn light small" data-edit-rev="${i}">✎ Edit / Reply</button>
            <button type="button" class="btn danger small" data-del-rev="${i}">✕</button>
          </div>
        </td>
      </tr>`).join('') || '<tr><td colspan="6" class="empty">No reviews in MySQL database.</td></tr>';
    }

    if ($('#enquiryRows')) {
      $('#enquiryRows').innerHTML = enquiriesList.length ? enquiriesList.map((enq, i) => `<tr>
        <td>${esc(enq.date || 'Today')}</td>
        <td><b>${esc(enq.name)}</b><br><small>${esc(enq.email)}</small></td>
        <td>${esc(enq.phone || '—')}<br><span class="pill blue">${esc(enq.topic || 'General')}</span></td>
        <td>${esc(enq.message)}</td>
        <td><button type="button" class="btn danger small" data-del-enq="${i}">Archive</button></td>
      </tr>`).join('') : '<tr><td colspan="5" class="empty">No customer contact messages yet.</td></tr>';
    }
  }
  renderReviews();

  $('#newReviewBtn')?.addEventListener('click', () => { $('#reviewEditor').hidden = false; $('#reviewForm').reset(); $('#revEditIndex').value = '-1'; });
  $('#cancelReviewBtn')?.addEventListener('click', () => $('#reviewEditor').hidden = true);
  $('#reviewForm')?.addEventListener('submit', async e => {
    e.preventDefault();
    const idx = +$('#revEditIndex').value;
    const existing = idx >= 0 ? reviewsList[idx] : null;
    const item = {
      action: 'save_review',
      id: existing ? existing.id : 0,
      customer: $('#revCustomer').value.trim(),
      product: $('#revProduct').value.trim(),
      rating: Number($('#revRating').value) || 5,
      status: $('#revStatus').value,
      comment: $('#revComment').value.trim(),
      reply: $('#revReply').value.trim()
    };
    const res = await apiReq('reviews', item);
    if (res && res.ok && Array.isArray(res.reviews)) {
      reviewsList = res.reviews;
      renderReviews();
      $('#reviewEditor').hidden = true;
      toast('Review saved to MySQL database!');
    }
  });
  $('#reviewRows')?.addEventListener('click', async e => {
    const ap = e.target.closest('[data-approve-rev]');
    if (ap) {
      const r = reviewsList[+ap.dataset.approveRev]; if (!r) return;
      r.status = 'Approved';
      const res = await apiReq('reviews', Object.assign({ action: 'save_review' }, r));
      if (res && res.ok && Array.isArray(res.reviews)) {
        reviewsList = res.reviews;
        renderReviews();
        toast('Review approved in MySQL!');
      }
      return;
    }
    const ed = e.target.closest('[data-edit-rev]');
    if (ed) {
      const idx = +ed.dataset.editRev, r = reviewsList[idx]; if (!r) return;
      $('#reviewEditor').hidden = false; $('#revEditIndex').value = String(idx);
      $('#revCustomer').value = r.customer; $('#revProduct').value = r.product; $('#revRating').value = r.rating || 5; $('#revStatus').value = r.status || 'Approved'; $('#revComment').value = r.comment; $('#revReply').value = r.reply || '';
      return;
    }
    const del = e.target.closest('[data-del-rev]');
    if (del && confirm('Delete this review from MySQL?')) {
      const r = reviewsList[+del.dataset.delRev]; if (!r) return;
      const res = await apiReq('reviews', { action: 'delete_review', id: r.id });
      if (res && res.ok && Array.isArray(res.reviews)) {
        reviewsList = res.reviews;
        renderReviews();
        toast('Review deleted from MySQL.');
      }
    }
  });
  $('#enquiryRows')?.addEventListener('click', async e => {
    const del = e.target.closest('[data-del-enq]');
    if (del) {
      const victim = enquiriesList[+del.dataset.delEnq]; if (!victim) return;
      const res = await apiReq('reviews', { action: 'delete_enquiry', id: victim.id });
      if (res && res.ok && Array.isArray(res.enquiries)) {
        enquiriesList = res.enquiries;
        renderReviews();
        toast('Enquiry deleted from MySQL.');
      }
    }
  });

  // =========================================================================
  // 7. BANNERS, PAYMENTS, SHIPPING & STORE SETTINGS — 100% MYSQL CRUD
  // =========================================================================
  $('#saveBanner')?.addEventListener('click', async () => {
    const b = { eyebrow: $('#bannerEyebrow').value, title: $('#bannerTitle').value, button: $('#bannerButton').value, link: $('#bannerLink').value, image: $('#bannerImageUrl').value, desc: $('#bannerDesc').value, placement: $('#bannerPlacement').value, status: $('#bannerStatus').value };
    await apiReq('settings', { key: 'banner', value: b });
    toast('Campaign banner saved to MySQL database!');
  });
  $('#savePayments')?.addEventListener('click', async () => {
    const p = { cod: $('#cod').value, bank: $('#bank').value, bankName: $('#bankName').value, bankTitle: $('#bankTitle').value, bankIban: $('#bankIban').value, walletNum: $('#walletNum').value, gateway: $('#gateway').value, currency: $('#currency').value };
    await apiReq('settings', { key: 'payments', value: p });
    toast('Payment methods & IBAN details saved to MySQL!');
  });
  $('#saveShipping')?.addEventListener('click', async () => {
    const s = { fee: Number($('#shipFee').value) || 350, threshold: Number($('#shipThreshold').value) || 25000, time: $('#shipTime').value, enabled: $('#shipEnabled').value, courier: $('#shipCourier').value, regions: $('#shipRegions').value };
    await apiReq('settings', { key: 'shipping', value: s });
    toast('Shipping rules saved to MySQL database!');
  });
  $('#saveSettings')?.addEventListener('click', async () => {
    if (!$('#settingsForm').reportValidity()) return;
    const ids = ['storeName','supportEmail','storePhone','storeCurrency','timezone','storeStatus','storeAddress','notifications','lowStock'];
    const data = {}; ids.forEach(id => data[id] = $('#' + id).value);
    await apiReq('settings', { key: 'general', value: data });
    toast('Store settings saved to MySQL Database.');
  });

  // =========================================================================
  // 8. BLOG POSTS STUDIO — 100% MYSQL CRUD
  // =========================================================================
  function renderBlogPosts() {
    const rows = document.getElementById('blogRows'); if (!rows) return;
    rows.innerHTML = blogPosts.map(p => `<tr>
      <td>
        <div class="prod-cell">
          <img class="prod-thumb" src="${esc(p.image || '')}" alt="">
          <div><div class="post-title">${esc(p.title)}</div><div class="post-excerpt">${esc(p.excerpt)}</div></div>
        </div>
      </td>
      <td>${esc(p.author)}</td><td>${esc(p.category)}</td><td>${esc(p.updated || '—')}</td>
      <td><span class="pill ${p.status === 'Published' ? 'green' : ''}">${esc(p.status)}</span></td>
      <td><div class="actions"><button type="button" class="btn small light" data-edit-blog="${esc(p.id)}">✎ Edit</button><button type="button" class="btn small danger" data-delete-blog="${esc(p.id)}">✕</button></div></td>
    </tr>`).join('');
    if (document.getElementById('postCount')) document.getElementById('postCount').textContent = blogPosts.length + ' post' + (blogPosts.length === 1 ? '' : 's');
    if (document.getElementById('blogEmpty')) document.getElementById('blogEmpty').style.display = blogPosts.length ? 'none' : 'block';
  }
  function openBlogForm(p) {
    document.getElementById('postEditor').style.display = 'block';
    document.getElementById('postFormTitle').textContent = p ? 'Edit blog post' : 'Create blog post';
    document.getElementById('postId').value = p?.id || '';
    document.getElementById('postTitle').value = p?.title || '';
    document.getElementById('postSlug').value = p?.slug || '';
    document.getElementById('postAuthor').value = p?.author || 'DECORLY Team';
    document.getElementById('postCategory').value = p?.category || 'Home Styling';
    document.getElementById('postStatus').value = p?.status || 'Published';
    document.getElementById('postImage').value = p?.image || '';
    document.getElementById('postExcerpt').value = p?.excerpt || '';
    document.getElementById('postContent').value = p?.content || '';
    document.getElementById('postEditor').scrollIntoView({ behavior: 'smooth', block: 'start' });
  }
  function closeBlogForm() {
    document.getElementById('postForm')?.reset();
    if (document.getElementById('postId')) document.getElementById('postId').value = '';
    if (document.getElementById('postEditor')) document.getElementById('postEditor').style.display = 'none';
  }
  document.addEventListener('click', async e => {
    if (e.target.closest('#newPost')) openBlogForm(null);
    if (e.target.closest('#cancelPost') || e.target.closest('#cancelPost2')) closeBlogForm();
    const edit = e.target.closest('[data-edit-blog]');
    if (edit) { const p = blogPosts.find(x => x.id === edit.dataset.editBlog); if (p) openBlogForm(p); }
    const del = e.target.closest('[data-delete-blog]');
    if (del) {
      const p = blogPosts.find(x => x.id === del.dataset.deleteBlog);
      if (p && confirm('Delete “' + p.title + '” from MySQL database?')) {
        const res = await apiReq('blog', { action: 'delete', id: p.id, slug: p.slug });
        if (res && res.ok && Array.isArray(res.posts)) {
          blogPosts = res.posts;
          renderBlogPosts();
          toast('Blog post deleted from MySQL.');
        }
      }
    }
  });
  document.getElementById('postForm')?.addEventListener('submit', async e => {
    e.preventDefault();
    const id = document.getElementById('postId').value || ('post-' + Date.now());
    const item = {
      action: 'save',
      id,
      title: document.getElementById('postTitle').value.trim(),
      slug: slugify(document.getElementById('postSlug').value || document.getElementById('postTitle').value),
      author: document.getElementById('postAuthor').value.trim(),
      category: document.getElementById('postCategory').value,
      status: document.getElementById('postStatus').value,
      image: document.getElementById('postImage').value.trim(),
      excerpt: document.getElementById('postExcerpt').value.trim(),
      content: document.getElementById('postContent').value.trim(),
      updated: new Date().toISOString().slice(0, 10)
    };
    const res = await apiReq('blog', item);
    if (res && res.ok && Array.isArray(res.posts)) {
      blogPosts = res.posts;
      closeBlogForm();
      renderBlogPosts();
      toast('Blog post saved to MySQL database!');
    }
  });
  renderBlogPosts();

  document.addEventListener('click', function(e) {
    var pr = e.target.closest('[data-decorly-print]');
    if (pr) { e.preventDefault(); window.print(); }
  });
})();
