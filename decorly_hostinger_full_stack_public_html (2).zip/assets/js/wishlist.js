(function(){
  var pre = document.getElementById('decorly-preloader');
  var bar = document.getElementById('decorlyLoaderBar');
  var pct = document.getElementById('decorlyLoaderPct');
  if(!pre) return;
  var p = 12, done = false;
  var iv = setInterval(function(){
    if(done) return;
    p += Math.max(4, Math.round((92 - p) * 0.28));
    if(p > 92) p = 92;
    if(bar) bar.style.width = p + '%';
    if(pct) pct.textContent = p + '%';
  }, 45);
  function finish(){
    if(done) return;
    done = true;
    clearInterval(iv);
    if(bar) bar.style.width = '100%';
    if(pct) pct.textContent = '100%';
    setTimeout(function(){
      pre.classList.add('is-loaded');
    }, 140);
  }
  if(document.readyState === 'complete' || document.readyState === 'interactive'){
    setTimeout(finish, 260);
  } else {
    window.addEventListener('DOMContentLoaded', function(){ setTimeout(finish, 280); });
    window.addEventListener('load', finish);
  }
  setTimeout(finish, 950);
})();

(function(){
  'use strict';
  const $ = s => document.querySelector(s);
  const $$ = s => [...document.querySelectorAll(s)];
  const load = (k, def=[]) => { try { const d = JSON.parse(localStorage.getItem(k) || 'null'); return d ?? def; } catch { return def; } };
  const save = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); return true; } catch { return false; } };
  const money = v => 'Rs ' + Math.round(Number(v || 0)).toLocaleString('en-PK');
  const clean = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));

  function getBoot() {
    return window.DECORLY_SERVER_BOOT || {};
  }

  function norm(p) {
    const dbProd = window.DecorlyShop?.product(p.slug || p.id) || {};
    const pr = Number(p.price) || window.DecorlyShop?.price(p.slug) || Number(dbProd.price) || 0;
    const slug = p.slug || dbProd.slug || String(p.id || '');
    return {
      id: p.id ?? slug,
      slug,
      name: p.name || dbProd.name || 'DECORLY Furniture',
      image: p.image || dbProd.image || '',
      price: pr,
      qty: Math.max(1, Number(p.qty ?? p.quantity) || 1),
      finish: p.finish || 'Signature Finish',
      url: 'product?slug=' + encodeURIComponent(slug)
    };
  }

  function getShippingRules() {
    const boot = getBoot();
    const s = (boot.settings && boot.settings.shipping) ? boot.settings.shipping : { fee: 350, threshold: 25000 };
    return { fee: Number(s.fee ?? 350), threshold: Number(s.threshold ?? 25000) };
  }

  function getActiveCoupons() {
    const boot = getBoot();
    return Array.isArray(boot.coupons) ? boot.coupons : [];
  }

  function cart() {
    const raw = load('decorly_cart', []);
    return (Array.isArray(raw) ? raw : []).map(norm);
  }
  function setCart(a) {
    save('decorly_cart', a);
    count();
    document.dispatchEvent(new Event('decorly:updated'));
  }
  function add(p) {
    let a = cart(), o = norm(p), old = a.find(x => String(x.id) === String(o.id) && x.finish === o.finish);
    if (old) old.qty += o.qty; else a.push(o);
    setCart(a);
  }
  function wishlist() {
    const raw = load('decorly_wishlist', []);
    return (Array.isArray(raw) ? raw : []).map(norm);
  }
  function setWishlist(a) {
    save('decorly_wishlist', a);
    document.dispatchEvent(new Event('decorly:updated'));
  }
  function count() {
    const c = cart().reduce((n, p) => n + p.qty, 0);
    $$('#cartCount,[data-cart-count]').forEach(el => el.textContent = c);
  }

  function empty(kind) {
    return `<div class="empty-state">
      <div class="empty-symbol">${kind === 'wishlist' ? '♡' : '♧'}</div>
      <h2>${kind === 'wishlist' ? 'Your wishlist is waiting' : 'Your shopping bag is currently empty'}</h2>
      <p>${kind === 'wishlist' ? 'Save furniture you love and find it here anytime.' : 'Explore our curated tables, tea trolleys and storage racks to begin.'}</p>
      <div class="empty-actions-row">
        <a class="flow-btn gold" href="shop">Explore Furniture Catalog ↗</a>
      </div>
    </div>`;
  }

  function renderWishlist() {
    const dest = $('#wishlistContent');
    if (!dest) return;
    let w = wishlist();
    if (!w.length) { dest.innerHTML = empty('wishlist'); return; }
    dest.innerHTML = `<div class="wish-cards">${w.map((p, i) => `<article class="wish-card">
      <a class="wish-photo" href="${clean(p.url)}"><img src="${clean(p.image)}" alt="${clean(p.name)}" loading="lazy"></a>
      <div class="wish-detail">
        <small>THE DECORLY EDIT</small>
        <h3><a href="${clean(p.url)}">${clean(p.name)}</a></h3>
        <strong class="money">${money(p.price)}</strong>
        <div class="wish-controls">
          <button type="button" data-move="${i}">Add to cart ↗</button>
          <button type="button" data-remove="${i}" aria-label="Remove ${clean(p.name)}">✕</button>
        </div>
        <button class="ar-card-button" type="button" data-ar="${clean(p.slug || p.id)}" aria-label="Open camera with ${clean(p.name)}"><span aria-hidden="true">⬡</span> Open Camera <span aria-hidden="true">↗</span></button>
      </div>
    </article>`).join('')}</div>`;
    dest.querySelectorAll('[data-remove]').forEach(b => b.onclick = () => { w.splice(+b.dataset.remove, 1); setWishlist(w); renderWishlist(); });
    dest.querySelectorAll('[data-move]').forEach(b => b.onclick = () => { let p = w[+b.dataset.move]; add(p); b.textContent = 'Added to Cart ✓'; });
  }

  function calculateTotals() {
    let a = cart();
    const subtotal = a.reduce((n, p) => n + (p.price * p.qty), 0);
    const items = a.reduce((n, p) => n + p.qty, 0);
    const shipRules = getShippingRules();
    const shipping = subtotal === 0 ? 0 : (subtotal >= shipRules.threshold ? 0 : shipRules.fee);

    let discount = 0, appliedCode = '';
    const savedCoupon = sessionStorage.getItem('decorly_applied_coupon') || '';
    if (savedCoupon && subtotal > 0) {
      const cp = getActiveCoupons().find(c => c.code.toUpperCase() === savedCoupon.toUpperCase() && c.status !== 'Expired');
      if (cp && subtotal >= (Number(cp.min) || 0)) {
        appliedCode = cp.code;
        discount = cp.type === 'fixed' ? Number(cp.value) : Math.round(subtotal * (Number(cp.value) / 100));
        if (discount > subtotal) discount = subtotal;
      }
    }
    const grandTotal = Math.max(0, subtotal - discount + shipping);
    return { subtotal, items, shipping, discount, appliedCode, grandTotal, freeThreshold: shipRules.threshold };
  }

  function cartRender() {
    const dest = $('#cartContent'), sum = $('#cartSummary');
    if (!dest || !sum) return;
    let a = cart();
    if (!a.length) {
      dest.innerHTML = empty('cart');
      sum.innerHTML = '<h2>Order summary</h2><p class="muted">Add a furniture design from the shop to view delivery &amp; promo calculations.</p>';
      return;
    }
    const t = calculateTotals();
    const remForFree = Math.max(0, t.freeThreshold - t.subtotal);
    dest.innerHTML = `<div class="flow-panel">
      <div class="cart-head-bar">
        <h2>Shopping Bag <span class="muted">(${t.items} item${t.items === 1 ? '' : 's'})</span></h2>
        <span class="free-ship-pill">
          ${remForFree === 0 ? '🎉 You unlocked FREE nationwide delivery!' : 'Add ' + money(remForFree) + ' more for FREE shipping!'}
        </span>
      </div>
      <div class="flow-list">` + a.map((p, i) => `<article class="lineitem">
        <a href="${clean(p.url)}"><img src="${clean(p.image)}" alt="${clean(p.name)}" loading="lazy"></a>
        <div>
          <h3><a href="${clean(p.url)}">${clean(p.name)}</a></h3>
          <p>Finish: <b>${clean(p.finish || 'Signature Finish')}</b> · Unit Price: ${money(p.price)}</p>
          <div class="line-actions">
            <div class="qty"><button type="button" data-minus="${i}">−</button><b>${p.qty}</b><button type="button" data-plus="${i}">+</button></div>
            <button type="button" class="text-action" data-delete="${i}">Remove</button>
          </div>
        </div>
        <strong class="money">${money(p.price * p.qty)}</strong>
      </article>`).join('') + '</div></div>';

    sum.innerHTML = `<h2>Order Summary</h2>
      <div class="summary-line"><span>Subtotal (${t.items} items)</span><strong>${money(t.subtotal)}</strong></div>
      <div class="summary-line"><span>Estimated Delivery</span><strong>${t.shipping === 0 ? 'FREE' : money(t.shipping)}</strong></div>
      ${t.discount > 0 ? `<div class="summary-line promo-line"><span>Promo (${clean(t.appliedCode)})</span><strong>− ${money(t.discount)}</strong></div>` : ''}
      <div class="coupon-box">
        <label>HAVE A PROMO COUPON?</label>
        <div class="coupon-row">
          <input id="cartCouponInput" value="${clean(t.appliedCode)}" placeholder="Enter coupon code...">
          <button type="button" id="applyCouponBtn">Apply</button>
        </div>
        <small id="couponFeedback"></small>
      </div>
      <div class="summary-line total"><span>Grand Total</span><strong>${money(t.grandTotal)}</strong></div>
      <a class="flow-btn gold full" href="checkout">Proceed to Checkout ↗</a>
      <a class="text-action" href="shop">← Continue shopping</a>`;

    dest.querySelectorAll('[data-plus]').forEach(b => b.onclick = () => { a[+b.dataset.plus].qty = Math.min(99, a[+b.dataset.plus].qty + 1); setCart(a); cartRender(); });
    dest.querySelectorAll('[data-minus]').forEach(b => b.onclick = () => { let p = a[+b.dataset.minus]; p.qty--; if (p.qty < 1) a.splice(+b.dataset.minus, 1); setCart(a); cartRender(); });
    dest.querySelectorAll('[data-delete]').forEach(b => b.onclick = () => { a.splice(+b.dataset.delete, 1); setCart(a); cartRender(); });

    $('#applyCouponBtn')?.addEventListener('click', () => {
      const code = ($('#cartCouponInput')?.value || '').trim().toUpperCase();
      const fb = $('#couponFeedback');
      if (!code) { sessionStorage.removeItem('decorly_applied_coupon'); cartRender(); return; }
      const cp = getActiveCoupons().find(c => c.code.toUpperCase() === code && c.status !== 'Expired');
      if (!cp) { if (fb) fb.textContent = 'Invalid or expired coupon code in database.'; return; }
      if (t.subtotal < (Number(cp.min) || 0)) { if (fb) fb.textContent = 'Minimum order of ' + money(cp.min) + ' required for ' + code + '.'; return; }
      sessionStorage.setItem('decorly_applied_coupon', code);
      cartRender();
    });
  }

  function checkout() {
    const form = $('#checkoutForm'), side = $('#checkoutSidebar');
    if (!form || !side) return;
    let a = cart();
    const user = getBoot().user;
    if (user) {
      if ($('#first') && !$('#first').value) $('#first').value = user.first || (user.name ? user.name.split(' ')[0] : '');
      if ($('#last') && !$('#last').value) $('#last').value = user.last || (user.name ? user.name.split(' ').slice(1).join(' ') : '');
      if ($('#email') && !$('#email').value) $('#email').value = user.email || '';
      if ($('#phone') && !$('#phone').value) $('#phone').value = user.phone || '';
      if ($('#city') && !$('#city').value && user.city) $('#city').value = user.city.split(',')[0].trim();
    }

    const t = calculateTotals();
    side.innerHTML = `<h2>Order Summary</h2>
      ${a.length ? a.map(p => `<div class="summary-line"><span>${clean(p.name)} × ${p.qty}</span><strong>${money(p.price * p.qty)}</strong></div>`).join('') : '<p class="muted">Your cart is empty.</p>'}
      <div class="summary-line"><span>Subtotal</span><strong>${money(t.subtotal)}</strong></div>
      <div class="summary-line"><span>Delivery Fee</span><strong>${t.shipping === 0 ? 'FREE' : money(t.shipping)}</strong></div>
      ${t.discount > 0 ? `<div class="summary-line"><span>Discount (${clean(t.appliedCode)})</span><strong>− ${money(t.discount)}</strong></div>` : ''}
      <div class="summary-line total"><span>Total Payable</span><strong>${money(t.grandTotal)}</strong></div>
      <p class="summary-note">Your order will be saved directly to the MySQL Database (orders &amp; order_items tables).</p>
      <a class="flow-btn line full" href="cart">← Edit Shopping Bag</a>`;

    const submit = $('#placeOrder');
    if (submit && !a.length) {
      submit.textContent = 'Add items to cart first';
      submit.disabled = true;
    }

    form.addEventListener('submit', async e => {
      e.preventDefault();
      if (!form.reportValidity() || !a.length) return;
      if (submit) { submit.disabled = true; submit.textContent = 'Saving Order to MySQL...'; }
      const payMethod = form.querySelector('input[name="paymentMethod"]:checked')?.value || 'Cash on Delivery (COD)';
      const fullName = ($('#first').value.trim() + ' ' + $('#last').value.trim()).trim();
      const payload = {
        customer: fullName,
        email: $('#email').value.trim(),
        phone: $('#phone').value.trim(),
        address: $('#address').value.trim(),
        city: $('#city').value.trim() + ', ' + ($('#province')?.value || 'Pakistan'),
        postcode: $('#postcode')?.value.trim() || '',
        notes: $('#orderNotes')?.value.trim() || '',
        date: new Date().toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }),
        subtotal: t.subtotal,
        shipping: t.shipping,
        discount: t.discount,
        coupon: t.appliedCode,
        total: t.grandTotal,
        payment: payMethod,
        status: 'Processing',
        items: a.map(it => ({ name: it.name, slug: it.slug, image: it.image, qty: it.qty, price: it.price, finish: it.finish }))
      };
      const res = await window.DecorlyAPI.request('orders', 'POST', payload);
      const ordId = (res && res.order_number) ? res.order_number : ('#DC-' + Date.now().toString().slice(-4));
      setCart([]);
      sessionStorage.removeItem('decorly_applied_coupon');
      location.href = 'order-confirmation?order=' + encodeURIComponent(ordId);
    });
  }

  function renderOrderConfirmationPage() {
    const box = $('#orderConfirmationContainer');
    if (!box) return;
    const qp = new URLSearchParams(location.search);
    const ordId = qp.get('order');
    const allOrders = Array.isArray(getBoot().orders) ? getBoot().orders : [];
    const ord = (ordId ? allOrders.find(o => o.id === ordId) : allOrders[0]) || allOrders[0];
    if (!ord) {
      box.innerHTML = `<div class="empty-state"><div class="empty-symbol">✓</div><h2>No recent order found</h2><p>Place an order through Checkout to view your itemized order receipt here.</p><a class="flow-btn gold" href="shop">Explore Furniture ↗</a></div>`;
      return;
    }
    if ($('#confHeroTitle')) $('#confHeroTitle').textContent = 'Order Confirmed · ' + ord.id;
    const items = Array.isArray(ord.items) ? ord.items : [];
    box.innerHTML = `
      <div class="flow-panel">
        <div class="conf-head-bar">
          <div>
            <span class="conf-badge">✓ ORDER SAVED IN MYSQL DATABASE</span>
            <h2>Order Reference: ${clean(ord.id)}</h2>
            <p class="muted">Placed on ${clean(ord.date)} · Payment Method: <b>${clean(ord.payment)}</b></p>
          </div>
          <div class="conf-actions">
            <button type="button" class="flow-btn line" data-decorly-print="1">🖨️ Print Receipt</button>
            <a class="flow-btn gold" href="my-account#orders">View in My Orders ↗</a>
          </div>
        </div>
        <div class="fields-2">
          <div>
            <small>CUSTOMER &amp; CONTACT</small>
            <strong>${clean(ord.customer)}</strong>
            <span>${clean(ord.email)} · ${clean(ord.phone)}</span>
          </div>
          <div>
            <small>DELIVERY DESTINATION</small>
            <strong>${clean(ord.address)}</strong>
            <span>${clean(ord.city)} ${clean(ord.postcode || '')}</span>
          </div>
        </div>
        <h3>Purchased Furniture Items</h3>
        <div class="flow-list">
          ${items.map(it => `<article class="lineitem">
            <img src="${clean(it.image)}" alt="${clean(it.name)}">
            <div>
              <h3>${clean(it.name)}</h3>
              <p>Quantity: <b>${it.qty || 1}</b> · Finish: ${clean(it.finish || 'Signature Finish')}</p>
            </div>
            <strong class="money">${money((it.price || 0) * (it.qty || 1))}</strong>
          </article>`).join('')}
        </div>
        <div class="conf-foot-bar">
          <a href="shop" class="text-action">← Continue Shopping on DECORLY</a>
          <div>Total Confirmed: <strong>${money(ord.total)}</strong></div>
        </div>
      </div>`;
  }

  // 100% MySQL Authentication (No localStorage user fallback!)
  function auth() {
    const form = $('#authForm');
    if (!form) return;
    const isSignup = document.body.dataset.page === 'signup';

    $('#toggleLoginPass')?.addEventListener('click', () => { const i = $('#password'); if (i) i.type = i.type === 'password' ? 'text' : 'password'; });
    $('#toggleSignupPass')?.addEventListener('click', () => {
      const i = $('#password'), c = $('#confirm');
      if (i) i.type = i.type === 'password' ? 'text' : 'password';
      if (c) c.type = c.type === 'password' ? 'text' : 'password';
    });

    $('#fillDemoBuyer')?.addEventListener('click', () => {
      if ($('#email')) $('#email').value = 'sara@decorly.com';
      if ($('#password')) $('#password').value = 'Customer@2026';
    });

    $('#forgotPassBtn')?.addEventListener('click', async () => {
      const em = prompt('Enter your registered email address to reset your password in the database:', '');
      if (!em) return;
      const newP = prompt('Enter your new password (minimum 6 characters):', '');
      if (!newP || newP.length < 6) {
        alert('Password must be at least 6 characters.');
        return;
      }
      const status = $('#authStatus');
      const res = await window.DecorlyAPI.request('auth.php?action=reset_password', 'POST', { email: em.trim(), new_password: newP });
      if (res && res.ok) {
        if (status) {
          status.textContent = '✓ Password updated in MySQL database for ' + res.email + '! You can now sign in.';
        }
        if ($('#email')) $('#email').value = res.email;
        if ($('#password')) $('#password').value = newP;
      } else {
        if (status) status.textContent = (res && res.error) ? res.error : 'Could not reset password. Please check your email.';
      }
    });

    form.addEventListener('submit', async e => {
      e.preventDefault();
      const status = $('#authStatus');
      if (!form.checkValidity()) { form.reportValidity(); return; }
      const email = ($('#email')?.value || '').trim().toLowerCase();
      const pass = $('#password')?.value || '';

      if (isSignup) {
        const confirmP = $('#confirm')?.value || '';
        if (pass !== confirmP) { if (status) status.textContent = '✕ Passwords do not match.'; return; }
        if (pass.length < 6) { if (status) status.textContent = '✕ Password must be at least 6 characters.'; return; }
        const first = $('#first')?.value.trim() || 'DECORLY';
        const last = $('#last')?.value.trim() || 'Buyer';
        const phone = $('#phone')?.value.trim() || '';
        if (status) status.textContent = 'Creating your account in MySQL database...';

        const apiRes = await window.DecorlyAPI.request('auth.php?action=register', 'POST', {
          first, last, name: (first + ' ' + last).trim(), email, phone, password: pass, city: 'Pakistan'
        });

        if (apiRes && apiRes.ok && apiRes.user) {
          save('decorly_current_user', apiRes.user);
          if (status) status.textContent = '✓ Account created in MySQL Database! Redirecting to My Account...';
          setTimeout(() => { location.href = 'my-account'; }, 350);
        } else {
          if (status) status.textContent = '✕ ' + ((apiRes && apiRes.error) || 'Database error while creating account. Make sure MySQL is running.');
        }
      } else {
        if (status) status.textContent = 'Verifying credentials with MySQL database...';
        const apiRes = await window.DecorlyAPI.request('auth.php?action=login', 'POST', { email, password: pass });
        if (apiRes && apiRes.ok && apiRes.user) {
          save('decorly_current_user', apiRes.user);
          if (status) status.textContent = '✓ Signed in as ' + apiRes.user.name + '! Redirecting to My Account...';
          setTimeout(() => { location.href = 'my-account'; }, 300);
        } else {
          if (status) status.textContent = '✕ ' + ((apiRes && apiRes.error) || 'Invalid email or password.');
        }
      }
    });
  }

  document.addEventListener('DOMContentLoaded', () => {
    count();
    renderWishlist();
    cartRender();
    checkout();
    renderOrderConfirmationPage();
    auth();
  });
  document.addEventListener('decorly:catalog-synced', () => {
    cartRender();
    renderOrderConfirmationPage();
  });
})();
