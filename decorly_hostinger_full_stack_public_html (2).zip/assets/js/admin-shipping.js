/* DECORLY External Script: admin-shipping.js */
location.replace('dashboard#shipping')

document.addEventListener('click', function(e) {
  var pr = e.target.closest('[data-decorly-print]');
  if (pr) { e.preventDefault(); window.print(); }
});
