/* DECORLY External Script: admin-customers.js */
location.replace('dashboard#customers')

document.addEventListener('click', function(e) {
  var pr = e.target.closest('[data-decorly-print]');
  if (pr) { e.preventDefault(); window.print(); }
});
