/* DECORLY External Script: admin-inventory.js */
location.replace('dashboard#inventory')

document.addEventListener('click', function(e) {
  var pr = e.target.closest('[data-decorly-print]');
  if (pr) { e.preventDefault(); window.print(); }
});
