/* DECORLY External Script: admin-blog.js */
location.replace('dashboard#blog')

document.addEventListener('click', function(e) {
  var pr = e.target.closest('[data-decorly-print]');
  if (pr) { e.preventDefault(); window.print(); }
});
