/* DECORLY External Script: admin-orders.js */
location.replace('dashboard#orders')

document.addEventListener('click', function(e) {
  var pr = e.target.closest('[data-decorly-print]');
  if (pr) { e.preventDefault(); window.print(); }
});
