/* DECORLY External Script: admin-index.js */
(function(){
  var pre = document.getElementById('decorly-preloader');
  var bar = document.getElementById('decorlyLoaderBar');
  var pct = document.getElementById('decorlyLoaderPct');
  if(!pre) return;
  var p = 12, done = false;
  var iv = setInterval(function(){
    if(done) return;
    p += Math.max(4, Math.round((92 - p) * 0.28));
    if(p > 92) p = 92;
    if(bar) bar.style.width = p + '%';
    if(pct) pct.textContent = p + '%';
  }, 45);
  function finish(){
    if(done) return;
    done = true;
    clearInterval(iv);
    if(bar) bar.style.width = '100%';
    if(pct) pct.textContent = '100%';
    setTimeout(function(){
      pre.classList.add('is-loaded');
    }, 140);
  }
  if(document.readyState === 'complete' || document.readyState === 'interactive'){
    setTimeout(finish, 260);
  } else {
    window.addEventListener('DOMContentLoaded', function(){ setTimeout(finish, 280); });
    window.addEventListener('load', finish);
  }
  setTimeout(finish, 950);
})();

(function(){
  'use strict';
  const boot = window.DECORLY_SERVER_BOOT || {};
  const prof = boot.admin_profile || {
    name: 'Store Administrator',
    role: 'Chief Store Administrator',
    email: 'admin@decorly.com',
    pass: 'Decorly@2026',
    initials: 'DA',
    photo: ''
  };

  if (document.getElementById('demoEmailText')) document.getElementById('demoEmailText').textContent = prof.email || 'admin@decorly.com';
  if (document.getElementById('demoPassText')) document.getElementById('demoPassText').textContent = prof.pass || 'Decorly@2026';
  if (document.getElementById('chipName')) document.getElementById('chipName').textContent = (prof.name || 'Store Administrator') + ' · ' + (prof.role || 'Admin');
  const av = document.getElementById('chipAvatar');
  if (av) {
    if (prof.photo) {
      av.innerHTML = '<img src="' + prof.photo.replace(/"/g, '&quot;') + '" alt="">';
    } else {
      av.textContent = (prof.initials || 'DA').slice(0, 2).toUpperCase();
    }
  }

  if (document.getElementById('email')) document.getElementById('email').value = prof.email || 'admin@decorly.com';

  document.getElementById('togglePass')?.addEventListener('click', function(){
    const inp = document.getElementById('password');
    if (inp) inp.type = inp.type === 'password' ? 'text' : 'password';
  });

  document.getElementById('autoFillBtn')?.addEventListener('click', function(){
    if (document.getElementById('email')) document.getElementById('email').value = prof.email || 'admin@decorly.com';
    if (document.getElementById('password')) document.getElementById('password').value = prof.pass || 'Decorly@2026';
    document.getElementById('error')?.classList.remove('show');
  });

  const form = document.getElementById('loginForm');
  form?.addEventListener('submit', async function(e){
    e.preventDefault();
    const email = document.getElementById('email').value.trim().toLowerCase();
    const pass = document.getElementById('password').value;
    try {
      const res = await fetch('../api/auth.php?action=admin_login', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({email, password: pass})
      });
      const data = await res.json();
      if (data && data.ok && data.admin) {
        sessionStorage.setItem('decorlyAdminDemoAuth', 'yes');
        if (document.getElementById('remember')?.checked) {
          localStorage.setItem('decorlyAdminDemoRemember', 'yes');
        }
        location.href = 'dashboard';
        return;
      }
    } catch (err) {}
    document.getElementById('error')?.classList.add('show');
  });
})();
