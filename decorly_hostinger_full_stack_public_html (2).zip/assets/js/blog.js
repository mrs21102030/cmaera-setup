(function(){
  var pre = document.getElementById('decorly-preloader');
  var bar = document.getElementById('decorlyLoaderBar');
  var pct = document.getElementById('decorlyLoaderPct');
  if(!pre) return;
  var p = 12, done = false;
  var iv = setInterval(function(){
    if(done) return;
    p += Math.max(4, Math.round((92 - p) * 0.28));
    if(p > 92) p = 92;
    if(bar) bar.style.width = p + '%';
    if(pct) pct.textContent = p + '%';
  }, 45);
  function finish(){
    if(done) return;
    done = true;
    clearInterval(iv);
    if(bar) bar.style.width = '100%';
    if(pct) pct.textContent = '100%';
    setTimeout(function(){
      pre.classList.add('is-loaded');
    }, 140);
  }
  if(document.readyState === 'complete' || document.readyState === 'interactive'){
    setTimeout(finish, 260);
  } else {
    window.addEventListener('DOMContentLoaded', function(){ setTimeout(finish, 280); });
    window.addEventListener('load', finish);
  }
  setTimeout(finish, 950);
})();

(function(){
  'use strict';
  const $ = id => document.getElementById(id);
  const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  let active = 'all';

  function getPosts() {
    const boot = window.DECORLY_SERVER_BOOT || {};
    return (Array.isArray(boot.blog_posts) ? boot.blog_posts : []).filter(p => p.status !== 'Draft');
  }

  function renderBlog() {
    const posts = getPosts();
    const q = ($('blogSearch')?.value || '').trim().toLowerCase();
    const tabs = $('blogTabs');
    if (tabs) {
      const cats = ['all', ...new Set(posts.map(p => p.category || 'Home Styling'))];
      tabs.innerHTML = cats.map(c =>
        `<button class="blog-tab ${active === c ? 'active' : ''}" data-category="${esc(c)}">${c === 'all' ? 'All articles' : esc(c)}</button>`
      ).join('');
      tabs.querySelectorAll('button').forEach(b => b.onclick = () => {
        active = b.dataset.category;
        renderBlog();
      });
    }

    const filtered = posts.filter(p =>
      (active === 'all' || p.category === active) &&
      (!q || (`${p.title} ${p.excerpt || ''} ${p.category || ''}`).toLowerCase().includes(q))
    );

    const grid = $('blogGrid');
    if (grid) {
      grid.innerHTML = filtered.map(p => `
        <a class="blog-card visible" href="single-blog?slug=${encodeURIComponent(p.slug)}">
          <figure><img alt="${esc(p.title)}" loading="lazy" src="${esc(p.image)}"/></figure>
          <div class="blog-card-body">
            <span class="blog-cat">${esc(p.category || 'Journal')}</span>
            <h2>${esc(p.title)}</h2>
            <p>${esc(p.excerpt || '')}</p>
            <span class="blog-read">READ ARTICLE <b>↗</b></span>
          </div>
        </a>
      `).join('');
    }
    if ($('blogEmpty')) $('blogEmpty').hidden = filtered.length !== 0;
  }

  $('blogSearch')?.addEventListener('input', renderBlog);
  renderBlog();
  document.addEventListener('decorly:catalog-synced', renderBlog);
})();
