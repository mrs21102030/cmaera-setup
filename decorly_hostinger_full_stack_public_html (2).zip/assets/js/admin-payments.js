/* DECORLY External Script: admin-payments.js */
location.replace('dashboard#payments')

document.addEventListener('click', function(e) {
  var pr = e.target.closest('[data-decorly-print]');
  if (pr) { e.preventDefault(); window.print(); }
});
