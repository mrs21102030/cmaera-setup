/* DECORLY External Script: contact.js */
(function(){
  var pre = document.getElementById('decorly-preloader');
  var bar = document.getElementById('decorlyLoaderBar');
  var pct = document.getElementById('decorlyLoaderPct');
  if(!pre) return;
  var p = 12, done = false;
  var iv = setInterval(function(){
    if(done) return;
    p += Math.max(4, Math.round((92 - p) * 0.28));
    if(p > 92) p = 92;
    if(bar) bar.style.width = p + '%';
    if(pct) pct.textContent = p + '%';
  }, 45);
  function finish(){
    if(done) return;
    done = true;
    clearInterval(iv);
    if(bar) bar.style.width = '100%';
    if(pct) pct.textContent = '100%';
    setTimeout(function(){
      pre.classList.add('is-loaded');
    }, 140);
  }
  if(document.readyState === 'complete' || document.readyState === 'interactive'){
    setTimeout(finish, 260);
  } else {
    window.addEventListener('DOMContentLoaded', function(){ setTimeout(finish, 280); });
    window.addEventListener('load', finish);
  }
  setTimeout(finish, 950);
})();

(()=>{'use strict';const btn=document.getElementById('menuBtn'),mob=document.getElementById('mobileMenu');if(btn&&mob){btn.addEventListener('click',()=>{const on=mob.classList.toggle('open');btn.setAttribute('aria-expanded',String(on))});mob.querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>{mob.classList.remove('open');btn.setAttribute('aria-expanded','false')}))}const sf=document.getElementById('searchForm');if(sf)sf.addEventListener('submit',e=>{e.preventDefault();let v=(document.getElementById('search')?.value||'').trim();location.href='search'+(v?'?q='+encodeURIComponent(v):'')});const pro=document.getElementById('progress');let ticking=false;window.addEventListener('scroll',()=>{if(ticking)return;ticking=true;requestAnimationFrame(()=>{if(pro)pro.style.width=(100*scrollY/Math.max(1,document.documentElement.scrollHeight-innerHeight))+'%';ticking=false})},{passive:true});const obs=window.IntersectionObserver?new IntersectionObserver(es=>{es.forEach(e=>{if(e.isIntersecting){e.target.classList.add('ed-in');obs.unobserve(e.target)}})},{threshold:.12}):null;document.querySelectorAll('[data-ed-reveal]').forEach(el=>obs?obs.observe(el):el.classList.add('ed-in'));const form=document.getElementById('contactForm');if(form)form.addEventListener('submit',e=>{e.preventDefault();const status=document.getElementById('formStatus');if(!form.reportValidity()){status.textContent='Please complete the required fields correctly.';return}const enq=JSON.parse(localStorage.getItem('decorly_enquiries')||'[]');
enq.unshift({
  date:new Date().toLocaleDateString('en-GB',{day:'2-digit',month:'short',year:'numeric'}),
  name:(document.getElementById('firstName')?.value||'')+' '+(document.getElementById('lastName')?.value||''),
  email:document.getElementById('email')?.value||'',
  phone:document.getElementById('phone')?.value||'',
  topic:document.getElementById('topic')?.value||'Product Enquiry',
  message:document.getElementById('message')?.value||''
});
localStorage.setItem('decorly_enquiries',JSON.stringify(enq));
if(window.DecorlyAPI){window.DecorlyAPI.request('reviews?action=enquiry','POST',enq[0]);}
status.style.color='#1f8b55';
status.style.fontWeight='700';
status.textContent='✓ Thank you! Your enquiry (#ENQ-'+String(100+enq.length)+') has been received and synced with the DECORLY Admin Dashboard.';
form.reset();})})();

/* DECORLY cross-page product search — uses the approved search results page */
(function(){
  document.addEventListener('submit',function(event){
    var form=event.target;
    if(!form || form.id!=='searchForm')return;
    event.preventDefault();
    event.stopImmediatePropagation();
    var field=form.querySelector('input[type="search"],input[name="q"],#search');
    var q=field?field.value.trim():'';
    window.location.href='search'+(q?'?q='+encodeURIComponent(q):'');
  },true);
})();

(()=>{const hd=document.querySelector('.decorly-site-header'),menu=document.querySelector('.decorly-site-mobile');if(!hd||!menu)return;
const btn=hd.querySelector('#mbtn');if(btn)btn.addEventListener('click',()=>{const open=menu.classList.toggle('o');btn.textContent=open?'×':'☰';btn.setAttribute('aria-expanded',String(open))});
menu.querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>{menu.classList.remove('o');if(btn){btn.textContent='☰';btn.setAttribute('aria-expanded','false')}}));
document.addEventListener('keydown',e=>{if(e.key==='Escape'){menu.classList.remove('o');if(btn){btn.textContent='☰';btn.setAttribute('aria-expanded','false')}}});
const form=hd.querySelector('form.sf');if(form)form.addEventListener('submit',e=>{e.preventDefault();const v=form.querySelector('input[name=q]')?.value.trim()||'';location.href='search'+(v?'?q='+encodeURIComponent(v):'')});
const mf=menu.querySelector('form');if(mf)mf.addEventListener('submit',e=>{e.preventDefault();const q=mf.querySelector('input[name=q]')?.value.trim()||'';location.href='search'+(q?'?q='+encodeURIComponent(q):'')});
const cart=hd.querySelector('#cartCount');function count(){if(!cart)return;try{const items=JSON.parse(localStorage.getItem('decorly_cart')||'[]');cart.textContent=Array.isArray(items)?items.reduce((n,p)=>n+(Number(p.quantity??p.qty)||1),0):0}catch(e){cart.textContent='0'}}count();window.addEventListener('storage',count);
})();

document.addEventListener('click', function(e) {
  var pr = e.target.closest('[data-decorly-print]');
  if (pr) { e.preventDefault(); window.print(); }
});
