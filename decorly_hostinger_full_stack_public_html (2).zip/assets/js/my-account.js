(function(){
  var pre = document.getElementById('decorly-preloader');
  var bar = document.getElementById('decorlyLoaderBar');
  var pct = document.getElementById('decorlyLoaderPct');
  if(!pre) return;
  var p = 12, done = false;
  var iv = setInterval(function(){
    if(done) return;
    p += Math.max(4, Math.round((92 - p) * 0.28));
    if(p > 92) p = 92;
    if(bar) bar.style.width = p + '%';
    if(pct) pct.textContent = p + '%';
  }, 45);
  function finish(){
    if(done) return;
    done = true;
    clearInterval(iv);
    if(bar) bar.style.width = '100%';
    if(pct) pct.textContent = '100%';
    setTimeout(function(){
      pre.classList.add('is-loaded');
    }, 140);
  }
  if(document.readyState === 'complete' || document.readyState === 'interactive'){
    setTimeout(finish, 260);
  } else {
    window.addEventListener('DOMContentLoaded', function(){ setTimeout(finish, 280); });
    window.addEventListener('load', finish);
  }
  setTimeout(finish, 950);
})();

(function(){
  'use strict';
  const $ = s => document.querySelector(s);
  const $$ = s => [...document.querySelectorAll(s)];
  const safe = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const money = n => 'Rs ' + Math.round(Number(n || 0)).toLocaleString('en-PK');

  const boot = window.DECORLY_SERVER_BOOT || {};
  let prof = boot.user || null;

  // If buyer is not signed in via PHP Session, redirect to login page
  if (!prof || !prof.email) {
    location.href = 'login';
    return;
  }

  let buyerOrders = [];
  let buyerAddresses = [];
  let editingAddrId = 0;

  function syncBuyerUI() {
    const fullName = ((prof.first || '') + ' ' + (prof.last || '')).trim() || prof.name || prof.email;
    if ($('#buyerSideName')) $('#buyerSideName').textContent = fullName;
    if ($('#buyerSideEmail')) $('#buyerSideEmail').textContent = prof.email;
    if ($('#buyerWelcomeTitle')) $('#buyerWelcomeTitle').textContent = 'Welcome back, ' + fullName + ' 👋';
    const av = $('#buyerSideAvatar');
    if (av) {
      if (prof.photo) {
        av.innerHTML = '<img src="' + safe(prof.photo) + '" alt="Avatar">';
      } else {
        av.textContent = fullName.split(' ').filter(Boolean).map(w => w[0]).join('').slice(0, 2).toUpperCase() || 'U';
      }
    }
    if ($('#first')) $('#first').value = prof.first || '';
    if ($('#last')) $('#last').value = prof.last || '';
    if ($('#email')) $('#email').value = prof.email || '';
    if ($('#phone')) $('#phone').value = prof.phone || '';
    if ($('#buyerCity')) $('#buyerCity').value = prof.city || 'Pakistan';
    if ($('#custDispName')) $('#custDispName').value = fullName;
  }
  syncBuyerUI();

  $('#buyerPhotoInput')?.addEventListener('change', e => {
    const f = e.target.files?.[0];
    if (!f) return;
    const r = new FileReader();
    r.onload = async ev => {
      prof.photo = String(ev.target.result || '');
      syncBuyerUI();
      await window.DecorlyAPI.request('auth.php?action=update_profile', 'POST', prof);
    };
    r.readAsDataURL(f);
  });

  $('#buyerLogoutBtn')?.addEventListener('click', async () => {
    localStorage.removeItem('decorly_current_user');
    await window.DecorlyAPI.request('auth.php?action=logout', 'POST');
    location.href = 'login';
  });

  $('#profileForm')?.addEventListener('submit', async e => {
    e.preventDefault();
    prof.first = $('#first').value.trim();
    prof.last = $('#last').value.trim();
    prof.name = (prof.first + ' ' + prof.last).trim();
    prof.email = $('#email').value.trim();
    prof.phone = $('#phone').value.trim();
    prof.city = $('#buyerCity').value.trim();
    const res = await window.DecorlyAPI.request('auth.php?action=update_profile', 'POST', prof);
    if (res && res.ok && res.user) {
      prof = res.user;
      localStorage.setItem('decorly_current_user', JSON.stringify(prof));
      syncBuyerUI();
      if ($('#profileFeedback')) $('#profileFeedback').textContent = '✓ Profile saved to MySQL database!';
    }
  });

  $('#customerSecurityForm')?.addEventListener('submit', async e => {
    e.preventDefault();
    const np = $('#custNewPass').value, cp = $('#custConfPass').value, fb = $('#custSecurityFeedback');
    if (np !== cp) {
      if (fb) fb.textContent = '✕ New password and confirmation do not match.';
      return;
    }
    const parts = ($('#custDispName').value.trim() || prof.name).split(' ');
    prof.first = parts[0] || prof.first;
    prof.last = parts.slice(1).join(' ') || '';
    prof.name = (prof.first + ' ' + prof.last).trim();
    const res = await window.DecorlyAPI.request('auth.php?action=update_profile', 'POST', Object.assign({}, prof, { new_password: np }));
    if (res && res.ok) {
      syncBuyerUI();
      if (fb) fb.textContent = '✓ Display name & password updated in MySQL Database!';
      $('#custCurrPass').value = '';
      $('#custNewPass').value = '';
      $('#custConfPass').value = '';
    }
  });

  async function fetchBuyerOrders() {
    const res = await window.DecorlyAPI.request('orders?email=' + encodeURIComponent(prof.email), 'GET');
    buyerOrders = (res && res.ok && Array.isArray(res.orders)) ? res.orders : [];
    renderBuyerOrders();
    renderBuyerOrderDetail(0);
  }

  function renderBuyerOrders() {
    if ($('#kpiBuyerOrders')) $('#kpiBuyerOrders').textContent = buyerOrders.length;
    if ($('#buyerOrdNavBadge')) $('#buyerOrdNavBadge').textContent = buyerOrders.length;
    const list = $('#buyerOrdersList');
    if (!list) return;
    if (!buyerOrders.length) {
      list.innerHTML = `<div class="empty">You have not placed any orders yet. <a href="shop">Explore the DECORLY catalog →</a></div>`;
      return;
    }
    list.innerHTML = buyerOrders.map((o, i) => {
      const itemSummary = (o.items || []).map(it => `${it.name} (×${it.qty || 1})`).join(', ') || 'DECORLY Furniture Order';
      return `<article class="buyer-order-card">
        <div>
          <div>
            <strong>${safe(o.id)}</strong> · <span>${safe(o.status || 'Processing')}</span> · <small>${safe(o.date)}</small>
          </div>
          <p>${safe(itemSummary)}</p>
          <small>Payment: ${safe(o.payment || 'COD')} · Destination: ${safe(o.city || 'Pakistan')}</small>
        </div>
        <div>
          <strong>${money(o.total)}</strong>
          <button type="button" class="account-btn" data-open-order="${i}">View Receipt &amp; Items ↗</button>
        </div>
      </article>`;
    }).join('');

    list.querySelectorAll('[data-open-order]').forEach(btn => {
      btn.addEventListener('click', () => {
        renderBuyerOrderDetail(+btn.dataset.openOrder);
        location.hash = '#order-details';
      });
    });
  }

  function renderBuyerOrderDetail(idx = 0) {
    const box = $('#buyerOrderDetailBox');
    if (!box) return;
    const o = buyerOrders[idx] || buyerOrders[0];
    if (!o) {
      box.innerHTML = `<p class="muted">No orders found for ${safe(prof.email)}.</p>`;
      return;
    }
    const items = Array.isArray(o.items) ? o.items : [];
    box.innerHTML = `
      <div>
        <div>
          <span>VERIFIED ORDER RECEIPT</span>
          <h2>Order ${safe(o.id)}</h2>
          <p class="muted">Placed on ${safe(o.date)} · Status: <b>${safe(o.status)}</b> · Payment: <b>${safe(o.payment || 'COD')}</b></p>
        </div>
        <div>
          <button type="button" class="account-btn outline" data-decorly-print="1">🖨️ Print Receipt</button>
          <a class="account-btn" href="#orders">← Back to My Orders</a>
        </div>
      </div>
      <div>
        <div><small>CUSTOMER</small><strong>${safe(o.customer)}</strong><span>${safe(o.email || '')} · ${safe(o.phone || '')}</span></div>
        <div><small>DELIVERY ADDRESS</small><strong>${safe(o.address || '')}</strong><span>${safe(o.city || 'Pakistan')}</span></div>
      </div>
      <div>
        ${items.map(it => `<div>
          <div>
            <strong>${safe(it.name)}</strong>
            <small>Qty: ${it.qty || 1} · Unit: ${money(it.price || o.total)}</small>
          </div>
          <strong>${money((it.price || o.total) * (it.qty || 1))}</strong>
        </div>`).join('')}
      </div>
      <div>
        <span>Need help with this order? <a href="contact">Contact Support</a></span>
        <strong>Total: ${money(o.total)}</strong>
      </div>`;
  }

  async function fetchBuyerAddresses() {
    const res = await window.DecorlyAPI.request('auth.php?action=addresses&email=' + encodeURIComponent(prof.email), 'GET');
    buyerAddresses = (res && res.ok && Array.isArray(res.addresses)) ? res.addresses : [];
    renderAddresses();
  }

  function renderAddresses() {
    if ($('#kpiBuyerAddr')) $('#kpiBuyerAddr').textContent = buyerAddresses.length;
    const list = $('#addressList');
    if (!list) return;
    if (!buyerAddresses.length) {
      list.innerHTML = `<p class="muted">No saved delivery addresses yet. Add your delivery address below.</p>`;
      return;
    }
    list.innerHTML = buyerAddresses.map((x, i) => `<article class="address-item">
      <h3>${safe(x.recipient_name || prof.name)} (${safe(x.label || 'Home')})</h3>
      <p>${[x.street_address, x.city, x.postal_code, x.phone].filter(Boolean).map(safe).join('<br>')}</p>
      <div class="mini-actions">
        <button type="button" data-edit="${i}">✎ Edit</button>
        <button type="button" data-remove="${i}">✕ Remove</button>
      </div>
    </article>`).join('');
  }

  $('#addressList')?.addEventListener('click', async e => {
    const b = e.target.closest('button');
    if (!b) return;
    if (b.hasAttribute('data-remove')) {
      const target = buyerAddresses[+b.dataset.remove];
      if (!target) return;
      const res = await window.DecorlyAPI.request('auth.php?action=addresses', 'POST', {
        sub_action: 'delete', id: target.id, email: prof.email
      });
      if (res && res.ok) {
        buyerAddresses = res.addresses || [];
        renderAddresses();
      }
    } else if (b.hasAttribute('data-edit')) {
      const target = buyerAddresses[+b.dataset.edit];
      if (!target) return;
      editingAddrId = target.id;
      if ($('#aname')) $('#aname').value = target.recipient_name || '';
      if ($('#aphone')) $('#aphone').value = target.phone || '';
      if ($('#astreet')) $('#astreet').value = target.street_address || '';
      if ($('#acity')) $('#acity').value = target.city || '';
      if ($('#azip')) $('#azip').value = target.postal_code || '';
      if ($('#addressFormTitle')) $('#addressFormTitle').textContent = 'Edit Delivery Address';
      $('#addressForm')?.scrollIntoView({ behavior: 'smooth' });
    }
  });

  $('#addressForm')?.addEventListener('submit', async e => {
    e.preventDefault();
    const res = await window.DecorlyAPI.request('auth.php?action=addresses', 'POST', {
      id: editingAddrId,
      email: prof.email,
      label: 'Home',
      recipient_name: $('#aname')?.value.trim() || prof.name,
      phone: $('#aphone')?.value.trim() || prof.phone,
      street_address: $('#astreet')?.value.trim() || '',
      city: (($('#acity')?.value.trim() || '') + ' ' + ($('#aregion')?.value.trim() || '')).trim(),
      postal_code: $('#azip')?.value.trim() || ''
    });
    if (res && res.ok) {
      buyerAddresses = res.addresses || [];
      editingAddrId = 0;
      $('#addressForm').reset();
      if ($('#addressFormTitle')) $('#addressFormTitle').textContent = 'Add a Delivery Address';
      renderAddresses();
      if ($('#addressFeedback')) $('#addressFeedback').textContent = '✓ Delivery address saved to MySQL database!';
    }
  });

  function updateBuyerKpis() {
    try {
      const c = JSON.parse(localStorage.getItem('decorly_cart') || '[]');
      const w = JSON.parse(localStorage.getItem('decorly_wishlist') || '[]');
      if ($('#kpiBuyerCart')) $('#kpiBuyerCart').textContent = Array.isArray(c) ? c.reduce((n, x) => n + (Number(x.qty ?? x.quantity) || 1), 0) : 0;
      if ($('#kpiBuyerWish')) $('#kpiBuyerWish').textContent = Array.isArray(w) ? w.length : 0;
    } catch {}
  }

  fetchBuyerOrders();
  fetchBuyerAddresses();
  updateBuyerKpis();

  const panels = $$('[data-account-panel]'), navs = $$('[data-buyer-nav]');
  const valid = new Set(panels.map(p => p.dataset.accountPanel));
  function activateTab() {
    let tab = location.hash.replace(/^#/, '') || 'overview';
    if (!valid.has(tab)) tab = 'overview';
    panels.forEach(p => { const on = p.dataset.accountPanel === tab; p.classList.toggle('is-active', on); p.hidden = !on; });
    navs.forEach(a => { const on = a.dataset.buyerNav === tab; a.classList.toggle('is-active', on); a.classList.toggle('active', on); });
    const titles = { 'overview': 'My Account Overview', 'profile': 'My Personal Profile', 'orders': 'My Order History', 'order-details': 'Order Receipt & Details', 'addresses': 'Saved Delivery Addresses', 'settings': 'Password & Security' };
    if ($('#buyerHeroHeading')) $('#buyerHeroHeading').textContent = titles[tab] || 'My Account';
    if ($('#buyerCrumbActive')) $('#buyerCrumbActive').textContent = titles[tab] || 'Overview';
  }
  window.addEventListener('hashchange', activateTab);
  activateTab();
})();
