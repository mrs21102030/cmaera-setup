/* DECORLY External Script: admin-collections.js */
location.replace('dashboard#categories')

document.addEventListener('click', function(e) {
  var pr = e.target.closest('[data-decorly-print]');
  if (pr) { e.preventDefault(); window.print(); }
});
