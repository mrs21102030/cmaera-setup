<?php require_once __DIR__ . '/db.php'; ?>
<!DOCTYPE html>

<html lang="en"><head><meta charset="utf-8"/><meta content="width=device-width,initial-scale=1" name="viewport"/><meta content="#102346" name="theme-color"/><meta content="Page Not Found | DECORLY — DECORLY furniture store information." name="description"/><title>Page Not Found | DECORLY</title><link href="https://fonts.googleapis.com" rel="preconnect"/><link crossorigin="" href="https://fonts.gstatic.com" rel="preconnect"/><link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700;800&amp;family=Manrope:wght@400;500;600;700;800&amp;display=swap" rel="stylesheet"/>







  <link rel="stylesheet" href="assets/css/global.css">
  <link rel="stylesheet" href="assets/css/404.css">
  <script src="api/bootstrap-js.php"></script>
</head><body class="decorly-unified">
<!-- DECORLY Luxury Preloader -->
<div id="decorly-preloader" role="status" aria-live="polite" aria-label="Loading DECORLY">
  <div class="dl-ambient"></div>
  <div class="dl-emblem-wrap">
    <div class="dl-ring-outer"></div>
    <div class="dl-ring-inner"></div>
    <div class="dl-core"><span>D</span></div>
  </div>
  <div class="dl-brand">DECOR<b>LY</b></div>
  <div class="dl-tag">CURATING INSPIRED LIVING</div>
  <div class="dl-track"><div class="dl-bar" id="decorlyLoaderBar"></div></div>
  <div class="dl-pct" id="decorlyLoaderPct">0%</div>
</div>


<div class="progress" id="progress"></div><header class="nv decorly-site-header" id="hd"><a aria-label="DECORLY Home" class="lg" href="./"><img alt="DECORLY" height="34" src="assets/decorly-logo-light.png" width="169"/></a>
<nav class="lk"><a href="./">Home</a><a href="shop">Shop</a><div class="decorly-cat-nav" id="decorlyCatNav"><a aria-expanded="false" aria-haspopup="true" class="decorly-cat-trigger" href="categories">Categories <span aria-hidden="true">⌄</span></a><div class="decorly-cat-menu"><div class="decorly-cat-group"><a class="decorly-cat-parent" href="categories?group=tables">Tables <span>›</span></a><div class="decorly-cat-sub"><a href="category?slug=nesting-tables">Nesting Tables</a><a href="category?slug=tea-tables">Tea Tables</a><a href="category?slug=console-tables">Console Tables</a><a href="category?slug=dining-tables">Dining Tables</a><a href="category?slug=coffee-tables">Coffee Tables</a><a href="category?slug=laptop-tables">Laptop Tables</a></div></div><div class="decorly-cat-group"><a class="decorly-cat-parent" href="categories?group=racks">Racks <span>›</span></a><div class="decorly-cat-sub"><a href="category?slug=kitchen-oven-racks">Kitchen Oven Racks</a><a href="category?slug=corner-racks">Corner Racks</a></div></div><div class="decorly-cat-group"><a class="decorly-cat-parent" href="categories?group=trolleys">Trolleys <span>›</span></a><div class="decorly-cat-sub"><a href="category?slug=tea-trolleys">Tea Trolleys</a></div></div><a class="decorly-all-cat" href="categories">Explore All Categories ↗</a></div></div><a href="about">About Us</a><a href="blog">Blog</a><a href="contact">Contact</a></nav>
<form action="search" class="sf" id="searchForm" method="get"><input aria-label="Search products" id="search" name="q" placeholder="Search..." type="search"/></form>
<div class="qk"><a aria-label="Wishlist" href="wishlist" title="Wishlist">♡</a><a aria-label="Cart" href="cart" title="Cart">🛒<i id="cartCount">0</i></a></div>
 <?php $__isLogged = !empty($_SESSION['decorly_user']); ?><a aria-label="Sign In or My Account" class="decorly-header-signin-btn<?php echo $__isLogged ? ' is-signed-in' : ''; ?>" id="headerSignInBtn" href="<?php echo $__isLogged ? 'my-account' : 'login'; ?>"><?php echo $__isLogged ? 'My Account' : 'Sign In'; ?></a>
<a class="gb nb" href="shop">Shop Furniture</a><button aria-label="Menu" class="mb" id="mbtn">☰</button></header><nav class="mm decorly-site-mobile" id="mm"><a href="./">Home</a><a href="shop">Shop All Products</a><a href="categories">All Categories</a><details><summary>Tables</summary><a href="category?slug=nesting-tables">Nesting Tables</a><a href="category?slug=tea-tables">Tea Tables</a><a href="category?slug=console-tables">Console Tables</a><a href="category?slug=dining-tables">Dining Tables</a><a href="category?slug=coffee-tables">Coffee Tables</a><a href="category?slug=laptop-tables">Laptop Tables</a></details><details><summary>Racks</summary><a href="category?slug=kitchen-oven-racks">Kitchen Oven Racks</a><a href="category?slug=corner-racks">Corner Racks</a></details><details><summary>Trolleys</summary><a href="category?slug=tea-trolleys">Tea Trolleys</a></details><a href="about">About Us</a><a href="blog">Blog</a><a href="contact">Contact Us</a><a href="wishlist">Wishlist</a><a href="cart">Cart</a><a href="login">Sign In</a><a href="signup">Create Account</a><a href="faq">Help &amp; FAQ</a><form action="search" method="get" class="d-u-404-1"><input name="q" placeholder="Search furniture..." type="search" class="d-u-404-2"/></form></nav><main class="dp-shell"><section class="dp-404"><div class="container"><span class="dp-kicker">404 / PAGE NOT FOUND</span><h1>This page is <em>out of place.</em></h1><p>The page you’re looking for may have moved or the address might be incorrect. Your next great furniture find is only a click away.</p><div class="dp-links"><a class="dp-button" href="./">BACK TO HOMEPAGE ↗</a><a class="dp-button outline" href="shop">EXPLORE THE SHOP ↗</a></div><nav aria-label="Helpful pages" class="dp-quick"><a href="categories">All Categories</a><a href="search">Search</a><a href="contact">Contact Us</a></nav></div></section></main>
<footer id="siteFooter" class="decorly-final-footer decorly-luxe-footer" aria-label="DECORLY website footer">
<div class="lf-top"><div class="lf-grid">
<section class="lf-brand" aria-label="DECORLY brand"><a href="./" class="lf-logo" aria-label="DECORLY homepage"><img src="assets/decorly-logo-light.png" alt="DECORLY" loading="lazy"></a><p>Furniture for inspired living. Discover contemporary tables, trolleys and thoughtful storage for your space.</p><a href="shop" class="lf-cta">Explore furniture <span aria-hidden="true">→</span></a></section>
<nav class="lf-links" aria-label="Explore"><div class="lf-icon" aria-hidden="true">⌂</div><h3>Explore</h3><a href="./">Home <span>›</span></a><a href="shop">Shop furniture <span>›</span></a><a href="categories">All categories <span>›</span></a><a href="about">About us <span>›</span></a><a href="contact">Contact us <span>›</span></a></nav>
<nav class="lf-links" aria-label="Collections"><div class="lf-icon" aria-hidden="true">▱</div><h3>Collections</h3><a href="category?slug=coffee-tables">Coffee tables <span>›</span></a><a href="category?slug=nesting-tables">Nesting tables <span>›</span></a><a href="category?slug=tea-trolleys">Tea trolleys <span>›</span></a><a href="category?slug=corner-racks">Corner racks <span>›</span></a></nav>
<nav class="lf-links" aria-label="Help and contact"><div class="lf-icon" aria-hidden="true">♧</div><h3>Help &amp; Contact</h3><a href="faq">Help &amp; FAQs <span>›</span></a><a href="shipping-policy">Shipping policy <span>›</span></a><a href="return-refund-policy">Returns &amp; refunds <span>›</span></a><a href="privacy-policy">Privacy policy <span>›</span></a><a href="terms-conditions">Terms &amp; conditions <span>›</span></a></nav>
<section class="lf-contact" aria-label="Contact details"><h3>Get in touch</h3><p class="lf-intro">Have a question? We're here to help.</p><div class="lf-method"><span class="lf-round" aria-hidden="true">✉</span><div><small>Official Support Email</small><a href="mailto:support@decorly.pk">support@decorly.pk</a></div></div><div class="lf-method"><span class="lf-round" aria-hidden="true">☎</span><div><small>Customer Care Helpline</small><a href="tel:+923008429000">+92 300 8429000</a></div></div><div class="lf-method"><span class="lf-round" aria-hidden="true">⌖</span><div><small>Studio / location</small><span>Industrial Estate &amp; Design Studio, Multan / Lahore, Pakistan</span></div></div><div class="lf-social"><p>Follow us</p><div aria-label="DECORLY official social channels"><span aria-label="DECORLY on Instagram">◎</span><span aria-label="DECORLY on Facebook">f</span><span aria-label="DECORLY on Pinterest">p</span><span aria-label="DECORLY on YouTube">▶</span><span aria-label="DECORLY on LinkedIn">in</span></div></div></section>
</div></div><div class="lf-bottom"><div class="lf-bottom-inner"><p>© 2026 DECORLY. All rights reserved.</p><div class="lf-perks"><div><b aria-hidden="true">♧</b><span>Shipping details<small>See shipping policy</small></span></div><div><b aria-hidden="true">♢</b><span>Returns &amp; refunds<small>View our policy</small></span></div><div><b aria-hidden="true">⬡</b><span>Checkout experience<small>Payment options at checkout</small></span></div></div><p class="lf-note">A more inspired home<br>for a brighter tomorrow.</p></div></div>
</footer>
<script src="assets/js/404.js"></script>
<script src="assets/js/decorly-shopping.js"></script>
</body></html>