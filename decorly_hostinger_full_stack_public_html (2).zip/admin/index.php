<?php require_once dirname(__DIR__) . '/db.php'; ?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="theme-color" content="#071224">
<title>Admin Sign In | DECORLY Executive Suite</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700;800&family=Manrope:wght@400;500;600;700;800&family=Playfair+Display:ital,wght@1,500&display=swap" rel="stylesheet">




  <link rel="stylesheet" href="../assets/css/global.css">
  <link rel="stylesheet" href="../assets/css/admin-index.css">
  <script src="../api/bootstrap-js.php"></script>
</head>
<body>
<!-- DECORLY Luxury Preloader -->
<div id="decorly-preloader" role="status" aria-live="polite" aria-label="Loading DECORLY">
  <div class="dl-ambient"></div>
  <div class="dl-emblem-wrap">
    <div class="dl-ring-outer"></div>
    <div class="dl-ring-inner"></div>
    <div class="dl-core"><span>D</span></div>
  </div>
  <div class="dl-brand">DECOR<b>LY</b></div>
  <div class="dl-tag">EXECUTIVE ADMIN PORTAL</div>
  <div class="dl-track"><div class="dl-bar" id="decorlyLoaderBar"></div></div>
  <div class="dl-pct" id="decorlyLoaderPct">0%</div>
</div>


<main class="layout">
  <section class="brand">
    <div class="brand-top">
      <div class="wordmark">DECOR<span>LY</span></div>
      <span class="badge-suite">Admin v2.6</span>
    </div>
    <div>
      <p class="eyebrow">PRIVATE EXECUTIVE PORTAL</p>
      <h1>Manage your store with <em>clarity</em> &amp; precision.</h1>
      <p>Real-time revenue analytics, interactive sales graphs, catalog control, and personal profile security — unified in one luxury workspace.</p>
      <div class="feature-pills">
        <div class="fpill"><i>📈</i> Interactive Sales Graphs</div>
        <div class="fpill"><i>🛡️</i> Profile &amp; Password Control</div>
        <div class="fpill"><i>📦</i> Live Catalog &amp; Orders</div>
        <div class="fpill"><i>✨</i> Instant Browser Sync</div>
      </div>
    </div>
    <div class="brandfoot"><span></span> DECORLY ADMINISTRATION · AUTHORIZED ACCESS ONLY</div>
  </section>
  <section class="formside">
    <a class="back" href="../">← Back to DECORLY Storefront</a>
    <div class="admin-preview-chip" id="adminChip">
      <div class="av" id="chipAvatar">DA</div>
      <span id="chipName">Welcome, Store Administrator</span>
    </div>
    <h2>Sign In to Dashboard</h2>
    <p class="sub">Enter your administrator credentials to open the control panel.</p>
    <form id="loginForm">
      <div class="field">
        <label for="email">Admin Email Address</label>
        <div class="input-wrap">
          <input id="email" type="email" autocomplete="username" placeholder="admin@decorly.com" required>
        </div>
      </div>
      <div class="field">
        <label for="password">Security Password</label>
        <div class="input-wrap">
          <input id="password" type="password" autocomplete="current-password" placeholder="Enter admin password" required>
          <button type="button" class="eye-btn" id="togglePass" aria-label="Show password">👁</button>
        </div>
      </div>
      <div id="error" class="error">Email or password does not match your saved admin profile. Please check credentials below.</div>
      <div class="rowline">
        <label class="remember"><input type="checkbox" id="remember" checked> Keep me signed in on this browser</label>
        <span class="d-u-index-1">Encrypted Session</span>
      </div>
      <button class="btn" type="submit">Open Executive Dashboard &nbsp;→</button>
    </form>
    
    <p class="note">Note: Credentials updated in <strong>My Profile &amp; Security</strong> inside the dashboard are automatically synced with this sign-in screen.</p>
  </section>
</main>


<script src="../assets/js/admin-index.js"></script>
</body>
</html>
