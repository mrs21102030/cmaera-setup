<?php require_once dirname(__DIR__) . '/db.php'; ?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta http-equiv="refresh" content="0;url=dashboard#blog"><title>Opening DECORLY Admin…</title>  <link rel="stylesheet" href="../assets/css/global.css">
  <link rel="stylesheet" href="../assets/css/admin-blog.css">
  <script src="../api/bootstrap-js.php"></script>
</head><body><p>Opening the single-page admin dashboard… <a href="dashboard#blog">Continue</a></p>
<script src="../assets/js/admin-blog.js"></script>
</body></html>