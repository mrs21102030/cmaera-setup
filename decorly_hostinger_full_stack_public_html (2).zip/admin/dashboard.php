<?php require_once dirname(__DIR__) . '/db.php'; ?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="theme-color" content="#071224">
<title>DECORLY Executive Admin Dashboard</title>
<link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700;800&family=Manrope:wght@400;500;600;700;800&family=Playfair+Display:ital,wght@1,500&display=swap" rel="stylesheet">




  <link rel="stylesheet" href="../assets/css/global.css">
  <link rel="stylesheet" href="../assets/css/admin-dashboard.css">
  <script src="../api/bootstrap-js.php"></script>
</head>
<body>
<!-- DECORLY Luxury Preloader -->
<div id="decorly-preloader" role="status" aria-live="polite" aria-label="Loading DECORLY">
  <div class="dl-ambient"></div>
  <div class="dl-emblem-wrap">
    <div class="dl-ring-outer"></div>
    <div class="dl-ring-inner"></div>
    <div class="dl-core"><span>D</span></div>
  </div>
  <div class="dl-brand">DECOR<b>LY</b></div>
  <div class="dl-tag">EXECUTIVE ADMIN SUITE</div>
  <div class="dl-track"><div class="dl-bar" id="decorlyLoaderBar"></div></div>
  <div class="dl-pct" id="decorlyLoaderPct">0%</div>
</div>


<div class="shell">
  <aside class="sidebar">
    <div class="brand-box">
      <a class="logo" href="dashboard">DECOR<span>LY</span></a>
      <span class="suite-pill">PRO</span>
    </div>
    <div class="tag">STORE CONTROL PANEL</div>

    <div class="side-profile-card" data-go="profile" title="Edit Admin Profile &amp; Password">
      <div class="avatar" id="sideAvatar">DA</div>
      <div class="side-prof-info">
        <strong id="sideAdminName">Store Administrator</strong>
        <small id="sideAdminRole">Chief Store Administrator</small>
      </div>
      <span class="side-prof-edit">✎</span>
    </div>

    <div class="group">Analytics &amp; Overview</div>
    <button class="nav active" data-view="overview"><span class="ico">▦</span><span class="navtext">Dashboard Overview</span></button>

    <div class="group">Store Management</div>
    <button class="nav" data-view="products"><span class="ico">▧</span><span class="navtext">Products</span><span class="nav-badge" id="sideProdBadge">6</span></button>
    <button class="nav" data-view="categories"><span class="ico">▤</span><span class="navtext">Categories</span><span class="nav-badge" id="sideCatBadge">9</span></button>
    <button class="nav" data-view="orders"><span class="ico">▣</span><span class="navtext">Orders</span><span class="nav-badge" id="sideOrdBadge">5</span></button>
    <button class="nav" data-view="customers"><span class="ico">👤</span><span class="navtext">Customers</span><span class="nav-badge" id="sideCustBadge">4</span></button>
    <button class="nav" data-view="inventory"><span class="ico">◫</span><span class="navtext">Inventory</span></button>

    <div class="group">Marketing &amp; Content</div>
    <button class="nav" data-view="coupons"><span class="ico">％</span><span class="navtext">Coupons</span></button>
    <button class="nav" data-view="reviews"><span class="ico">☆</span><span class="navtext">Reviews &amp; Enquiries</span></button>
    <button class="nav" data-view="banners"><span class="ico">▱</span><span class="navtext">Banners &amp; Hero</span></button>
    <button class="nav" data-view="blog"><span class="ico">✎</span><span class="navtext">Blog Posts</span></button>

    <div class="group">Account &amp; Configuration</div>
    <button class="nav" data-view="profile"><span class="ico">🛡️</span><span class="navtext">My Profile &amp; Security</span><span class="nav-badge new">EDIT</span></button>
    <button class="nav" data-view="payments"><span class="ico">＄</span><span class="navtext">Payments</span></button>
    <button class="nav" data-view="shipping"><span class="ico">⇢</span><span class="navtext">Shipping</span></button>
    <button class="nav" data-view="settings"><span class="ico">⚙</span><span class="navtext">Store Settings</span></button>

    <div class="sidebottom">
      <span>DECORLY Admin v3.0</span>
      <button class="logout-btn" id="logout">Sign out</button>
    </div>
  </aside>

  <main class="main">
    <header class="topbar">
      <div class="topbar-left">
        <div class="crumb">Workspace / <b id="crumb">Dashboard Overview</b></div>
        <div class="top-search-wrap">
          <span class="top-search-ico">🔍</span>
          <input type="search" class="top-search" id="globalJumpSearch" placeholder="Jump to section (products, orders, profile)...">
        </div>
      </div>
      <div class="topbar-right">
        <a class="live-store-btn" href="../" title="Open Customer Storefront">
          <i class="live-dot"></i><span>View Storefront ↗</span>
        </a>
        <button class="btn light small" data-go="profile">🛡️ Edit Profile</button>
        <div class="user-menu-wrap" id="userMenuWrap">
          <button type="button" class="user-trigger" id="userTrigger" aria-expanded="false">
            <span class="avatar" id="topAvatar">DA</span>
            <span class="user-meta">
              <strong id="topAdminName">Store Administrator</strong>
              <small id="topAdminRole">Chief Store Administrator</small>
            </span>
            <span class="user-caret">▾</span>
          </button>
          <div class="user-dropdown" id="userDropdown">
            <div class="ud-head">
              <strong id="dropAdminName">Store Administrator</strong>
              <span id="dropAdminEmail">admin@decorly.com</span>
            </div>
            <button type="button" class="ud-item" data-go="profile">👤 Edit Name &amp; Profile</button>
            <button type="button" class="ud-item" data-go="profile" data-focus-pass="1">🔑 Change Admin Password</button>
            <button type="button" class="ud-item" data-go="products">▧ Add / Edit Products</button>
            <button type="button" class="ud-item" data-go="settings">⚙ Store Preferences</button>
            <button type="button" class="ud-item danger" id="logoutDropdown">🚪 Sign Out of Admin</button>
          </div>
        </div>
      </div>
    </header>

    <div class="wrap">
      <!-- ================= VIEW 1: OVERVIEW & ANALYTICS ================= -->
      <section class="view active" id="view-overview">
        <div class="exec-hero">
          <div class="exec-hero-left">
            <p class="eyebrow">EXECUTIVE PERFORMANCE SUITE · LIVE ANALYTICS</p>
            <h1 id="heroGreeting">Welcome back, Store Administrator</h1>
            <p>Full control over products (with images, specs &amp; descriptions), categories, live customer orders, coupons, reviews, and administrator security.</p>
          </div>
          <div class="exec-hero-actions">
            <button class="btn gold" data-go="products" id="heroAddProdBtn">＋ Add New Product</button>
            <button class="btn glass" data-go="profile">🛡️ Edit Profile &amp; Password</button>
            <button class="btn glass" id="exportReportBtn">↓ Export Analytics CSV</button>
          </div>
        </div>

        <div class="stats">
          <div class="stat featured">
            <div class="stat-top"><div class="label">Total Store Revenue</div><div class="stat-ico">₨</div></div>
            <div class="num" id="kpiRevenue">PKR 482,500</div>
            <div class="stat-foot">
              <span class="trend">↑ 18.4% this month</span>
              <svg class="spark-svg" viewBox="0 0 82 28"><path d="M2 24 C18 22, 24 14, 38 15 C52 16, 62 6, 80 3" fill="none" stroke="#f3dfb6" stroke-width="2.5" stroke-linecap="round"/></svg>
            </div>
          </div>
          <div class="stat">
            <div class="stat-top"><div class="label">Total Orders</div><div class="stat-ico">▣</div></div>
            <div class="num" id="orderCount">5</div>
            <div class="stat-foot">
              <span class="trend">↑ Live checkout sync</span>
              <svg class="spark-svg" viewBox="0 0 82 28"><path d="M2 22 C16 18, 28 21, 42 12 C56 5, 68 9, 80 4" fill="none" stroke="#1f8b55" stroke-width="2.5" stroke-linecap="round"/></svg>
            </div>
          </div>
          <div class="stat">
            <div class="stat-top"><div class="label">Active Products</div><div class="stat-ico">▧</div></div>
            <div class="num" id="productCount">6</div>
            <div class="stat-foot">
              <span class="trend d-u-dashboard-1">Synced with Shop</span>
              <svg class="spark-svg" viewBox="0 0 82 28"><path d="M2 20 C20 19, 32 13, 48 14 C62 14, 70 7, 80 6" fill="none" stroke="#2563eb" stroke-width="2.5" stroke-linecap="round"/></svg>
            </div>
          </div>
          <div class="stat">
            <div class="stat-top"><div class="label">Registered Customers</div><div class="stat-ico">👤</div></div>
            <div class="num" id="customerCountKpi">4</div>
            <div class="stat-foot">
              <span class="trend">↑ Active accounts</span>
              <svg class="spark-svg" viewBox="0 0 82 28"><path d="M2 25 C18 20, 34 17, 48 11 C62 7, 72 8, 80 3" fill="none" stroke="#b97316" stroke-width="2.5" stroke-linecap="round"/></svg>
            </div>
          </div>
        </div>

        <div class="analytics-grid">
          <div class="panel">
            <div class="panelhead">
              <div>
                <h2>Revenue &amp; Orders Performance Graph</h2>
                <p class="panelhead-sub">Interactive store revenue curve (PKR) and order volume across periods</p>
              </div>
              <div class="chart-controls">
                <div class="seg-group" id="timeframeTabs">
                  <button type="button" class="seg-btn" data-tf="7d">7 Days</button>
                  <button type="button" class="seg-btn" data-tf="30d">30 Days</button>
                  <button type="button" class="seg-btn active" data-tf="12m">12 Months</button>
                </div>
                <div class="seg-group" id="chartTypeTabs">
                  <button type="button" class="seg-btn active" data-ctype="area">Area Curve</button>
                  <button type="button" class="seg-btn" data-ctype="bar">Bar Graph</button>
                </div>
              </div>
            </div>
            <div class="chart-legend-row">
              <div class="legend-items">
                <span><i class="legend-dot d-u-dashboard-2"></i>Revenue (PKR)</span>
                <span><i class="legend-dot d-u-dashboard-3"></i>Order Volume</span>
              </div>
              <span class="muted" id="chartPeriodSummary">Showing Jan – Dec 2026 · Hover any point for exact figures</span>
            </div>
            <div class="chart-stage" id="chartStage">
              <div class="chart-tooltip" id="chartTooltip">
                <strong id="ttLabel">Oct 2026</strong>
                <div class="tt-row"><span>Revenue:</span><b id="ttRev">PKR 68,500</b></div>
                <div class="tt-row"><span>Orders:</span><b id="ttOrd">24 orders</b></div>
                <div class="tt-row"><span>Avg. Order:</span><b id="ttAov">PKR 2,854</b></div>
              </div>
              <svg id="revenueSvg" viewBox="0 0 720 245" preserveAspectRatio="none"></svg>
            </div>
            <div class="chart-kpi-strip">
              <div class="ckpi"><small>Peak Period Revenue</small><strong id="ckpiPeak">PKR 84,500</strong><span>↑ Highest recorded</span></div>
              <div class="ckpi"><small>Avg. Order Value</small><strong id="ckpiAov">PKR 24,120</strong><span>↑ +6.4% vs prior</span></div>
              <div class="ckpi"><small>Conversion Rate</small><strong id="ckpiConv">4.82%</strong><span>↑ Storefront checkout</span></div>
              <div class="ckpi"><small>YoY Growth Index</small><strong id="ckpiGrowth">+24.6%</strong><span>↑ Strong momentum</span></div>
            </div>
          </div>

          <div class="panel">
            <div class="panelhead">
              <div>
                <h2>Sales by Category &amp; Fulfillment</h2>
                <p class="panelhead-sub">Hover segments to inspect category share</p>
              </div>
            </div>
            <div class="donut-wrap">
              <div class="donut-box">
                <svg viewBox="0 0 120 120" id="categoryDonutSvg">
                  <circle cx="60" cy="60" r="44" fill="none" stroke="#eef1f6" stroke-width="20"></circle>
                  <circle class="donut-seg" cx="60" cy="60" r="44" stroke="#102346" stroke-dasharray="121.6 154.8" stroke-dashoffset="0" data-cat="Tables Collection" data-pct="44%" data-val="PKR 212,300"></circle>
                  <circle class="donut-seg" cx="60" cy="60" r="44" stroke="#d5b77a" stroke-dasharray="77.4 199.0" stroke-dashoffset="-121.6" data-cat="Tea Trolleys" data-pct="28%" data-val="PKR 135,100"></circle>
                  <circle class="donut-seg" cx="60" cy="60" r="44" stroke="#1f8b55" stroke-dasharray="49.8 226.7" stroke-dashoffset="-199.0" data-cat="Storage Racks" data-pct="18%" data-val="PKR 86,850"></circle>
                  <circle class="donut-seg" cx="60" cy="60" r="44" stroke="#3b82f6" stroke-dasharray="27.6 248.8" stroke-dashoffset="-248.8" data-cat="Console & Dining" data-pct="10%" data-val="PKR 48,250"></circle>
                </svg>
                <div class="donut-center">
                  <strong id="donutCenterPct">44%</strong>
                  <small id="donutCenterLabel">Tables Share</small>
                </div>
              </div>
              <div class="donut-legend" id="donutLegend">
                <div class="dl-row" data-cat="Tables Collection" data-pct="44%" data-val="PKR 212,300"><span class="dl-row-left"><i class="dl-swatch d-u-dashboard-4"></i>Tables</span><span class="dl-row-val">44% · PKR 212k</span></div>
                <div class="dl-row" data-cat="Tea Trolleys" data-pct="28%" data-val="PKR 135,100"><span class="dl-row-left"><i class="dl-swatch d-u-dashboard-2"></i>Tea Trolleys</span><span class="dl-row-val">28% · PKR 135k</span></div>
                <div class="dl-row" data-cat="Storage Racks" data-pct="18%" data-val="PKR 86,850"><span class="dl-row-left"><i class="dl-swatch d-u-dashboard-3"></i>Storage Racks</span><span class="dl-row-val">18% · PKR 86.8k</span></div>
                <div class="dl-row" data-cat="Console & Dining" data-pct="10%" data-val="PKR 48,250"><span class="dl-row-left"><i class="dl-swatch d-u-dashboard-5"></i>Console &amp; Dining</span><span class="dl-row-val">10% · PKR 48.2k</span></div>
              </div>
            </div>
            <div class="funnel-box">
              <div class="funnel-title"><span>Live Order Status Distribution</span><span class="muted" id="funnelTotalText">5 total orders</span></div>
              <div id="orderStatusBars"></div>
            </div>
          </div>
        </div>

        <div class="grid2">
          <div class="panel">
            <div class="panelhead"><h2>Recent Orders</h2><button class="btn light small" data-go="orders">Manage All Orders →</button></div>
            <div class="tablewrap">
              <table>
                <thead><tr><th>Order</th><th>Customer</th><th>Total</th><th>Status</th><th>Action</th></tr></thead>
                <tbody id="recentOrders"></tbody>
              </table>
            </div>
          </div>
          <div class="panel">
            <div class="panelhead"><h2>Quick Executive Actions</h2><span class="muted">Instant workspace shortcuts</span></div>
            <div class="quickgrid d-u-dashboard-6">
              <button class="quick" data-go="products"><div class="quick-ico">＋</div><b>Add Product with Photos</b><span>Full specs, images &amp; description</span></button>
              <button class="quick" data-go="profile"><div class="quick-ico">🛡️</div><b>Edit Profile &amp; Password</b><span>Update name, email &amp; security</span></button>
              <button class="quick" data-go="orders"><div class="quick-ico">▣</div><b>Orders &amp; Invoices</b><span>View customer orders &amp; print</span></button>
              <button class="quick" data-go="coupons"><div class="quick-ico">％</div><b>Create Promo Coupon</b><span>Synced with Cart &amp; Checkout</span></button>
            </div>
          </div>
        </div>
      </section>

      <!-- ================= VIEW 2: MY PROFILE & SECURITY ================= -->
      <section class="view" id="view-profile">
        <div class="headrow">
          <div>
            <p class="eyebrow">ADMINISTRATOR ACCOUNT &amp; SECURITY</p>
            <h1>My Profile &amp; Password</h1>
            <p class="desc">Update your administrator display name, login email, avatar appearance, and security password. Changes sync immediately across the dashboard and login screen.</p>
          </div>
          <button class="btn light" id="resetAdminDefaultBtn">↺ Reset to Default Admin Credentials</button>
        </div>

        <div class="profile-layout">
          <aside class="prof-card">
            <div class="prof-avatar-lg" id="cardAvatarPreview">DA</div>
            <h3 id="cardNamePreview">Store Administrator</h3>
            <span class="prof-role-badge" id="cardRolePreview">Chief Store Administrator</span>
            <p class="prof-bio-text" id="cardBioPreview">Managing DECORLY luxury furniture catalog, storefront operations, and customer fulfillment across Pakistan.</p>
            <div class="prof-meta-list">
              <div class="pm-row"><span>Login Email</span><strong id="cardEmailPreview">admin@decorly.com</strong></div>
              <div class="pm-row"><span>Phone</span><strong id="cardPhonePreview">+92 300 8429000</strong></div>
              <div class="pm-row"><span>Location</span><strong id="cardCityPreview">Multan / Lahore, PK</strong></div>
              <div class="pm-row"><span>Password Status</span><strong id="cardPassStatus" class="d-u-dashboard-7">● Protected &amp; Synced</strong></div>
            </div>
            <div class="d-u-dashboard-8">Choose Avatar Color Theme</div>
            <div class="theme-swatches" id="avatarThemeSwatches">
              <button type="button" class="tswatch active d-u-dashboard-9" data-grad="linear-gradient(135deg,#d5b77a,#b58b4c)" data-fg="#081428"></button>
              <button type="button" class="tswatch d-u-dashboard-10" data-grad="linear-gradient(135deg,#102346,#264b8a)" data-fg="#f3dfb6"></button>
              <button type="button" class="tswatch d-u-dashboard-11" data-grad="linear-gradient(135deg,#136f47,#26a66c)" data-fg="#ffffff"></button>
              <button type="button" class="tswatch d-u-dashboard-12" data-grad="linear-gradient(135deg,#7c1d2e,#b83248)" data-fg="#ffffff"></button>
              <button type="button" class="tswatch d-u-dashboard-13" data-grad="linear-gradient(135deg,#4c1d95,#7c3aed)" data-fg="#ffffff"></button>
              <button type="button" class="tswatch d-u-dashboard-14" data-grad="linear-gradient(135deg,#1f2937,#4b5563)" data-fg="#f3dfb6"></button>
            </div>
            <div class="photo-upload-row">
              <label class="btn gold small d-u-dashboard-15">📷 Upload Photo<input type="file" id="adminPhotoInput" accept="image/*" hidden></label>
              <button type="button" class="btn glass small" id="removePhotoBtn">Remove Photo</button>
            </div>
          </aside>

          <div>
            <div class="panel">
              <div class="panelhead">
                <div><h2>Edit Personal Profile &amp; Display Name</h2><p class="panelhead-sub">Your name and role appear in the sidebar, topbar, welcome banner, and journal posts</p></div>
                <span class="pill green">Live Sync Enabled</span>
              </div>
              <form id="adminProfileForm" class="fields">
                <div class="field"><label for="adminNameInput">Administrator Full Name *</label><input id="adminNameInput" required maxlength="80"></div>
                <div class="field"><label for="adminRoleInput">Role / Designation *</label><input id="adminRoleInput" required maxlength="80"></div>
                <div class="field"><label for="adminEmailInput">Admin Sign-In Email *</label><input id="adminEmailInput" type="email" required maxlength="120"></div>
                <div class="field"><label for="adminPhoneInput">Contact Phone</label><input id="adminPhoneInput" type="tel" maxlength="40"></div>
                <div class="field"><label for="adminInitialsInput">Avatar Initials (2 Letters)</label><input id="adminInitialsInput" maxlength="3"></div>
                <div class="field"><label for="adminCityInput">Office / City</label><input id="adminCityInput" maxlength="80"></div>
                <div class="field full"><label for="adminBioInput">Administrator Bio / Executive Note</label><textarea id="adminBioInput" rows="3"></textarea></div>
                <div class="field full d-u-dashboard-16">
                  <span class="muted">Changes are immediately saved to browser storage and reflected across the header &amp; login page.</span>
                  <button type="submit" class="btn gold">💾 Save Profile &amp; Name</button>
                </div>
              </form>
            </div>

            <div class="panel" id="passwordPanel">
              <div class="panelhead">
                <div><h2>Change Admin Password &amp; Security</h2><p class="panelhead-sub">Update the password used to sign in on <code>admin/</code></p></div>
                <span class="pill blue" id="activePassHintPill">Current: Decorly@2026</span>
              </div>
              <form id="adminPasswordForm" class="fields">
                <div class="field full">
                  <label for="currentPassInput">Current Password *</label>
                  <div class="pass-wrap"><input id="currentPassInput" type="password" required placeholder="Enter current admin password"><button type="button" class="pass-toggle" data-toggle-pass="currentPassInput">👁</button></div>
                </div>
                <div class="field">
                  <label for="newPassInput">New Password *</label>
                  <div class="pass-wrap"><input id="newPassInput" type="password" required minlength="6" placeholder="Enter new password"><button type="button" class="pass-toggle" data-toggle-pass="newPassInput">👁</button></div>
                  <div class="strength-bars" id="strengthBars"><div class="sbar"></div><div class="sbar"></div><div class="sbar"></div><div class="sbar"></div></div>
                  <div class="strength-text"><span id="strengthLabel">Password strength</span><span id="strengthScore">0/4</span></div>
                  <div class="req-chips">
                    <span class="rchip" id="reqLen">6+ chars</span>
                    <span class="rchip" id="reqCase">Upper &amp; Lower</span>
                    <span class="rchip" id="reqNum">Number</span>
                    <span class="rchip" id="reqSym">Symbol (@#$!)</span>
                  </div>
                </div>
                <div class="field">
                  <label for="confirmPassInput">Confirm New Password *</label>
                  <div class="pass-wrap"><input id="confirmPassInput" type="password" required minlength="6" placeholder="Re-enter new password"><button type="button" class="pass-toggle" data-toggle-pass="confirmPassInput">👁</button></div>
                  <p class="muted d-u-dashboard-17" id="passMatchMsg">Re-type your new password to confirm.</p>
                </div>
                <div class="field full d-u-dashboard-16">
                  <span class="muted">Tip: Once updated, use your new password next time you sign in at <code>admin/</code>.</span>
                  <button type="submit" class="btn">🔐 Update Admin Password</button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </section>

      <!-- ================= VIEW 3: PRODUCTS (COMPLETE STUDIO WITH IMAGES, SPECS, DESCRIPTIONS) ================= -->
      <section class="view" id="view-products">
        <div class="headrow">
          <div>
            <p class="eyebrow">COMPLETE CATALOG STUDIO</p>
            <h1>Products Management</h1>
            <p class="desc">Add or edit furniture products with primary &amp; gallery photos, SKU, regular &amp; sale prices, dimensions, materials, finishes, and full descriptions. Syncs directly with the customer storefront.</p>
          </div>
          <button class="btn gold" id="newProduct">＋ Add New Product</button>
        </div>

        <div class="panel" id="productEditor" hidden>
          <div class="panelhead">
            <div>
              <h2 id="productFormHeading">Add New Furniture Product</h2>
              <p class="panelhead-sub">Complete all product specifications, photography, and pricing details below</p>
            </div>
            <button class="btn light small" type="button" id="cancelProductTop">✕ Close Editor</button>
          </div>
          <form id="productForm" class="fields cols3">
            <input type="hidden" name="editIndex" id="prodEditIndex" value="-1">
            <div class="field d-u-dashboard-18">
              <label>Product Title / Name *</label>
              <input name="name" id="prodName" required placeholder="e.g. Luxury Gold 2-Tier Tea Trolley with Marble Trays">
            </div>
            <div class="field">
              <label>URL Slug (Auto-generated)</label>
              <input name="slug" id="prodSlug" placeholder="luxury-gold-2-tier-tea-trolley">
            </div>

            <div class="field">
              <label>SKU / Reference Code *</label>
              <input name="sku" id="prodSku" required placeholder="e.g. DEC-TT-108">
            </div>
            <div class="field">
              <label>Furniture Category *</label>
              <select name="category" id="prodCategory" required>
                <option value="Tea Trolleys" data-slug="tea-trolleys">Tea Trolleys</option>
                <option value="Coffee Tables" data-slug="coffee-tables">Coffee Tables</option>
                <option value="Nesting Tables" data-slug="nesting-tables">Nesting Tables</option>
                <option value="Console Tables" data-slug="console-tables">Console Tables</option>
                <option value="Dining Tables" data-slug="dining-tables">Dining Tables</option>
                <option value="Laptop Tables" data-slug="laptop-tables">Laptop Tables</option>
                <option value="Kitchen Oven Racks" data-slug="kitchen-oven-racks">Kitchen Oven Racks</option>
                <option value="Corner Racks" data-slug="corner-racks">Corner Racks</option>
                <option value="Tea Tables" data-slug="tea-tables">Tea Tables</option>
              </select>
            </div>
            <div class="field">
              <label>Product Badge / Highlight</label>
              <select name="badge" id="prodBadge">
                <option value="SIGNATURE EDIT">SIGNATURE EDIT (Featured)</option>
                <option value="DECORLY EDIT">DECORLY EDIT (Standard)</option>
                <option value="NEW ARRIVAL">NEW ARRIVAL</option>
                <option value="BEST SELLER">BEST SELLER</option>
                <option value="LIMITED EDITION">LIMITED EDITION</option>
              </select>
            </div>

            <div class="field">
              <label>Regular Price (PKR) *</label>
              <input name="price" id="prodPrice" type="number" min="1" required placeholder="e.g. 22500">
            </div>
            <div class="field">
              <label>Sale / Discounted Price (PKR — Optional)</label>
              <input name="salePrice" id="prodSalePrice" type="number" min="0" placeholder="Leave blank if not on sale">
            </div>
            <div class="field">
              <label>Stock Quantity *</label>
              <input name="stock" id="prodStock" type="number" min="0" value="10" required>
            </div>

            <!-- Primary Image Upload + URL -->
            <div class="field full">
              <label>Primary Product Photograph (Upload Image File OR Paste Image URL) *</label>
              <div class="img-upload-box">
                <div class="img-preview-box" id="prodImgPreview"><span>No Photo</span></div>
                <div class="d-u-dashboard-19">
                  <div class="d-u-dashboard-20">
                    <label class="btn gold small d-u-dashboard-15">
                      📷 Upload Product Image from Computer
                      <input type="file" id="prodImageFile" accept="image/*" hidden>
                    </label>
                    <button type="button" class="btn light small" id="clearProdImgBtn">Reset Image</button>
                  </div>
                  <input name="image" id="prodImageUrl" placeholder="Or paste direct image URL (https://...)" value="https://images.unsplash.com/photo-1499933374294-4584851497cc?auto=format&fit=crop&w=900&q=85">
                  <small class="field-hint">Uploaded image or URL is displayed on Shop cards, Category pages, and the Single Product gallery.</small>
                </div>
              </div>
            </div>

            <div class="field full">
              <label>Additional Gallery Image URLs (Optional — comma separated for Product Lightbox Gallery)</label>
              <input name="gallery" id="prodGallery" placeholder="https://images.unsplash.com/photo-1..., https://images.unsplash.com/photo-2...">
            </div>

            <!-- Specifications -->
            <div class="field">
              <label>Available Finishes / Colors (comma separated)</label>
              <input name="finish" id="prodFinish" placeholder="e.g. Brushed Gold & Black Glass, Warm Walnut, Matte Black" value="Brushed Gold & Tempered Glass">
            </div>
            <div class="field">
              <label>Material &amp; Construction</label>
              <input name="material" id="prodMaterial" placeholder="e.g. Powder-Coated Steel Frame & 8mm Tempered Glass" value="Heavy-Gauge Powder-Coated Steel & Tempered Glass">
            </div>
            <div class="field">
              <label>Dimensions (L × W × H)</label>
              <input name="dimensions" id="prodDimensions" placeholder="e.g. 76 cm × 44 cm × 82 cm" value="76 cm × 44 cm × 82 cm">
            </div>

            <div class="field">
              <label>Weight &amp; Load Capacity</label>
              <input name="weight" id="prodWeight" placeholder="e.g. 12.5 kg (Max load 45 kg)" value="12.5 kg">
            </div>
            <div class="field">
              <label>Warranty Coverage</label>
              <input name="warranty" id="prodWarranty" placeholder="e.g. 1 Year Structural & Finish Warranty" value="1 Year Structural Warranty">
            </div>
            <div class="field">
              <label>Catalog Visibility Status</label>
              <select name="status" id="prodStatus">
                <option value="Published">Published (Visible on Store)</option>
                <option value="Draft">Draft (Hidden)</option>
              </select>
            </div>

            <!-- Short & Full Descriptions -->
            <div class="field full">
              <label>Short Summary / Lead Highlight *</label>
              <input name="short" id="prodShort" required maxlength="220" placeholder="1–2 sentence summary shown below the product title on the product page..." value="An expressive addition to your living space, pairing architectural steel proportions with refined everyday utility.">
            </div>
            <div class="field full">
              <label>Full Detailed Product Description &amp; Care Instructions *</label>
              <textarea name="description" id="prodDesc" required rows="4" placeholder="Write complete product story, styling tips, craftsmanship details, and care instructions...">Crafted for modern Pakistani homes, this signature DECORLY piece balances visual lightness with enduring structural strength. Hand-finished frame detailing and easy-clean surfaces make it ideal for both everyday family living and formal hosting.</textarea>
            </div>

            <div class="field full d-u-dashboard-21">
              <button class="btn light" type="button" id="cancelProduct">Cancel</button>
              <button class="btn gold" type="submit">💾 Save Product to Catalog</button>
            </div>
          </form>
        </div>

        <div class="panel">
          <div class="panelhead">
            <h2>Store Product Catalog (<span id="prodTableCount">0</span> items)</h2>
            <div class="d-u-dashboard-22">
              <select class="search d-u-dashboard-23" id="productCatFilter">
                <option value="">All Categories</option>
                <option>Tea Trolleys</option><option>Coffee Tables</option><option>Nesting Tables</option>
                <option>Console Tables</option><option>Dining Tables</option><option>Laptop Tables</option>
                <option>Kitchen Oven Racks</option><option>Corner Racks</option><option>Tea Tables</option>
              </select>
              <input class="search" id="productSearch" placeholder="Search by name, SKU, finish…">
            </div>
          </div>
          <div class="tablewrap">
            <table>
              <thead><tr><th>Product &amp; Specs</th><th>Category</th><th>Pricing (PKR)</th><th>Stock</th><th>Visibility</th><th>Actions</th></tr></thead>
              <tbody id="productsRows"></tbody>
            </table>
          </div>
        </div>
      </section>

      <!-- ================= VIEW 4: CATEGORIES (COMPLETE FORM WITH IMAGE & DESCRIPTION) ================= -->
      <section class="view" id="view-categories">
        <div class="headrow">
          <div>
            <p class="eyebrow">PRODUCT ORGANIZATION</p>
            <h1>Categories &amp; Collections</h1>
            <p class="desc">Create and edit furniture categories with cover imagery, URL slugs, parent groups, and descriptions.</p>
          </div>
          <button class="btn gold" id="addCategory">＋ Add New Category</button>
        </div>

        <div class="panel" id="categoryEditor" hidden>
          <div class="panelhead">
            <h2 id="catFormTitle">Add / Edit Category</h2>
            <button type="button" class="btn light small" id="cancelCatBtn">✕ Close</button>
          </div>
          <form id="categoryForm" class="fields">
            <input type="hidden" id="catEditIndex" value="-1">
            <div class="field"><label>Category Name *</label><input id="catName" required placeholder="e.g. Coffee Tables"></div>
            <div class="field"><label>URL Slug *</label><input id="catSlug" required placeholder="e.g. coffee-tables"></div>
            <div class="field">
              <label>Parent Furniture Group</label>
              <select id="catGroup"><option>Tables</option><option>Racks</option><option>Trolleys</option><option>Decor &amp; Accents</option></select>
            </div>
            <div class="field"><label>Status</label><select id="catStatus"><option>Active</option><option>Hidden</option></select></div>
            <div class="field full"><label>Subcategories / Style Tags</label><input id="catSubs" placeholder="e.g. Round, Marble Top, Solid Walnut, Glass Top"></div>
            <div class="field full">
              <label>Category Cover Photograph (Upload Image OR Paste URL)</label>
              <div class="img-upload-box">
                <div class="img-preview-box" id="catImgPreview"><span>Cover</span></div>
                <div class="d-u-dashboard-24">
                  <label class="btn gold small d-u-dashboard-25">📷 Upload Cover Photo<input type="file" id="catImageFile" accept="image/*" hidden></label>
                  <input id="catImageUrl" placeholder="https://images.unsplash.com/...">
                </div>
              </div>
            </div>
            <div class="field full"><label>Category Editorial Description</label><textarea id="catDesc" rows="3" placeholder="Displayed at the top of the category collection page..."></textarea></div>
            <div class="field full"><button type="submit" class="btn gold">💾 Save Category</button></div>
          </form>
        </div>

        <div class="panel">
          <div class="tablewrap">
            <table>
              <thead><tr><th>Category &amp; Slug</th><th>Parent Group</th><th>Subcategories</th><th>Products</th><th>Status</th><th>Actions</th></tr></thead>
              <tbody id="categoryRows"></tbody>
            </table>
          </div>
        </div>
      </section>

      <!-- ================= VIEW 5: ORDERS (WITH INVOICE MODAL & MANUAL ORDER CREATOR) ================= -->
      <section class="view" id="view-orders">
        <div class="headrow">
          <div>
            <p class="eyebrow">SALES &amp; FULFILLMENT</p>
            <h1>Orders &amp; Invoices</h1>
            <p class="desc">Customer orders placed on Checkout automatically appear here. Inspect itemized invoices, update delivery status, or record a manual phone/WhatsApp order.</p>
          </div>
          <div class="d-u-dashboard-22">
            <input class="search" id="orderSearch" placeholder="Search order ID, customer, city…">
            <button class="btn gold" id="newManualOrderBtn">＋ Create Manual Order</button>
          </div>
        </div>

        <div class="panel" id="manualOrderEditor" hidden>
          <div class="panelhead"><h2>Create Manual / Phone Order</h2><button type="button" class="btn light small" id="cancelManualOrder">✕ Close</button></div>
          <form id="manualOrderForm" class="fields cols3">
            <div class="field"><label>Customer Full Name *</label><input id="moName" required placeholder="e.g. Bilal Ahmed"></div>
            <div class="field"><label>Customer Phone *</label><input id="moPhone" required placeholder="+92 300 1234567"></div>
            <div class="field"><label>Customer Email</label><input id="moEmail" type="email" placeholder="customer@example.com"></div>
            <div class="field"><label>Delivery City *</label><input id="moCity" required placeholder="e.g. Lahore / Multan / Karachi"></div>
            <div class="field d-u-dashboard-18"><label>Street Address *</label><input id="moAddress" required placeholder="House #, Street, Sector/Area"></div>
            <div class="field"><label>Product Ordered *</label><input id="moProduct" required placeholder="e.g. Luxury Gold 2-Tier Tea Trolley"></div>
            <div class="field"><label>Total Amount (PKR) *</label><input id="moTotal" type="number" min="1" required placeholder="18500"></div>
            <div class="field"><label>Payment Method</label><select id="moPayment"><option>Cash on Delivery (COD)</option><option>Bank Transfer (IBAN)</option><option>JazzCash / EasyPaisa</option></select></div>
            <div class="field full"><button type="submit" class="btn gold">💾 Save Order</button></div>
          </form>
        </div>

        <div class="panel">
          <div class="tablewrap">
            <table>
              <thead><tr><th>Order ID</th><th>Customer &amp; City</th><th>Date</th><th>Payment</th><th>Total</th><th>Status</th><th>Update Status</th><th>Invoice</th></tr></thead>
              <tbody id="ordersRows"></tbody>
            </table>
          </div>
        </div>
      </section>

      <!-- ================= VIEW 6: CUSTOMERS (WITH ADD/EDIT CUSTOMER FORM) ================= -->
      <section class="view" id="view-customers">
        <div class="headrow">
          <div>
            <p class="eyebrow">CUSTOMER RELATIONSHIPS</p>
            <h1>Customers Directory</h1>
            <p class="desc">View and manage registered customer accounts, contact details, and lifetime spend.</p>
          </div>
          <div class="d-u-dashboard-22">
            <input class="search" id="customerSearch" placeholder="Search customers…">
            <button class="btn gold" id="newCustomerBtn">＋ Add Customer</button>
          </div>
        </div>

        <div class="panel" id="customerEditor" hidden>
          <div class="panelhead"><h2 id="custFormTitle">Add / Edit Customer</h2><button type="button" class="btn light small" id="cancelCustomerBtn">✕ Close</button></div>
          <form id="customerForm" class="fields">
            <input type="hidden" id="custEditIndex" value="-1">
            <div class="field"><label>Full Name *</label><input id="custName" required placeholder="e.g. Ayesha Noor"></div>
            <div class="field"><label>Email Address *</label><input id="custEmail" type="email" required placeholder="ayesha@example.com"></div>
            <div class="field"><label>Phone Number *</label><input id="custPhone" required placeholder="+92 300 0000000"></div>
            <div class="field"><label>City / Location</label><input id="custCity" placeholder="Lahore, Pakistan"></div>
            <div class="field"><label>Customer Segment</label><select id="custType"><option>Returning</option><option>VIP</option><option>New</option></select></div>
            <div class="field"><label>Total Spent (PKR)</label><input id="custSpent" type="number" min="0" value="0"></div>
            <div class="field full"><button type="submit" class="btn gold">💾 Save Customer</button></div>
          </form>
        </div>

        <div class="panel">
          <div class="tablewrap">
            <table>
              <thead><tr><th>Customer</th><th>Email &amp; Phone</th><th>City</th><th>Orders</th><th>Total Spent</th><th>Segment</th><th>Actions</th></tr></thead>
              <tbody id="customerRows"></tbody>
            </table>
          </div>
        </div>
      </section>

      <!-- ================= VIEW 7: INVENTORY (INLINE STOCK & SKU CONTROL) ================= -->
      <section class="view" id="view-inventory">
        <div class="headrow">
          <div>
            <p class="eyebrow">STOCK CONTROL</p>
            <h1>Live Inventory Manager</h1>
            <p class="desc">Adjust stock quantities and SKU codes directly in the table below. Changes sync immediately with Products.</p>
          </div>
          <button class="btn light" id="stockRefresh">↻ Sync Inventory</button>
        </div>
        <div class="panel">
          <div class="tablewrap">
            <table>
              <thead><tr><th>Product</th><th>SKU Code</th><th>Category</th><th>Quick Adjust Stock</th><th>Stock Health</th><th>Action</th></tr></thead>
              <tbody id="inventoryRows"></tbody>
            </table>
          </div>
        </div>
      </section>

      <!-- ================= VIEW 8: COUPONS (FULL FORM SYNCED WITH CART/CHECKOUT) ================= -->
      <section class="view" id="view-coupons">
        <div class="headrow">
          <div>
            <p class="eyebrow">PROMOTIONS &amp; DISCOUNTS</p>
            <h1>Promo Coupons</h1>
            <p class="desc">Create percentage or fixed PKR discount codes. Active coupons can be applied directly by shoppers in Cart and Checkout!</p>
          </div>
          <button class="btn gold" id="newCoupon">＋ Create New Coupon</button>
        </div>

        <div class="panel" id="couponEditor" hidden>
          <div class="panelhead"><h2 id="couponFormTitle">Create / Edit Promo Coupon</h2><button type="button" class="btn light small" id="cancelCouponBtn">✕ Close</button></div>
          <form id="couponForm" class="fields cols3">
            <input type="hidden" id="couponEditIndex" value="-1">
            <div class="field"><label>Coupon Code *</label><input id="cpCode" required placeholder="e.g. SUMMER20" class="d-u-dashboard-26"></div>
            <div class="field"><label>Discount Type *</label><select id="cpType"><option value="percent">Percentage Discount (%)</option><option value="fixed">Fixed Amount (PKR)</option></select></div>
            <div class="field"><label>Discount Value *</label><input id="cpValue" type="number" min="1" required placeholder="e.g. 15 or 2500"></div>
            <div class="field"><label>Min. Order Subtotal (PKR)</label><input id="cpMin" type="number" min="0" value="5000"></div>
            <div class="field"><label>Valid Until Date</label><input id="cpExpiry" type="date" value="2026-12-31"></div>
            <div class="field"><label>Status</label><select id="cpStatus"><option>Active</option><option>Draft</option><option>Expired</option></select></div>
            <div class="field full"><button type="submit" class="btn gold">💾 Save Coupon</button></div>
          </form>
        </div>

        <div class="panel">
          <div class="tablewrap">
            <table>
              <thead><tr><th>Code</th><th>Type</th><th>Discount</th><th>Min. Order</th><th>Valid Until</th><th>Status</th><th>Actions</th></tr></thead>
              <tbody id="couponRows"></tbody>
            </table>
          </div>
        </div>
      </section>

      <!-- ================= VIEW 9: REVIEWS & CUSTOMER ENQUIRIES ================= -->
      <section class="view" id="view-reviews">
        <div class="headrow">
          <div>
            <p class="eyebrow">CUSTOMER FEEDBACK &amp; MESSAGES</p>
            <h1>Product Reviews &amp; Enquiries</h1>
            <p class="desc">Moderate product reviews, post official DECORLY responses, and view customer contact enquiries submitted from the Contact Us page.</p>
          </div>
          <button class="btn gold" id="newReviewBtn">＋ Add Product Review</button>
        </div>

        <div class="panel" id="reviewEditor" hidden>
          <div class="panelhead"><h2>Add / Edit Product Review</h2><button type="button" class="btn light small" id="cancelReviewBtn">✕ Close</button></div>
          <form id="reviewForm" class="fields">
            <input type="hidden" id="revEditIndex" value="-1">
            <div class="field"><label>Customer Name *</label><input id="revCustomer" required placeholder="e.g. Sara Malik"></div>
            <div class="field"><label>Product Name *</label><input id="revProduct" required placeholder="e.g. Modern Tea Table"></div>
            <div class="field"><label>Star Rating *</label><select id="revRating"><option value="5">★★★★★ (5 Stars)</option><option value="4">★★★★☆ (4 Stars)</option><option value="3">★★★☆☆ (3 Stars)</option><option value="2">★★☆☆☆ (2 Stars)</option><option value="1">★☆☆☆☆ (1 Star)</option></select></div>
            <div class="field"><label>Status</label><select id="revStatus"><option>Approved</option><option>Pending</option></select></div>
            <div class="field full"><label>Customer Review Comment *</label><textarea id="revComment" rows="3" required placeholder="Customer feedback..."></textarea></div>
            <div class="field full"><label>Official DECORLY Reply (Optional)</label><input id="revReply" placeholder="Thank you for choosing DECORLY!"></div>
            <div class="field full"><button type="submit" class="btn gold">💾 Save Review</button></div>
          </form>
        </div>

        <div class="panel">
          <div class="panelhead"><h2>Product Reviews</h2></div>
          <div class="tablewrap">
            <table>
              <thead><tr><th>Customer</th><th>Product</th><th>Rating</th><th>Review &amp; Reply</th><th>Status</th><th>Moderation</th></tr></thead>
              <tbody id="reviewRows"></tbody>
            </table>
          </div>
        </div>

        <div class="panel">
          <div class="panelhead"><h2>Customer Contact Form Enquiries</h2><span class="muted">Submitted via Contact Us page</span></div>
          <div class="tablewrap">
            <table>
              <thead><tr><th>Date</th><th>Name &amp; Email</th><th>Phone &amp; Topic</th><th>Message</th><th>Action</th></tr></thead>
              <tbody id="enquiryRows"></tbody>
            </table>
          </div>
        </div>
      </section>

      <!-- ================= VIEW 10: BANNERS & HERO CAMPAIGNS ================= -->
      <section class="view" id="view-banners">
        <div class="headrow">
          <div>
            <p class="eyebrow">SITE CONTENT &amp; VISUAL MERCHANDISING</p>
            <h1>Banners &amp; Hero Campaigns</h1>
            <p class="desc">Configure homepage promo banners with background imagery, headlines, CTA links, and live visual preview.</p>
          </div>
          <button class="btn gold" id="saveBanner">💾 Save Active Banner</button>
        </div>

        <div class="panel">
          <div class="panelhead"><h2>Live Campaign Banner Preview</h2><span class="pill green" id="bannerLiveBadge">Published</span></div>
          <div id="bannerVisualPreview" class="d-u-dashboard-27">
            <div class="d-u-dashboard-28">
              <span id="prevBannerEyebrow" class="d-u-dashboard-29">LIMITED TIME CURATION</span>
              <h3 id="prevBannerTitle" class="d-u-dashboard-30">Furniture made for living beautifully</h3>
              <p id="prevBannerDesc" class="d-u-dashboard-31">Discover thoughtfully designed pieces for every corner of your home.</p>
            </div>
            <span class="btn gold d-u-dashboard-32" id="prevBannerBtn">Explore collection →</span>
          </div>
        </div>

        <div class="panel">
          <form class="fields" id="bannerForm">
            <div class="field"><label>Campaign Eyebrow</label><input value="LIMITED TIME CURATION" id="bannerEyebrow"></div>
            <div class="field"><label>Banner Headline *</label><input value="Furniture made for living beautifully" id="bannerTitle" required></div>
            <div class="field"><label>CTA Button Label</label><input value="Explore collection" id="bannerButton"></div>
            <div class="field"><label>CTA Target Link</label><input value="shop" id="bannerLink"></div>
            <div class="field full">
              <label>Banner Background Image (Upload File OR Paste URL)</label>
              <div class="img-upload-box">
                <div class="img-preview-box" id="bannerImgThumb"><span>Hero</span></div>
                <div class="d-u-dashboard-24">
                  <label class="btn gold small d-u-dashboard-25">📷 Upload Banner Image<input type="file" id="bannerImageFile" accept="image/*" hidden></label>
                  <input id="bannerImageUrl" placeholder="https://images.unsplash.com/..." value="https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?auto=format&fit=crop&w=1400&q=80">
                </div>
              </div>
            </div>
            <div class="field full"><label>Banner Description</label><textarea id="bannerDesc">Discover thoughtfully designed pieces for every corner of your home.</textarea></div>
            <div class="field"><label>Placement Zone</label><select id="bannerPlacement"><option>Homepage Hero / Promo Strip</option><option>Shop Page Top Banner</option><option>Sitewide Announcement Bar</option></select></div>
            <div class="field"><label>Campaign Status</label><select id="bannerStatus"><option>Published</option><option>Draft</option></select></div>
          </form>
        </div>
      </section>

      <!-- ================= VIEW 11: BLOG POSTS (WITH IMAGE UPLOAD & STOREFRONT SYNC) ================= -->
      <section class="view" id="view-blog">
        <div class="headrow"><div><p class="eyebrow">EDITORIAL STUDIO</p><h1>Blog Posts</h1><p class="desc">Create, edit, publish and delete journal posts with featured images. Published posts automatically sync to the customer Blog page.</p></div><button class="btn gold" id="newPost">＋ Add New Post</button></div>
        <div class="panel d-u-dashboard-33" id="postEditor">
          <div class="panelhead"><h2 id="postFormTitle">Create blog post</h2><button type="button" class="btn light small" id="cancelPost">Cancel</button></div>
          <form id="postForm" class="fields">
            <input type="hidden" id="postId">
            <div class="field full"><label for="postTitle">Post title *</label><input id="postTitle" required maxlength="140" placeholder="e.g. How to Style a Small Living Room"></div>
            <div class="field"><label for="postSlug">URL slug</label><input id="postSlug" placeholder="how-to-style-a-small-living-room"></div>
            <div class="field"><label for="postAuthor">Author</label><input id="postAuthor" value="DECORLY Team" required></div>
            <div class="field"><label for="postCategory">Category</label><select id="postCategory"><option>Interior Design</option><option>Furniture Guide</option><option>Home Styling</option><option>Buying Advice</option><option>News</option></select></div>
            <div class="field"><label for="postStatus">Status</label><select id="postStatus"><option value="Published">Published</option><option value="Draft">Draft</option></select></div>
            <div class="field full">
              <label for="postImage">Featured Cover Image (Upload Photo OR Paste URL)</label>
              <div class="img-upload-box">
                <div class="img-preview-box" id="blogImgPreview"><span>Blog</span></div>
                <div class="d-u-dashboard-24">
                  <label class="btn gold small d-u-dashboard-25">📷 Upload Article Cover<input type="file" id="blogImageFile" accept="image/*" hidden></label>
                  <input id="postImage" placeholder="https://images.unsplash.com/..." value="https://images.unsplash.com/photo-1499933374294-4584851497cc?auto=format&fit=crop&w=1200&q=85">
                </div>
              </div>
            </div>
            <div class="field full"><label for="postExcerpt">Short excerpt *</label><textarea id="postExcerpt" required rows="3" placeholder="A short summary shown on blog cards..."></textarea></div>
            <div class="field full"><label for="postContent">Full article content *</label><textarea id="postContent" required rows="8" placeholder="Write the full blog post here..."></textarea></div>
            <div class="field full d-u-dashboard-22"><button class="btn gold" type="submit">💾 Save Post</button><button class="btn light" type="button" id="cancelPost2">Cancel</button></div>
          </form>
        </div>
        <div class="panel"><div class="panelhead"><h2>All blog posts</h2><span class="desc" id="postCount">0 posts</span></div><div class="tablewrap"><table><thead><tr><th>Post</th><th>Author</th><th>Category</th><th>Updated</th><th>Status</th><th>Actions</th></tr></thead><tbody id="blogRows"></tbody></table></div><p class="desc d-u-dashboard-34" id="blogEmpty">No posts yet. Select “Add New Post” to create your first article.</p></div>
      </section>

      <!-- ================= VIEW 12: PAYMENTS (COMPLETE PAKISTANI GATEWAY FIELDS) ================= -->
      <section class="view" id="view-payments">
        <div class="headrow"><div><p class="eyebrow">CHECKOUT CONFIGURATION</p><h1>Payment Methods</h1><p class="desc">Configure Cash on Delivery, Bank Transfer IBAN details, and Mobile Wallet numbers shown to customers at Checkout.</p></div><button class="btn gold" id="savePayments">💾 Save Payment Settings</button></div>
        <div class="panel">
          <div class="fields">
            <div class="field"><label>Cash on Delivery (COD)</label><select id="cod"><option>Enabled</option><option>Disabled</option></select></div>
            <div class="field"><label>Direct Bank Transfer</label><select id="bank"><option>Enabled</option><option>Disabled</option></select></div>
            <div class="field"><label>Bank Name</label><input id="bankName" value="Meezan Bank / HBL Pakistan"></div>
            <div class="field"><label>Bank Account Title</label><input id="bankTitle" value="DECORLY FURNITURE STUDIO"></div>
            <div class="field"><label>IBAN / Account Number</label><input id="bankIban" value="PK36 MEZN 0001 2345 6789 0102"></div>
            <div class="field"><label>JazzCash / EasyPaisa Wallet Number</label><input id="walletNum" value="+92 300 8429000 (DECORLY Official)"></div>
            <div class="field"><label>Online Card Gateway</label><select id="gateway"><option>Active (Hostinger SSL Gateway)</option><option>Not connected</option></select></div>
            <div class="field"><label>Store Currency</label><select id="currency"><option>PKR — Pakistani Rupee</option><option>USD — US Dollar</option></select></div>
          </div>
        </div>
      </section>

      <!-- ================= VIEW 13: SHIPPING ================= -->
      <section class="view" id="view-shipping">
        <div class="headrow"><div><p class="eyebrow">DELIVERY RULES</p><h1>Shipping &amp; Logistics</h1><p class="desc">Set standard delivery fee and free-shipping threshold (synced live with Customer Cart &amp; Checkout).</p></div><button class="btn gold" id="saveShipping">💾 Save Shipping Rules</button></div>
        <div class="panel">
          <div class="fields">
            <div class="field"><label>Standard Delivery Fee (PKR)</label><input id="shipFee" type="number" value="350"></div>
            <div class="field"><label>Free Shipping Threshold (PKR)</label><input id="shipThreshold" type="number" value="25000"></div>
            <div class="field"><label>Estimated Delivery Window</label><select id="shipTime"><option>3–5 business days</option><option>5–7 business days</option><option>1–2 business days (Express)</option></select></div>
            <div class="field"><label>Shipping Status</label><select id="shipEnabled"><option>Enabled</option><option>Disabled</option></select></div>
            <div class="field"><label>Primary Courier Partners</label><input id="shipCourier" value="TCS Logistics, Leopards Heavy Cargo & DECORLY Fleet"></div>
            <div class="field"><label>Serviceable Regions</label><input id="shipRegions" value="All Major Cities across Punjab, Sindh, KPK & Islamabad"></div>
          </div>
        </div>
      </section>

      <!-- ================= VIEW 14: STORE SETTINGS ================= -->
      <section class="view" id="view-settings">
        <div class="headrow"><div><p class="eyebrow">CONFIGURATION</p><h1>Store Settings</h1><p class="desc">Update general store information, contact channels, and admin preferences.</p></div><div class="d-u-dashboard-35"><button class="btn light" data-go="profile">🛡️ Edit Admin Profile &amp; Password</button><button class="btn gold" id="saveSettings">💾 Save Changes</button></div></div>
        <div class="panel"><div class="panelhead"><h2>General Information &amp; Contact Channels</h2></div><form id="settingsForm" class="fields"><div class="field"><label>Store Name</label><input id="storeName" value="DECORLY" required></div><div class="field"><label>Support Email</label><input id="supportEmail" type="email" value="support@decorly.com"></div><div class="field"><label>Contact Phone / WhatsApp</label><input id="storePhone" value="+92 300 8429000"></div><div class="field"><label>Default Currency</label><select id="storeCurrency"><option>PKR</option><option>USD</option></select></div><div class="field"><label>Timezone</label><select id="timezone"><option>Asia/Karachi (PKT)</option><option>UTC</option></select></div><div class="field"><label>Store Status</label><select id="storeStatus"><option>Open</option><option>Maintenance mode</option></select></div><div class="field full"><label>Showroom / Studio Address</label><textarea id="storeAddress">DECORLY Design Studio, Gulgasht / Bosan Road, Multan & Gulberg III, Lahore, Pakistan</textarea></div></form></div>
        <div class="panel"><div class="panelhead"><h2>Admin Preferences</h2></div><div class="fields"><div class="field"><label>Dashboard Notifications</label><select id="notifications"><option>Enabled</option><option>Disabled</option></select></div><div class="field"><label>Low-Stock Alert Threshold</label><input id="lowStock" type="number" value="5" min="0"></div></div></div>
      </section>
    </div>
  </main>
</div>

<!-- Order Invoice / Details Modal -->
<div class="admin-modal" id="orderDetailModal" role="dialog" aria-modal="true">
  <div class="admin-modal-card" id="orderModalContent"></div>
</div>

<div class="toast" id="toast">✨ Saved & synced with DECORLY Storefront & Database.</div>







<script src="../assets/js/admin-dashboard.js"></script>
</body>
</html>
