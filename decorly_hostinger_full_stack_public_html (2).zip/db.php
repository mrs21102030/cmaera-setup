<?php
/**
 * ============================================================================
 * DECORLY LUXURY FURNITURE — SECURE PHP + MYSQL ENGINE (db.php)
 * ============================================================================
 */
if (session_status() === PHP_SESSION_NONE) {
    @ini_set('session.cookie_httponly', '1');
    @ini_set('session.use_only_cookies', '1');
    @ini_set('session.cookie_samesite', 'Lax');
    @session_start();
}

if (!headers_sent()) {
    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: SAMEORIGIN');
    header('X-XSS-Protection: 1; mode=block');
    header('Referrer-Policy: strict-origin-when-cross-origin');
}

require_once __DIR__ . '/config.php';

function decorly_execute_sql_file(PDO $pdo, $sqlFilePath) {
    if (!file_exists($sqlFilePath)) {
        return ['ok' => false, 'executed' => 0, 'error' => 'SQL file not found'];
    }
    $raw = file_get_contents($sqlFilePath);
    $lines = preg_split('/\r\n|\r|\n/', $raw);
    $cleanLines = [];
    foreach ($lines as $line) {
        $trimmed = trim($line);
        if ($trimmed === '' || strpos($trimmed, '--') === 0) {
            continue;
        }
        $cleanLines[] = $line;
    }
    $cleanSql = implode("\n", $cleanLines);
    $statements = preg_split('/;\s*(?:\r?\n|$)/', $cleanSql);
    $executed = 0;
    $errors = [];

    foreach ($statements as $stmt) {
        $stmt = trim($stmt);
        if ($stmt === '') continue;
        try {
            $pdo->exec($stmt);
            $executed++;
        } catch (PDOException $e) {
            $errors[] = $e->getMessage();
        }
    }
    return [
        'ok' => count($errors) === 0 || $executed > 10,
        'executed' => $executed,
        'errors' => $errors
    ];
}

function decorly_ensure_schema(PDO $pdo, $forceImport = false) {
    static $checked = false;
    if ($checked && !$forceImport) return true;
    $checked = true;

    try {
        if (!$forceImport) {
            // ONLY check if the `products` table exists. NEVER re-seed if rows were deleted by Admin or phpMyAdmin!
            $stmt = $pdo->query("SHOW TABLES LIKE 'products'");
            if ($stmt && $stmt->rowCount() > 0) {
                return true;
            }
        }
        $sqlPath = __DIR__ . '/database/decorly_complete_database.sql';
        if (!file_exists($sqlPath)) {
            $sqlPath = __DIR__ . '/decorly_complete_database.sql';
        }
        decorly_execute_sql_file($pdo, $sqlPath);
        return true;
    } catch (Exception $e) {
        return false;
    }
}

function decorly_db($autoInit = true, $silent = false) {
    static $pdo = null;
    static $failed = false;
    if ($pdo !== null) return $pdo;
    if ($failed && $silent) return null;

    $pdoOpts = [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ];

    // Candidate credentials to try (configured first, then XAMPP default root/'')
    $candidates = [
        ['host' => DB_HOST, 'port' => DB_PORT, 'user' => DB_USER, 'pass' => DB_PASS, 'db' => DB_NAME],
    ];
    if (DB_USER !== 'root' || DB_PASS !== '') {
        $candidates[] = ['host' => 'localhost', 'port' => '3306', 'user' => 'root', 'pass' => '', 'db' => DB_NAME];
        $candidates[] = ['host' => '127.0.0.1', 'port' => '3306', 'user' => 'root', 'pass' => '', 'db' => DB_NAME];
    } else {
        $candidates[] = ['host' => '127.0.0.1', 'port' => '3306', 'user' => 'root', 'pass' => '', 'db' => DB_NAME];
    }

    foreach ($candidates as $c) {
        try {
            // Connect to MySQL server first to see if user already imported the SQL into a database in phpMyAdmin
            $srvDsn = 'mysql:host=' . $c['host'] . ';port=' . $c['port'] . ';charset=utf8mb4';
            $srvPdo = new PDO($srvDsn, $c['user'], $c['pass'], $pdoOpts);

            // Find all databases that have BOTH `products` and `admins` tables
            $schemasStmt = $srvPdo->query("
                SELECT t1.TABLE_SCHEMA
                FROM information_schema.TABLES t1
                INNER JOIN information_schema.TABLES t2
                  ON t1.TABLE_SCHEMA = t2.TABLE_SCHEMA AND t2.TABLE_NAME = 'admins'
                WHERE t1.TABLE_NAME = 'products'
                  AND t1.TABLE_SCHEMA NOT IN ('information_schema','mysql','performance_schema','sys','phpmyadmin')
            ");
            $foundSchemas = $schemasStmt ? $schemasStmt->fetchAll(PDO::FETCH_COLUMN) : [];

            $targetDb = $c['db'];
            if (count($foundSchemas) === 1) {
                $targetDb = $foundSchemas[0];
            } elseif (count($foundSchemas) > 1) {
                // If user modified one of the databases in phpMyAdmin (e.g. deleted products or added users), pick the active modified one
                $bestSchema = in_array($c['db'], $foundSchemas, true) ? $c['db'] : $foundSchemas[0];
                foreach ($foundSchemas as $sch) {
                    $safeSch = preg_replace('/[^a-zA-Z0-9_]/', '', $sch);
                    $pCount = (int)$srvPdo->query("SELECT COUNT(*) FROM `{$safeSch}`.`products`")->fetchColumn();
                    $uCount = (int)$srvPdo->query("SELECT COUNT(*) FROM `{$safeSch}`.`users`")->fetchColumn();
                    if ($pCount !== 36 || $uCount !== 4) {
                        $bestSchema = $sch;
                        break;
                    }
                }
                $targetDb = $bestSchema;
            } else {
                // No database has the schema yet: create targetDb and initialize once
                $safeDb = preg_replace('/[^a-zA-Z0-9_]/', '', $targetDb);
                $srvPdo->exec("CREATE DATABASE IF NOT EXISTS `{$safeDb}` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
            }

            $dsn = 'mysql:host=' . $c['host'] . ';port=' . $c['port'] . ';dbname=' . $targetDb . ';charset=utf8mb4';
            $pdo = new PDO($dsn, $c['user'], $c['pass'], $pdoOpts);
            if ($autoInit) {
                decorly_ensure_schema($pdo, false);
            }
            return $pdo;
        } catch (PDOException $e) {
            // Fallback direct connection attempt if user lacks information_schema / CREATE DATABASE privilege (e.g. shared hosting)
            try {
                $dsn = 'mysql:host=' . $c['host'] . ';port=' . $c['port'] . ';dbname=' . $c['db'] . ';charset=utf8mb4';
                $pdo = new PDO($dsn, $c['user'], $c['pass'], $pdoOpts);
                if ($autoInit) {
                    decorly_ensure_schema($pdo, false);
                }
                return $pdo;
            } catch (PDOException $inner) {
                continue;
            }
        }
    }

    $failed = true;
    if ($silent) {
        return null;
    }
    http_response_code(503);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
        'ok' => false,
        'db_connected' => false,
        'error' => 'MySQL database is not connected. Make sure MySQL is running in XAMPP or configure Hostinger credentials in config.php / setup-hostinger.php.'
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function decorly_get_bootstrap_payload(PDO $pdo = null) {
    if (!$pdo) {
        $pdo = decorly_db(true, true);
    }
    if (!$pdo) {
        return [
            'ok' => false,
            'db_connected' => false,
            'products' => [],
            'categories' => [],
            'orders' => [],
            'customers' => [],
            'coupons' => [],
            'reviews' => [],
            'enquiries' => [],
            'blog_posts' => [],
            'settings' => [],
            'banner' => null,
            'admin_profile' => null,
            'user' => $_SESSION['decorly_user'] ?? null,
            'admin' => $_SESSION['decorly_admin'] ?? null
        ];
    }
    try {
        $prodsRaw = $pdo->query("SELECT * FROM `products` ORDER BY `id` ASC")->fetchAll();
        $products = array_map(function($r) {
            $galStr = trim($r['gallery_urls'] ?? '');
            $galList = $galStr !== '' ? array_values(array_filter(array_map('trim', explode(',', $galStr)))) : [];
            if (empty($galList) && !empty($r['image_url'])) {
                $galList = [$r['image_url']];
            }
            return [
                'id' => $r['product_code'] ?: ('prod-' . $r['id']),
                'db_id' => (int)$r['id'],
                'name' => $r['name'],
                'slug' => $r['slug'],
                'sku' => $r['sku'],
                'category' => $r['category_name'],
                'catSlug' => $r['category_slug'],
                'badge' => $r['badge'],
                'price' => (float)$r['price'],
                'salePrice' => $r['sale_price'] !== null ? (float)$r['sale_price'] : null,
                'stock' => (int)$r['stock'],
                'image' => $r['image_url'],
                'gallery' => $r['gallery_urls'],
                'galleryList' => $galList,
                'finish' => $r['finish_options'],
                'material' => $r['material'],
                'dimensions' => $r['dimensions'],
                'weight' => $r['weight'],
                'warranty' => $r['warranty'],
                'status' => $r['status'],
                'featured' => (bool)$r['is_featured'],
                'short' => $r['short_description'],
                'description' => $r['description']
            ];
        }, $prodsRaw);

        $catsRaw = $pdo->query("SELECT * FROM `categories` ORDER BY `sort_order` ASC, `id` ASC")->fetchAll();
        $categories = array_map(function($r) {
            return [
                'id' => (int)$r['id'],
                'name' => $r['name'],
                'slug' => $r['slug'],
                'group' => $r['parent_group'],
                'subs' => $r['subcategories'],
                'status' => $r['status'],
                'image' => $r['image_url'],
                'desc' => $r['description']
            ];
        }, $catsRaw);

        $ordersRaw = $pdo->query("SELECT * FROM `orders` ORDER BY `id` DESC")->fetchAll();
        $itemStmt = $pdo->prepare("SELECT * FROM `order_items` WHERE `order_id` = ? OR `order_number` = ?");
        $orders = [];
        foreach ($ordersRaw as $o) {
            $itemStmt->execute([$o['id'], $o['order_number']]);
            $items = [];
            foreach ($itemStmt->fetchAll() as $it) {
                $items[] = [
                    'name' => $it['product_name'],
                    'slug' => $it['product_slug'],
                    'image' => $it['product_image'],
                    'finish' => $it['finish'],
                    'qty' => (int)$it['quantity'],
                    'price' => (float)$it['unit_price']
                ];
            }
            $orders[] = [
                'id' => $o['order_number'],
                'db_id' => (int)$o['id'],
                'customer' => $o['customer_name'],
                'email' => $o['customer_email'],
                'phone' => $o['customer_phone'],
                'address' => $o['shipping_address'],
                'city' => $o['city'],
                'postcode' => $o['postal_code'],
                'notes' => $o['order_notes'],
                'date' => $o['order_date_label'],
                'subtotal' => (float)$o['subtotal'],
                'shipping' => (float)$o['shipping_fee'],
                'discount' => (float)$o['discount_amount'],
                'coupon' => $o['coupon_code'],
                'total' => (float)$o['total_amount'],
                'payment' => $o['payment_method'],
                'status' => $o['status'],
                'items' => $items
            ];
        }

        $custRaw = $pdo->query("SELECT * FROM `users` ORDER BY `id` DESC")->fetchAll();
        $customers = array_map(function($r) {
            return [
                'id' => (int)$r['id'],
                'first' => $r['first_name'],
                'last' => $r['last_name'],
                'name' => $r['full_name'],
                'email' => $r['email'],
                'phone' => $r['phone'],
                'city' => $r['city'],
                'orders' => (int)$r['orders_count'],
                'spent' => (float)$r['total_spent'],
                'type' => $r['customer_type']
            ];
        }, $custRaw);

        $couponsRaw = $pdo->query("SELECT * FROM `coupons` ORDER BY `id` ASC")->fetchAll();
        $coupons = array_map(function($r) {
            return [
                'id' => (int)$r['id'],
                'code' => $r['code'],
                'type' => $r['discount_type'],
                'value' => (float)$r['discount_value'],
                'min' => (float)$r['min_order_amount'],
                'expiry' => $r['expiry_date'],
                'status' => $r['status']
            ];
        }, $couponsRaw);

        $revsRaw = $pdo->query("SELECT * FROM `reviews` ORDER BY `id` DESC")->fetchAll();
        $reviews = array_map(function($r) {
            return [
                'id' => (int)$r['id'],
                'customer' => $r['customer_name'],
                'product' => $r['product_name'],
                'rating' => (int)$r['rating'],
                'comment' => $r['comment'],
                'reply' => $r['admin_reply'] ?? '',
                'status' => $r['status']
            ];
        }, $revsRaw);

        $enqRaw = $pdo->query("SELECT * FROM `enquiries` ORDER BY `id` DESC")->fetchAll();
        $enquiries = array_map(function($e) {
            return [
                'id' => (int)$e['id'],
                'date' => $e['date_label'],
                'name' => $e['name'],
                'email' => $e['email'],
                'phone' => $e['phone'],
                'topic' => $e['topic'],
                'message' => $e['message']
            ];
        }, $enqRaw);

        $blogRaw = $pdo->query("SELECT * FROM `blog_posts` ORDER BY `id` DESC")->fetchAll();
        $posts = array_map(function($r) {
            return [
                'id' => $r['post_key'] ?: ('post-' . $r['id']),
                'db_id' => (int)$r['id'],
                'title' => $r['title'],
                'slug' => $r['slug'],
                'author' => $r['author'],
                'category' => $r['category'],
                'status' => $r['status'],
                'image' => $r['image_url'],
                'excerpt' => $r['excerpt'],
                'content' => $r['content'],
                'updated' => $r['updated_date']
            ];
        }, $blogRaw);

        $settingsRows = $pdo->query("SELECT * FROM `store_settings`")->fetchAll();
        $settings = [];
        foreach ($settingsRows as $s) {
            $settings[$s['setting_key']] = json_decode($s['setting_value'], true) ?: $s['setting_value'];
        }

        $bannerRow = $pdo->query("SELECT * FROM `banners` ORDER BY `id` ASC LIMIT 1")->fetch();
        $banner = $bannerRow ? [
            'eyebrow' => $bannerRow['eyebrow'],
            'title' => $bannerRow['title'],
            'button' => $bannerRow['button_text'],
            'link' => $bannerRow['button_link'],
            'image' => $bannerRow['image_url'],
            'desc' => $bannerRow['description'],
            'placement' => $bannerRow['placement'],
            'status' => $bannerRow['status']
        ] : null;

        $admRow = $pdo->query("SELECT * FROM `admins` ORDER BY `id` ASC LIMIT 1")->fetch();
        $adminProfile = $admRow ? [
            'id' => (int)$admRow['id'],
            'name' => $admRow['name'],
            'role' => $admRow['role'],
            'email' => $admRow['email'],
            'phone' => $admRow['phone'],
            'initials' => $admRow['initials'],
            'city' => $admRow['city'],
            'bio' => $admRow['bio'],
            'pass' => $admRow['password_plain_hint'] ?? 'Decorly@2026',
            'grad' => $admRow['avatar_grad'],
            'fg' => $admRow['avatar_fg'],
            'photo' => $admRow['photo_url'] ?? ''
        ] : null;

        // Refresh active session user from DB if logged in
        $sessionUser = $_SESSION['decorly_user'] ?? null;
        if ($sessionUser && !empty($sessionUser['email'])) {
            $uStmt = $pdo->prepare("SELECT * FROM `users` WHERE LOWER(`email`) = LOWER(?) LIMIT 1");
            $uStmt->execute([$sessionUser['email']]);
            $freshU = $uStmt->fetch();
            if ($freshU) {
                $sessionUser = [
                    'id' => (int)$freshU['id'],
                    'first' => $freshU['first_name'],
                    'last' => $freshU['last_name'],
                    'name' => $freshU['full_name'],
                    'email' => $freshU['email'],
                    'phone' => $freshU['phone'],
                    'city' => $freshU['city'],
                    'photo' => $freshU['photo_url'] ?? ''
                ];
                $_SESSION['decorly_user'] = $sessionUser;
            } else {
                unset($_SESSION['decorly_user']);
                $sessionUser = null;
            }
        }

        return [
            'ok' => true,
            'db_connected' => true,
            'products' => $products,
            'categories' => $categories,
            'orders' => $orders,
            'customers' => $customers,
            'coupons' => $coupons,
            'reviews' => $reviews,
            'enquiries' => $enquiries,
            'blog_posts' => $posts,
            'settings' => $settings,
            'banner' => $banner,
            'admin_profile' => $adminProfile,
            'user' => $sessionUser,
            'admin' => $_SESSION['decorly_admin'] ?? null
        ];
    } catch (Exception $e) {
        return ['ok' => false, 'db_connected' => false, 'error' => $e->getMessage()];
    }
}
