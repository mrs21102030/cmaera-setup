<?php
/**
 * ============================================================================
 * DECORLY LUXURY FURNITURE — PRODUCTION DATABASE CONFIGURATION (config.php)
 * ============================================================================
 * Works automatically on XAMPP (localhost / root /decorly_db) and Hostinger.
 * If you use custom Hostinger credentials, either edit below or use /setup-hostinger.php
 * ============================================================================
 */

if (file_exists(__DIR__ . '/api/db-credentials.php')) {
    require_once __DIR__ . '/api/db-credentials.php';
}

if (!defined('DB_HOST')) define('DB_HOST', getenv('DB_HOST') ?: 'localhost');
if (!defined('DB_PORT')) define('DB_PORT', getenv('DB_PORT') ?: '3306');
if (!defined('DB_NAME')) define('DB_NAME', getenv('DB_NAME') ?: 'decorly_db');
if (!defined('DB_USER')) define('DB_USER', getenv('DB_USER') ?: 'root');
if (!defined('DB_PASS')) define('DB_PASS', getenv('DB_PASS') !== false ? getenv('DB_PASS') : '');
