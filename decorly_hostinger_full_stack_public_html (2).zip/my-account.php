<?php require_once __DIR__ . '/db.php'; ?>
<!DOCTYPE html>

<html lang="en"><head><meta charset="utf-8"/><meta content="width=device-width,initial-scale=1" name="viewport"/><meta content="#102346" name="theme-color"/><title>My Account | DECORLY</title><link href="https://fonts.googleapis.com" rel="preconnect"/><link crossorigin="" href="https://fonts.gstatic.com" rel="preconnect"/><link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700;800&amp;family=Manrope:wght@400;500;600;700;800&amp;display=swap" rel="stylesheet"/>







  <link rel="stylesheet" href="assets/css/global.css">
  <link rel="stylesheet" href="assets/css/my-account.css">
  <script src="api/bootstrap-js.php"></script>
</head><body class="decorly-unified" data-page="account">
<!-- DECORLY Luxury Preloader -->
<div id="decorly-preloader" role="status" aria-live="polite" aria-label="Loading DECORLY">
  <div class="dl-ambient"></div>
  <div class="dl-emblem-wrap">
    <div class="dl-ring-outer"></div>
    <div class="dl-ring-inner"></div>
    <div class="dl-core"><span>D</span></div>
  </div>
  <div class="dl-brand">DECOR<b>LY</b></div>
  <div class="dl-tag">CURATING INSPIRED LIVING</div>
  <div class="dl-track"><div class="dl-bar" id="decorlyLoaderBar"></div></div>
  <div class="dl-pct" id="decorlyLoaderPct">0%</div>
</div>


<header class="nv decorly-site-header" id="hd"><a aria-label="DECORLY Home" class="lg" href="./"><img alt="DECORLY" height="34" src="assets/decorly-logo-light.png" width="169"/></a>
<nav class="lk"><a href="./">Home</a><a href="shop">Shop</a><div class="decorly-cat-nav" id="decorlyCatNav"><a aria-expanded="false" aria-haspopup="true" class="decorly-cat-trigger" href="categories">Categories <span aria-hidden="true">⌄</span></a><div class="decorly-cat-menu"><div class="decorly-cat-group"><a class="decorly-cat-parent" href="categories?group=tables">Tables <span>›</span></a><div class="decorly-cat-sub"><a href="category?slug=nesting-tables">Nesting Tables</a><a href="category?slug=tea-tables">Tea Tables</a><a href="category?slug=console-tables">Console Tables</a><a href="category?slug=dining-tables">Dining Tables</a><a href="category?slug=coffee-tables">Coffee Tables</a><a href="category?slug=laptop-tables">Laptop Tables</a></div></div><div class="decorly-cat-group"><a class="decorly-cat-parent" href="categories?group=racks">Racks <span>›</span></a><div class="decorly-cat-sub"><a href="category?slug=kitchen-oven-racks">Kitchen Oven Racks</a><a href="category?slug=corner-racks">Corner Racks</a></div></div><div class="decorly-cat-group"><a class="decorly-cat-parent" href="categories?group=trolleys">Trolleys <span>›</span></a><div class="decorly-cat-sub"><a href="category?slug=tea-trolleys">Tea Trolleys</a></div></div><a class="decorly-all-cat" href="categories">Explore All Categories ↗</a></div></div><a href="about">About Us</a><a href="blog">Blog</a><a href="contact">Contact</a></nav>
<form action="search" class="sf" id="searchForm" method="get"><input aria-label="Search products" id="search" name="q" placeholder="Search..." type="search"/></form>
<div class="qk"><a aria-label="Wishlist" href="wishlist" title="Wishlist">♡</a><a aria-label="Cart" href="cart" title="Cart">🛒<i id="cartCount">0</i></a></div>
 <?php $__isLogged = !empty($_SESSION['decorly_user']); ?><a aria-label="Sign In or My Account" class="decorly-header-signin-btn<?php echo $__isLogged ? ' is-signed-in' : ''; ?>" id="headerSignInBtn" href="<?php echo $__isLogged ? 'my-account' : 'login'; ?>"><?php echo $__isLogged ? 'My Account' : 'Sign In'; ?></a>
<a class="gb nb" href="shop">Shop Furniture</a><button aria-label="Menu" class="mb" id="mbtn">☰</button></header><nav class="mm decorly-site-mobile" id="mm"><a href="./">Home</a><a href="shop">Shop All Products</a><a href="categories">All Categories</a><details><summary>Tables</summary><a href="category?slug=nesting-tables">Nesting Tables</a><a href="category?slug=tea-tables">Tea Tables</a><a href="category?slug=console-tables">Console Tables</a><a href="category?slug=dining-tables">Dining Tables</a><a href="category?slug=coffee-tables">Coffee Tables</a><a href="category?slug=laptop-tables">Laptop Tables</a></details><details><summary>Racks</summary><a href="category?slug=kitchen-oven-racks">Kitchen Oven Racks</a><a href="category?slug=corner-racks">Corner Racks</a></details><details><summary>Trolleys</summary><a href="category?slug=tea-trolleys">Tea Trolleys</a></details><a href="about">About Us</a><a href="blog">Blog</a><a href="contact">Contact Us</a><a href="wishlist">Wishlist</a><a href="cart">Cart</a><a href="login">Sign In</a><a href="signup">Create Account</a><a href="faq">Help &amp; FAQ</a><form action="search" method="get" class="d-u-my-account-1"><input name="q" placeholder="Search furniture..." type="search" class="d-u-my-account-2"/></form></nav><main>
<section class="flow-hero">
  <div class="container">
    <div class="crumbs"><a href="./">Home</a> &nbsp;/&nbsp; <a href="my-account">My Account</a> &nbsp;/&nbsp; <span id="buyerCrumbActive">Overview</span></div>
    <span class="kicker">DECORLY / CUSTOMER PORTAL</span>
    <h1 id="buyerHeroHeading">My Account</h1>
    <p id="buyerHeroSub">Manage your orders, personal profile, delivery addresses, wishlist, and account security.</p>
  </div>
</section>

<section class="flow-section account-section">
  <div class="container account-layout">
    <aside class="account-sidebar d-u-my-account-3">
      <div class="d-u-my-account-4">
        <div class="member-icon d-u-my-account-5" id="buyerSideAvatar">SM</div>
        <h2 class="sidebar-title d-u-my-account-6" id="buyerSideName">Sara Malik</h2>
        <p id="buyerSideEmail" class="d-u-my-account-7">sara@decorly.com</p>
        <span class="d-u-my-account-8">GOLD MEMBER</span>
        <div class="d-u-my-account-9">
          <label class="d-u-my-account-10">
            📷 Change Photo
            <input type="file" id="buyerPhotoInput" accept="image/*" hidden/>
          </label>
        </div>
      </div>

      <nav aria-label="Account navigation" class="sidebar-nav d-u-my-account-11">
        <a class="active d-u-my-account-12" data-buyer-nav="overview" href="#overview"><span>▦ &nbsp;Overview</span><span aria-hidden="true">↗</span></a>
        <a data-buyer-nav="profile" href="#profile" class="d-u-my-account-12"><span>👤 &nbsp;My Profile</span><span aria-hidden="true">↗</span></a>
        <a data-buyer-nav="orders" href="#orders" class="d-u-my-account-12"><span>▤ &nbsp;My Orders</span><span id="buyerOrdNavBadge" class="d-u-my-account-13">2</span></a>
        <a data-buyer-nav="addresses" href="#addresses" class="d-u-my-account-12"><span>⌖ &nbsp;My Addresses</span><span aria-hidden="true">↗</span></a>
        <a data-buyer-nav="settings" href="#settings" class="d-u-my-account-12"><span>🛡️ &nbsp;Password &amp; Security</span><span aria-hidden="true">↗</span></a>
      </nav>

      <div class="d-u-my-account-14">
        <a href="shop" class="d-u-my-account-15">Shop Catalog →</a>
        <button type="button" id="buyerLogoutBtn" class="d-u-my-account-16">Sign Out</button>
      </div>
    </aside>

    <div class="account-stack">
      <!-- PANEL 1: OVERVIEW -->
      <div class="decorly-buyer-panel is-active" data-account-panel="overview" id="account-overview">
        <section class="account-card">
          <div class="account-intro d-u-my-account-17">
            <div>
              <h2 id="buyerWelcomeTitle">Welcome back, Sara Malik 👋</h2>
              <p class="muted">Track your furniture deliveries, manage saved addresses, and update your personal security credentials.</p>
            </div>
            <a class="account-btn" href="shop">Explore New Arrivals ↗</a>
          </div>

          <div class="d-u-my-account-18">
            <div class="d-u-my-account-19">
              <small class="d-u-my-account-20">Total Orders</small>
              <strong id="kpiBuyerOrders" class="d-u-my-account-21">2</strong>
            </div>
            <div class="d-u-my-account-19">
              <small class="d-u-my-account-20">Wishlist Pieces</small>
              <strong id="kpiBuyerWish" class="d-u-my-account-21">0</strong>
            </div>
            <div class="d-u-my-account-19">
              <small class="d-u-my-account-20">Saved Addresses</small>
              <strong id="kpiBuyerAddr" class="d-u-my-account-21">1</strong>
            </div>
            <div class="d-u-my-account-19">
              <small class="d-u-my-account-20">Items in Cart</small>
              <strong id="kpiBuyerCart" class="d-u-my-account-21">0</strong>
            </div>
          </div>

          <div class="account-grid d-u-my-account-22">
            <article class="account-tile"><div class="tile-icon">👤</div><h3>Personal Profile</h3><p>Edit your name, email, phone number &amp; profile photo.</p><a href="#profile">Edit Profile ↗</a></article>
            <article class="account-tile"><div class="tile-icon">▤</div><h3>Order History &amp; Receipts</h3><p>View placed orders, live delivery status &amp; invoices.</p><a href="#orders">View My Orders ↗</a></article>
            <article class="account-tile"><div class="tile-icon">⌖</div><h3>Delivery Addresses</h3><p>Manage home and office shipping locations.</p><a href="#addresses">Manage Addresses ↗</a></article>
            <article class="account-tile"><div class="tile-icon">🛡️</div><h3>Password &amp; Security</h3><p>Update your account password and display name.</p><a href="#settings">Change Password ↗</a></article>
            <article class="account-tile"><div class="tile-icon">♡</div><h3>Saved Wishlist</h3><p>Review furniture designs saved for your home.</p><a href="wishlist">Open Wishlist ↗</a></article>
            <article class="account-tile"><div class="tile-icon">🛒</div><h3>Shopping Cart</h3><p>Apply promo codes and complete checkout.</p><a href="cart">Open Cart ↗</a></article>
          </div>
        </section>
      </div>

      <!-- PANEL 2: MY PROFILE -->
      <div class="decorly-buyer-panel" data-account-panel="profile" id="account-profile" hidden>
        <section class="account-card">
          <div class="account-intro">
            <h2>Personal Profile Information</h2>
            <p class="muted">Update your contact details below. These automatically pre-fill during Checkout.</p>
          </div>
          <form id="profileForm" class="d-u-my-account-23">
            <div class="account-fieldset">
              <div class="account-field"><label for="first">First name *</label><input autocomplete="given-name" id="first" maxlength="80" placeholder="First name" required/></div>
              <div class="account-field"><label for="last">Last name *</label><input autocomplete="family-name" id="last" maxlength="80" placeholder="Last name" required/></div>
              <div class="account-field"><label for="email">Email address *</label><input autocomplete="email" id="email" maxlength="150" placeholder="you@example.com" type="email" required/></div>
              <div class="account-field"><label for="phone">Mobile phone *</label><input autocomplete="tel" id="phone" maxlength="28" placeholder="+92 300 1234567" type="tel" required/></div>
              <div class="account-field wide"><label for="buyerCity">Primary City / Province</label><input id="buyerCity" maxlength="90" placeholder="e.g. Multan / Lahore, Punjab"/></div>
            </div>
            <div class="account-actions">
              <button class="account-btn" type="submit">💾 Save Profile Details ↗</button>
              <button class="account-btn outline" id="clearProfile" type="button">Reset Form</button>
            </div>
            <div aria-live="polite" class="feedback d-u-my-account-24" id="profileFeedback"></div>
          </form>
        </section>
      </div>

      <!-- PANEL 3: MY ORDERS -->
      <div class="decorly-buyer-panel" data-account-panel="orders" id="account-orders" hidden>
        <section class="account-card">
          <div class="account-intro d-u-my-account-17">
            <div>
              <h2>Your Order History</h2>
              <p class="muted">Orders placed on Checkout automatically appear below and stay synced with Admin fulfillment status.</p>
            </div>
            <a class="account-btn" href="shop">＋ Place New Order ↗</a>
          </div>
          <div id="buyerOrdersList" class="d-u-my-account-25"></div>
        </section>
      </div>

      <!-- PANEL 4: ORDER DETAILS -->
      <div class="decorly-buyer-panel" data-account-panel="order-details" id="account-order-details" hidden>
        <section class="account-card">
          <div id="buyerOrderDetailBox"></div>
        </section>
      </div>

      <!-- PANEL 5: SAVED ADDRESSES -->
      <div class="decorly-buyer-panel" data-account-panel="addresses" id="account-addresses" hidden>
        <section class="account-card">
          <div class="account-intro">
            <h2>Saved Delivery Addresses</h2>
            <p class="muted">Add or edit delivery locations for faster furniture checkout.</p>
          </div>
          <div class="address-grid d-u-my-account-22" id="addressList"></div>
          <form id="addressForm" class="d-u-my-account-26">
            <h2 id="addressFormTitle" class="d-u-my-account-27">Add a Delivery Address</h2>
            <div class="account-fieldset">
              <div class="account-field"><label for="aname">Recipient full name *</label><input autocomplete="name" id="aname" maxlength="90" required/></div>
              <div class="account-field"><label for="aphone">Phone number *</label><input autocomplete="tel" id="aphone" maxlength="26" required/></div>
              <div class="account-field wide"><label for="astreet">Street address / House &amp; Block *</label><input autocomplete="street-address" id="astreet" maxlength="180" required/></div>
              <div class="account-field"><label for="acity">City *</label><input autocomplete="address-level2" id="acity" maxlength="90" required/></div>
              <div class="account-field"><label for="aregion">Province / State *</label><input autocomplete="address-level1" id="aregion" maxlength="90" value="Punjab" required/></div>
              <div class="account-field"><label for="azip">Postal code</label><input autocomplete="postal-code" id="azip" maxlength="20" value="60000"/></div>
              <div class="account-field"><label for="acountry">Country</label><input autocomplete="country-name" id="acountry" maxlength="70" value="Pakistan"/></div>
            </div>
            <div class="account-actions">
              <button class="account-btn" type="submit">💾 Save Delivery Address ↗</button>
              <button class="account-btn outline" id="cancelAddress" type="button">Clear Form</button>
            </div>
            <div aria-live="polite" class="feedback d-u-my-account-24" id="addressFeedback"></div>
          </form>
        </section>
      </div>

      <!-- PANEL 6: PASSWORD & SECURITY SETTINGS -->
      <div class="decorly-buyer-panel" data-account-panel="settings" id="account-settings" hidden>
        <section class="account-card">
          <div class="account-intro">
            <h2>Password &amp; Account Security</h2>
            <p class="muted">Update your customer display name and sign-in password below.</p>
          </div>
          <form id="customerSecurityForm" class="d-u-my-account-22">
            <div class="account-fieldset">
              <div class="account-field"><label for="custDispName">Full Display Name *</label><input id="custDispName" maxlength="80" placeholder="e.g. Sara Malik" required/></div>
              <div class="account-field"><label for="custCurrPass">Current Password</label><input id="custCurrPass" type="password" placeholder="Current password (default: Customer@2026)"/></div>
              <div class="account-field"><label for="custNewPass">New Password (min 6 chars) *</label><input id="custNewPass" type="password" minlength="6" placeholder="Enter new password" required/></div>
              <div class="account-field"><label for="custConfPass">Confirm New Password *</label><input id="custConfPass" type="password" minlength="6" placeholder="Re-enter new password" required/></div>
            </div>
            <div class="account-actions d-u-my-account-28">
              <button class="account-btn" type="submit">🔐 Update Name &amp; Password ↗</button>
              <a class="account-btn outline" href="login">Switch Account ↗</a>
            </div>
            <div aria-live="polite" class="feedback d-u-my-account-29" id="custSecurityFeedback"></div>
          </form>
        </section>
      </div>
    </div>
  </div>
</section>
</main>
<footer aria-label="DECORLY website footer" class="decorly-final-footer decorly-luxe-footer" id="siteFooter">
<div class="lf-top"><div class="lf-grid">
<section aria-label="DECORLY brand" class="lf-brand"><a aria-label="DECORLY homepage" class="lf-logo" href="./"><img alt="DECORLY" loading="lazy" src="assets/decorly-logo-light.png"/></a><p>Furniture for inspired living. Discover contemporary tables, trolleys and thoughtful storage for your space.</p><a class="lf-cta" href="shop">Explore furniture <span aria-hidden="true">→</span></a></section>
<nav aria-label="Explore" class="lf-links"><div aria-hidden="true" class="lf-icon">⌂</div><h3>Explore</h3><a href="./">Home <span>›</span></a><a href="shop">Shop furniture <span>›</span></a><a href="categories">All categories <span>›</span></a><a href="about">About us <span>›</span></a><a href="contact">Contact us <span>›</span></a></nav>
<nav aria-label="Collections" class="lf-links"><div aria-hidden="true" class="lf-icon">▱</div><h3>Collections</h3><a href="category?slug=coffee-tables">Coffee tables <span>›</span></a><a href="category?slug=nesting-tables">Nesting tables <span>›</span></a><a href="category?slug=tea-trolleys">Tea trolleys <span>›</span></a><a href="category?slug=corner-racks">Corner racks <span>›</span></a></nav>
<nav aria-label="Help and contact" class="lf-links"><div aria-hidden="true" class="lf-icon">♧</div><h3>Help &amp; Contact</h3><a href="faq">Help &amp; FAQs <span>›</span></a><a href="shipping-policy">Shipping policy <span>›</span></a><a href="return-refund-policy">Returns &amp; refunds <span>›</span></a><a href="privacy-policy">Privacy policy <span>›</span></a><a href="terms-conditions">Terms &amp; conditions <span>›</span></a></nav>
<section aria-label="Contact details" class="lf-contact"><h3>Get in touch</h3><p class="lf-intro">Have a question? We're here to help.</p><div class="lf-method"><span aria-hidden="true" class="lf-round">✉</span><div><small>Official Support Email</small><a href="mailto:support@decorly.pk">support@decorly.pk</a></div></div><div class="lf-method"><span aria-hidden="true" class="lf-round">☎</span><div><small>Customer Care Helpline</small><a href="tel:+923008429000">+92 300 8429000</a></div></div><div class="lf-method"><span aria-hidden="true" class="lf-round">⌖</span><div><small>Studio / location</small><span>Industrial Estate &amp; Design Studio, Multan / Lahore, Pakistan</span></div></div><div class="lf-social"><p>Follow us</p><div aria-label="DECORLY official social channels"><span aria-label="DECORLY on Instagram">◎</span><span aria-label="DECORLY on Facebook">f</span><span aria-label="DECORLY on Pinterest">p</span><span aria-label="DECORLY on YouTube">▶</span><span aria-label="DECORLY on LinkedIn">in</span></div></div></section>
</div></div><div class="lf-bottom"><div class="lf-bottom-inner"><p>© 2026 DECORLY. All rights reserved.</p><div class="lf-perks"><div><b aria-hidden="true">♧</b><span>Shipping details<small>See shipping policy</small></span></div><div><b aria-hidden="true">♢</b><span>Returns &amp; refunds<small>View our policy</small></span></div><div><b aria-hidden="true">⬡</b><span>Checkout experience<small>Payment options at checkout</small></span></div></div><p class="lf-note">A more inspired home<br/>for a brighter tomorrow.</p></div></div>
</footer>



<script src="assets/js/my-account.js"></script>
<script src="assets/js/decorly-shopping.js"></script>
</body></html>