<?php require_once __DIR__ . '/db.php'; ?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta http-equiv="refresh" content="0;url=my-account#order-details"><title>Opening DECORLY Buyer Dashboard</title>







  <link rel="stylesheet" href="assets/css/global.css">
  <link rel="stylesheet" href="assets/css/order-details.css">
  <script src="api/bootstrap-js.php"></script>
</head><body>
<!-- DECORLY Luxury Preloader -->
<div id="decorly-preloader" role="status" aria-live="polite" aria-label="Loading DECORLY">
  <div class="dl-ambient"></div>
  <div class="dl-emblem-wrap">
    <div class="dl-ring-outer"></div>
    <div class="dl-ring-inner"></div>
    <div class="dl-core"><span>D</span></div>
  </div>
  <div class="dl-brand">DECOR<b>LY</b></div>
  <div class="dl-tag">CURATING INSPIRED LIVING</div>
  <div class="dl-track"><div class="dl-bar" id="decorlyLoaderBar"></div></div>
  <div class="dl-pct" id="decorlyLoaderPct">0%</div>
</div>


<p>Buyer dashboard is now one page. <a href="my-account#order-details">Open My Account</a>.</p>
<script src="assets/js/order-details.js"></script>
<script src="assets/js/decorly-shopping.js"></script>
</body></html>