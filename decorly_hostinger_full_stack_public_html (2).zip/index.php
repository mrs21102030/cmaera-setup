<?php require_once __DIR__ . '/db.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8"/>
<meta content="width=device-width,initial-scale=1" name="viewport"/>
<title>DECORLY | Premium Furniture for Inspired Living</title>
<meta content="Shop DECORLY tables, tea trolleys, racks and contemporary furniture." name="description"/>
<link href="https://fonts.googleapis.com" rel="preconnect"/>
<link crossorigin="" href="https://fonts.gstatic.com" rel="preconnect"/>
<link href="https://images.unsplash.com" rel="preconnect"/>
<link href="https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700;800&family=Playfair+Display:ital,wght@1,500&display=swap" rel="stylesheet"/>











  <link rel="stylesheet" href="assets/css/global.css">
  <link rel="stylesheet" href="assets/css/index.css">
  <script src="api/bootstrap-js.php"></script>
</head>
<body>
<!-- DECORLY Luxury Preloader -->
<div id="decorly-preloader" role="status" aria-live="polite" aria-label="Loading DECORLY">
  <div class="dl-ambient"></div>
  <div class="dl-emblem-wrap">
    <div class="dl-ring-outer"></div>
    <div class="dl-ring-inner"></div>
    <div class="dl-core"><span>D</span></div>
  </div>
  <div class="dl-brand">DECOR<b>LY</b></div>
  <div class="dl-tag">CURATING INSPIRED LIVING</div>
  <div class="dl-track"><div class="dl-bar" id="decorlyLoaderBar"></div></div>
  <div class="dl-pct" id="decorlyLoaderPct">0%</div>
</div>


<div class="pg" id="pg"></div>
<header class="nv" id="hd">
 <a aria-label="DECORLY Home" class="lg" href="./"><img alt="DECORLY" height="34" src="assets/decorly-logo-light.png" width="169"/></a>
 <nav class="lk">
  <a href="./">Home</a>
  <a href="shop">Shop</a>
  <div class="decorly-cat-nav" id="decorlyCatNav">
   <a aria-expanded="false" aria-haspopup="true" class="decorly-cat-trigger" href="categories">Categories <span aria-hidden="true">⌄</span></a>
   <div class="decorly-cat-menu">
    <div class="decorly-cat-group">
     <a class="decorly-cat-parent" href="categories?group=tables">Tables <span>›</span></a>
     <div class="decorly-cat-sub">
      <a href="category?slug=nesting-tables">Nesting Tables</a>
      <a href="category?slug=tea-tables">Tea Tables</a>
      <a href="category?slug=console-tables">Console Tables</a>
      <a href="category?slug=dining-tables">Dining Tables</a>
      <a href="category?slug=coffee-tables">Coffee Tables</a>
      <a href="category?slug=laptop-tables">Laptop Tables</a>
     </div>
    </div>
    <div class="decorly-cat-group">
     <a class="decorly-cat-parent" href="categories?group=racks">Racks <span>›</span></a>
     <div class="decorly-cat-sub">
      <a href="category?slug=kitchen-oven-racks">Kitchen Oven Racks</a>
      <a href="category?slug=corner-racks">Corner Racks</a>
     </div>
    </div>
    <div class="decorly-cat-group">
     <a class="decorly-cat-parent" href="categories?group=trolleys">Trolleys <span>›</span></a>
     <div class="decorly-cat-sub">
      <a href="category?slug=tea-trolleys">Tea Trolleys</a>
     </div>
    </div>
    <a class="decorly-all-cat" href="categories">Explore All Categories ↗</a>
   </div>
  </div>
  <a href="about">About Us</a>
  <a href="blog">Blog</a>
  <a href="contact">Contact</a>
 </nav>
 <form action="search" class="sf" id="searchForm" method="get">
  <input aria-label="Search products" id="search" name="q" placeholder="Search..." type="search"/>
 </form>
 <div class="qk">
  <a aria-label="Wishlist" href="wishlist" title="Wishlist">♡</a>
  <a aria-label="Cart" href="cart" title="Cart">🛒<i id="cartCount">0</i></a>
  </div>
 <?php $__isLogged = !empty($_SESSION['decorly_user']); ?><a aria-label="Sign In or My Account" class="decorly-header-signin-btn<?php echo $__isLogged ? ' is-signed-in' : ''; ?>" id="headerSignInBtn" href="<?php echo $__isLogged ? 'my-account' : 'login'; ?>"><?php echo $__isLogged ? 'My Account' : 'Sign In'; ?></a>
 <a class="gb nb" href="shop">Shop Furniture</a>
 <button aria-label="Menu" class="mb" id="mbtn">☰</button>
</header>
<nav class="mm" id="mm">
 <a href="./">Home</a>
 <a href="shop">Shop All Products</a>
 <a href="categories">All Categories</a>
 <details><summary>Tables</summary>
  <a href="category?slug=nesting-tables">Nesting Tables</a>
  <a href="category?slug=tea-tables">Tea Tables</a>
  <a href="category?slug=console-tables">Console Tables</a>
  <a href="category?slug=dining-tables">Dining Tables</a>
  <a href="category?slug=coffee-tables">Coffee Tables</a>
  <a href="category?slug=laptop-tables">Laptop Tables</a>
 </details>
 <details><summary>Racks</summary>
  <a href="category?slug=kitchen-oven-racks">Kitchen Oven Racks</a>
  <a href="category?slug=corner-racks">Corner Racks</a>
 </details>
 <details><summary>Trolleys</summary>
  <a href="category?slug=tea-trolleys">Tea Trolleys</a>
 </details>
 <a href="about">About Us</a>
 <a href="blog">Blog</a>
 <a href="contact">Contact Us</a>
 <a href="wishlist">Wishlist</a>
 <a href="cart">Cart</a>
 <a href="login">Sign In</a>
 <a href="signup">Create Account</a>
 <a href="faq">Help &amp; FAQ</a>
 <form action="search" method="get" class="d-u-index-1">
  <input name="q" placeholder="Search furniture..." type="search" class="d-u-index-2"/>
 </form>
</nav>

<main id="home">
 <section class="hero-story" id="hero">
  <div class="story-stage">
   <div class="scene-layer">
    <img alt="Luxury interior" class="scene-back first" decoding="async" fetchpriority="high" height="1067" sizes="100vw" src="https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?auto=format&fit=crop&w=1400&q=70" srcset="https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?auto=format&fit=crop&w=720&q=68 720w,https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?auto=format&fit=crop&w=1400&q=70 1400w" width="1600"/>
    <img alt="Modern interior" class="scene-back second" decoding="async" height="1067" sizes="100vw" src="https://images.unsplash.com/photo-1600607687920-4e2a09cf159d?auto=format&fit=crop&w=1400&q=70" srcset="https://images.unsplash.com/photo-1600607687920-4e2a09cf159d?auto=format&fit=crop&w=720&q=68 720w,https://images.unsplash.com/photo-1600607687920-4e2a09cf159d?auto=format&fit=crop&w=1400&q=70 1400w" width="1600"/>
    <img alt="Room details" class="scene-back third" decoding="async" height="1067" sizes="100vw" src="https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3?auto=format&fit=crop&w=1400&q=70" srcset="https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3?auto=format&fit=crop&w=720&q=68 720w,https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3?auto=format&fit=crop&w=1400&q=70 1400w" width="1600"/>
    <div class="story-shade"></div>
   </div>
   <div class="story-lines"></div>
   <img alt="DECORLY tea trolley" class="float-frame float-one" decoding="async" src="https://dodgerblue-louse-798026.hostingersite.com/wp-content/uploads/2026/10/Luxury-Gold-2-Tier-Tea-Trolley-with-Black-Glass-Trays.png"/>
   <img alt="Statement console table" class="float-frame float-two" decoding="async" src="https://images.unsplash.com/photo-1618220179428-22790b461013?auto=format&fit=crop&w=500&q=70"/>
   <img alt="Furniture detail" class="float-frame float-three" decoding="async" src="https://images.unsplash.com/photo-1534349762230-0a162eebd8cb?auto=format&fit=crop&w=420&q=70"/>
   <div class="hero-inner">
    <div class="hero-copy">
     <span class="eyebrow">THE ART OF EVERYDAY LIVING</span>
     <h1>MAKE ROOM<br/>FOR <em>BETTER LIVING.</em></h1>
     <p>Curated tables, elegant trolleys and considered details. Furniture that gives every corner its own story.</p>
     <a class="button" href="#categories">DISCOVER COLLECTIONS <span>↗</span></a>
    </div>
   </div>
   <div class="scene-copy story-one">
    <span class="eyebrow">SCENE 01 / THE ART OF LIVING</span>
    <h2>Furniture that<br/>moves you.</h2>
    <p>From the living room to the dining room, every corner can feel a little more extraordinary.</p>
   </div>
   <div class="scene-copy story-two">
    <span class="eyebrow">SCENE 02 / MADE TO BE NOTICED</span>
    <h2>Make space<br/>for <em>style.</em></h2>
    <p>Explore details, finishes and forms that give your home its own unmistakable character.</p>
   </div>
   <div class="hero-collection-chip">
    <span>THE SIGNATURE EDIT</span>
    <strong>Objects of desire. Made for living.</strong>
    <a href="#categories">Explore the edit ↗</a>
   </div>
   <div class="story-caption">DECORLY — COLLECTION 2026</div>
   <div class="scene-counter">SCROLL TO EXPLORE ↓</div>
  </div>
 </section>

 <section class="pad" id="intro">
  <div class="w ig">
   <div class="rv">
    <span class="eb">WELCOME TO DECORLY</span>
    <p class="d-u-index-3">A considered collection for the living, dining and functional spaces that make a house a home.</p>
   </div>
   <div class="rv d-u-index-4">
    <h2 class="h2 d-u-index-5">Objects for<br/>living <em>better.</em></h2>
    <div class="chips"><span>TABLES</span><span>TROLLEYS</span><span>RACKS &amp; STORAGE</span></div>
   </div>
  </div>
 </section>

 <section class="pad" id="categories">
  <div class="w">
   <div class="top rv">
    <div>
     <span class="eb">01 / FIND YOUR STYLE</span>
     <h2 class="h2">Explore our<br/><em>main categories.</em></h2>
     <p class="sub">Choose from Tables, Racks and Trolleys. Open a category to explore its dedicated collections.</p>
    </div>
    <a class="tl" href="categories">EXPLORE ALL CATEGORIES ↗</a>
   </div>
   <div class="cg" id="cg"></div>
  </div>
 </section>

 <section class="pad prod" id="shop">
  <div class="w">
   <div class="top rv">
    <div>
     <span class="eb">02 / THE FURNITURE EDIT</span>
     <h2 class="h2">Find your next<br/><em>favorite.</em></h2>
     <p class="sub">Browse a curated showcase across DECORLY's collections. Click a design to continue shopping.</p>
    </div>
    <a class="tl" href="shop">FULL SHOP ↗</a>
   </div>
   <div class="tabs" id="tabs"></div>
   <div class="pgd" id="pgd"></div>
   <p id="rm" class="d-u-index-6">Showcase photography may differ from the linked items. Confirm live pricing on the product page.</p>
  </div>
 </section>

 <div id="eds"></div>

 <section class="mf">
  <div class="w"><span class="eb">THOUGHTFUL FURNITURE / BOLD SPACES</span></div>
  <div class="mw d-u-index-7" id="mw">LIVE <em>BOLD.</em> LIVE BETTER. LIVE <em>BOLD.</em></div>
  <div class="w mb2">
   <p>Good design belongs in everyday life. Discover modern finishes, statement silhouettes and practical pieces to bring your personal vision home.</p>
   <a class="btn bg1" href="#shop">DISCOVER YOUR PIECE <s>↗</s></a>
  </div>
 </section>

 <section class="pad">
  <div class="w">
   <div class="top rv">
    <div>
     <span class="eb">WHY EXPLORE DECORLY</span>
     <h2 class="h2">Designed around<br/><em>you.</em></h2>
    </div>
   </div>
   <div class="bgd">
    <div class="bn rv"><b>◇</b><h3>Distinctive designs</h3><p>From marble looks to warm wood and metal finishes for your modern space.</p></div>
    <div class="bn rv d-u-index-8"><b>▦</b><h3>Thoughtful storage</h3><p>Browse racks, organizers and versatile pieces for everyday needs.</p></div>
    <div class="bn rv d-u-index-9"><b>✳</b><h3>Every room covered</h3><p>Living, dining, study and kitchen categories all in one place.</p></div>
    <div class="bn rv d-u-index-10"><b>↗</b><h3>Easy exploration</h3><p>Simple product navigation with direct links into our store.</p></div>
   </div>
  </div>
 </section>

 <section class="pad d-u-index-11" id="about">
  <div class="w sg">
   <div class="si rv">
    <img alt="Modern living area" data-i="1600210492486-724fe5c67fb0" data-w="1400" loading="lazy" decoding="async"/>
    <img alt="Modern dining interior" data-i="1600607687939-ce8a6c25118c" data-w="1000" loading="lazy" decoding="async"/>
   </div>
   <div class="rv d-u-index-4">
    <span class="eb">03 / THE DECORLY POINT OF VIEW</span>
    <h2 class="h2">A home worth<br/><em>coming back to.</em></h2>
    <p class="sub">DECORLY brings together furniture collections inspired by comfortable living and contemporary design. Explore the details you love, then visit the matching category in our shop.</p>
    <div class="sl">
     <div><span>01 &nbsp; Timeless silhouettes</span><b>↗</b></div>
     <div><span>02 &nbsp; Expressive finishes</span><b>↗</b></div>
     <div><span>03 &nbsp; Everyday functionality</span><b>↗</b></div>
    </div>
    <a class="btn bg2 d-u-index-12" href="about">ABOUT DECORLY <s>↗</s></a>
   </div>
  </div>
 </section>

 <section class="pad prod">
  <div class="w fq">
   <div class="rv">
    <span class="eb">QUESTIONS, ANSWERED</span>
    <h2 class="h2">A little more<br/><em>clarity.</em></h2>
    <p class="sub">Shopping should feel simple, from the first scroll to choosing your piece.</p>
   </div>
   <div class="rv d-u-index-4">
    <div class="fi"><button aria-expanded="false" class="fq-q">Can I shop every DECORLY category here?<b>+</b></button><div class="fa"><p>Yes, all listed furniture categories are included on this page. Category and product links take you to the current DECORLY store.</p></div></div>
    <div class="fi"><button aria-expanded="false" class="fq-q">Are product prices live?<b>+</b></button><div class="fa"><p>Product prices and availability should be confirmed on the live product or category page.</p></div></div>
    <div class="fi"><button aria-expanded="false" class="fq-q">Where do I complete my purchase?<b>+</b></button><div class="fa"><p>Use the collection links to browse products on DECORLY's main website and complete your purchase there.</p></div></div>
    <div class="fi"><button aria-expanded="false" class="fq-q">Can I explore furniture for a specific room?<b>+</b></button><div class="fa"><p>Yes. Browse coffee and nesting tables for living areas, dining tables for dining spaces, and racks for practical storage.</p></div></div>
   </div>
  </div>
 </section>

 <section class="cta">
  <div class="rv">
   <span class="eb d-u-index-13">YOUR SPACE. YOUR STORY.</span>
   <h2>MAKE ROOM FOR<br/><em>SOMETHING NEW.</em></h2>
   <a class="btn bg1" href="shop">EXPLORE THE FULL STORE <s>↗</s></a>
  </div>
 </section>
</main>

<footer aria-label="DECORLY website footer" class="decorly-luxe-footer" id="siteFooter">
 <div class="lf-top">
  <div class="lf-grid">
   <section aria-label="DECORLY brand" class="lf-brand">
    <a aria-label="DECORLY homepage" class="lf-logo" href="./"><img alt="DECORLY" loading="lazy" src="assets/decorly-logo-light.png"/></a>
    <p>Furniture for inspired living. Discover contemporary tables, trolleys and thoughtful storage for your space.</p>
    <a class="lf-cta" href="shop">Explore furniture <span aria-hidden="true">→</span></a>
   </section>
   <nav aria-label="Explore" class="lf-links">
    <div aria-hidden="true" class="lf-icon">⌂</div>
    <h3>Explore</h3>
    <a href="./">Home <span>›</span></a>
    <a href="shop">Shop furniture <span>›</span></a>
    <a href="categories">All categories <span>›</span></a>
    <a href="about">About us <span>›</span></a>
    <a href="contact">Contact us <span>›</span></a>
   </nav>
   <nav aria-label="Collections" class="lf-links">
    <div aria-hidden="true" class="lf-icon">▱</div>
    <h3>Collections</h3>
    <a href="category?slug=coffee-tables">Coffee tables <span>›</span></a>
    <a href="category?slug=nesting-tables">Nesting tables <span>›</span></a>
    <a href="category?slug=tea-trolleys">Tea trolleys <span>›</span></a>
    <a href="category?slug=corner-racks">Corner racks <span>›</span></a>
   </nav>
   <nav aria-label="Help and contact" class="lf-links">
    <div aria-hidden="true" class="lf-icon">♧</div>
    <h3>Help &amp; Contact</h3>
    <a href="faq">Help &amp; FAQs <span>›</span></a>
    <a href="shipping-policy">Shipping policy <span>›</span></a>
    <a href="return-refund-policy">Returns &amp; refunds <span>›</span></a>
    <a href="privacy-policy">Privacy policy <span>›</span></a>
    <a href="terms-conditions">Terms &amp; conditions <span>›</span></a>
   </nav>
   <section aria-label="Contact details" class="lf-contact">
    <h3>Get in touch</h3>
    <p class="lf-intro">Have a question? We're here to help.</p>
    <div class="lf-method"><span aria-hidden="true" class="lf-round">✉</span><div><small>Official Support Email</small><a href="mailto:support@decorly.pk">support@decorly.pk</a></div></div>
    <div class="lf-method"><span aria-hidden="true" class="lf-round">☎</span><div><small>Customer Care Helpline</small><a href="tel:+923008429000">+92 300 8429000</a></div></div>
    <div class="lf-method"><span aria-hidden="true" class="lf-round">⌖</span><div><small>Studio / location</small><span>Industrial Estate &amp; Design Studio, Multan / Lahore, Pakistan</span></div></div>
    <div class="lf-social">
     <p>Follow us</p>
     <div aria-label="DECORLY official social channels">
      <span aria-label="DECORLY on Instagram">◎</span>
      <span aria-label="DECORLY on Facebook">f</span>
      <span aria-label="DECORLY on Pinterest">p</span>
      <span aria-label="DECORLY on YouTube">▶</span>
      <span aria-label="DECORLY on LinkedIn">in</span>
     </div>
    </div>
   </section>
  </div>
 </div>
 <div class="lf-bottom">
  <div class="lf-bottom-inner">
   <p>© 2026 DECORLY. All rights reserved.</p>
   <div class="lf-perks">
    <div><b aria-hidden="true">♧</b><span>Shipping details<small>See shipping policy</small></span></div>
    <div><b aria-hidden="true">♢</b><span>Returns &amp; refunds<small>View our policy</small></span></div>
    <div><b aria-hidden="true">⬡</b><span>Checkout experience<small>Payment options at checkout</small></span></div>
   </div>
   <p class="lf-note">A more inspired home<br/>for a brighter tomorrow.</p>
  </div>
 </div>
</footer>
<button aria-label="Back to top" class="bt" id="bt">↑</button>


<script src="https://cdn.jsdelivr.net/npm/gsap@3.12.5/dist/gsap.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/gsap@3.12.5/dist/ScrollTrigger.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/lenis@1.1.13/dist/lenis.min.js"></script>



<script src="assets/js/index.js"></script>
<script src="assets/js/decorly-shopping.js"></script>
</body>
</html>