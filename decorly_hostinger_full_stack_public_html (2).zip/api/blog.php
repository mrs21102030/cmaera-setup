<?php
require_once __DIR__ . '/config.php';
$pdo = decorly_db();
$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
$in = decorly_input();

function map_blog($r) {
    return [
        'id' => $r['post_key'] ?: ('post-' . $r['id']),
        'db_id' => (int)$r['id'],
        'title' => $r['title'],
        'slug' => $r['slug'],
        'author' => $r['author'],
        'category' => $r['category'],
        'status' => $r['status'],
        'image' => $r['image_url'],
        'excerpt' => $r['excerpt'],
        'content' => $r['content'],
        'updated' => $r['updated_date']
    ];
}

if ($method === 'GET') {
    $rows = $pdo->query("SELECT * FROM `blog_posts` ORDER BY `id` DESC")->fetchAll();
    decorly_json(['ok' => true, 'posts' => array_map('map_blog', $rows)]);
}

if ($method === 'POST' || $method === 'PUT') {
    $action = $in['action'] ?? 'save';
    if ($action === 'delete') {
        $slug = trim($in['slug'] ?? '');
        $key = trim($in['id'] ?? '');
        $pdo->prepare("DELETE FROM `blog_posts` WHERE `slug` = ? OR `post_key` = ?")->execute([$slug, $key]);
        $rows = $pdo->query("SELECT * FROM `blog_posts` ORDER BY `id` DESC")->fetchAll();
        decorly_json(['ok' => true, 'posts' => array_map('map_blog', $rows)]);
    }
    $title = trim($in['title'] ?? 'DECORLY Journal');
    $slug = trim($in['slug'] ?? strtolower(preg_replace('/[^a-z0-9]+/i', '-', $title)));
    $key = trim($in['id'] ?? ('post-' . time()));
    $author = trim($in['author'] ?? 'DECORLY Team');
    $cat = trim($in['category'] ?? 'Home Styling');
    $status = trim($in['status'] ?? 'Published');
    $image = trim($in['image'] ?? '');
    $excerpt = trim($in['excerpt'] ?? '');
    $content = trim($in['content'] ?? '');
    $updated = trim($in['updated'] ?? date('Y-m-d'));

    $stmt = $pdo->prepare("INSERT INTO `blog_posts` (`post_key`, `title`, `slug`, `author`, `category`, `status`, `image_url`, `excerpt`, `content`, `updated_date`)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE `title`=VALUES(`title`), `author`=VALUES(`author`), `category`=VALUES(`category`), `status`=VALUES(`status`), `image_url`=VALUES(`image_url`), `excerpt`=VALUES(`excerpt`), `content`=VALUES(`content`), `updated_date`=VALUES(`updated_date`)");
    $stmt->execute([$key, $title, $slug, $author, $cat, $status, $image, $excerpt, $content, $updated]);

    $rows = $pdo->query("SELECT * FROM `blog_posts` ORDER BY `id` DESC")->fetchAll();
    decorly_json(['ok' => true, 'posts' => array_map('map_blog', $rows)]);
}
