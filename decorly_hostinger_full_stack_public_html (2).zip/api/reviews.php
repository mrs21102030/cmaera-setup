<?php
require_once __DIR__ . '/config.php';
$pdo = decorly_db();
$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
$in = decorly_input();

function map_rev($r) {
    return [
        'id' => (int)$r['id'],
        'customer' => $r['customer_name'],
        'product' => $r['product_name'],
        'rating' => (int)$r['rating'],
        'comment' => $r['comment'],
        'reply' => $r['admin_reply'] ?? '',
        'status' => $r['status']
    ];
}
function map_enq($e) {
    return [
        'id' => (int)$e['id'],
        'date' => $e['date_label'],
        'name' => $e['name'],
        'email' => $e['email'],
        'phone' => $e['phone'],
        'topic' => $e['topic'],
        'message' => $e['message']
    ];
}

if ($method === 'GET') {
    $revs = $pdo->query("SELECT * FROM `reviews` ORDER BY `id` DESC")->fetchAll();
    $enqs = $pdo->query("SELECT * FROM `enquiries` ORDER BY `id` DESC")->fetchAll();
    decorly_json([
        'ok' => true,
        'reviews' => array_map('map_rev', $revs),
        'enquiries' => array_map('map_enq', $enqs)
    ]);
}

if ($method === 'POST' || $method === 'PUT') {
    $action = $in['action'] ?? 'save_review';
    if ($action === 'enquiry') {
        $stmt = $pdo->prepare("INSERT INTO `enquiries` (`date_label`, `name`, `email`, `phone`, `topic`, `message`) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->execute([
            trim($in['date'] ?? date('d M Y')),
            trim($in['name'] ?? ''),
            trim($in['email'] ?? ''),
            trim($in['phone'] ?? ''),
            trim($in['topic'] ?? 'General Enquiry'),
            trim($in['message'] ?? '')
        ]);
        $enqs = $pdo->query("SELECT * FROM `enquiries` ORDER BY `id` DESC")->fetchAll();
        decorly_json(['ok' => true, 'enquiries' => array_map('map_enq', $enqs)]);
    }
    if ($action === 'delete_enquiry') {
        $id = (int)($in['id'] ?? 0);
        $pdo->prepare("DELETE FROM `enquiries` WHERE `id` = ?")->execute([$id]);
        $enqs = $pdo->query("SELECT * FROM `enquiries` ORDER BY `id` DESC")->fetchAll();
        decorly_json(['ok' => true, 'enquiries' => array_map('map_enq', $enqs)]);
    }
    if ($action === 'delete_review') {
        $id = (int)($in['id'] ?? 0);
        $pdo->prepare("DELETE FROM `reviews` WHERE `id` = ?")->execute([$id]);
        $revs = $pdo->query("SELECT * FROM `reviews` ORDER BY `id` DESC")->fetchAll();
        decorly_json(['ok' => true, 'reviews' => array_map('map_rev', $revs)]);
    }

    $id = (int)($in['id'] ?? 0);
    $customer = trim($in['customer'] ?? 'Verified Buyer');
    $product = trim($in['product'] ?? 'DECORLY Furniture');
    $rating = max(1, min(5, (int)($in['rating'] ?? 5)));
    $comment = trim($in['comment'] ?? '');
    $reply = trim($in['reply'] ?? '');
    $status = trim($in['status'] ?? 'Approved');

    if ($id > 0) {
        $stmt = $pdo->prepare("UPDATE `reviews` SET `customer_name`=?, `product_name`=?, `rating`=?, `comment`=?, `admin_reply`=?, `status`=? WHERE `id`=?");
        $stmt->execute([$customer, $product, $rating, $comment, $reply, $status, $id]);
    } else {
        $stmt = $pdo->prepare("INSERT INTO `reviews` (`customer_name`, `product_name`, `rating`, `comment`, `admin_reply`, `status`) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->execute([$customer, $product, $rating, $comment, $reply, $status]);
    }
    $revs = $pdo->query("SELECT * FROM `reviews` ORDER BY `id` DESC")->fetchAll();
    decorly_json(['ok' => true, 'reviews' => array_map('map_rev', $revs)]);
}
