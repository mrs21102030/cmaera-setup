<?php
require_once __DIR__ . '/config.php';
$pdo = decorly_db();
$in = decorly_input();
$action = $in['action'] ?? 'bootstrap';

if ($action === 'bootstrap') {
    decorly_json(decorly_get_bootstrap_payload($pdo));
}

decorly_json(['ok' => true, 'service' => 'DECORLY Production PHP+MySQL API v2.0']);
