<?php
require_once __DIR__ . '/config.php';
$pdo = decorly_db();
$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
$in = decorly_input();

function map_product_row($r) {
    $galStr = trim($r['gallery_urls'] ?? '');
    $galList = $galStr !== '' ? array_values(array_filter(array_map('trim', explode(',', $galStr)))) : [];
    if (empty($galList) && !empty($r['image_url'])) {
        $galList = [$r['image_url']];
    }
    return [
        'id' => $r['product_code'] ?: ('prod-' . $r['id']),
        'db_id' => (int)$r['id'],
        'name' => $r['name'],
        'slug' => $r['slug'],
        'sku' => $r['sku'],
        'category' => $r['category_name'],
        'catSlug' => $r['category_slug'],
        'badge' => $r['badge'],
        'price' => (float)$r['price'],
        'salePrice' => $r['sale_price'] !== null ? (float)$r['sale_price'] : null,
        'stock' => (int)$r['stock'],
        'image' => $r['image_url'],
        'gallery' => $r['gallery_urls'],
        'galleryList' => $galList,
        'finish' => $r['finish_options'],
        'material' => $r['material'],
        'dimensions' => $r['dimensions'],
        'weight' => $r['weight'],
        'warranty' => $r['warranty'],
        'status' => $r['status'],
        'featured' => (bool)$r['is_featured'],
        'short' => $r['short_description'],
        'description' => $r['description']
    ];
}

if ($method === 'GET') {
    $cat = trim($in['category'] ?? '');
    $slug = trim($in['slug'] ?? '');
    if ($slug !== '') {
        $stmt = $pdo->prepare("SELECT * FROM `products` WHERE `slug` = ? OR `product_code` = ? LIMIT 1");
        $stmt->execute([$slug, $slug]);
        $row = $stmt->fetch();
        decorly_json(['ok' => true, 'product' => $row ? map_product_row($row) : null]);
    }
    if ($cat !== '') {
        $stmt = $pdo->prepare("SELECT * FROM `products` WHERE `category_slug` = ? ORDER BY `id` ASC");
        $stmt->execute([$cat]);
    } else {
        $stmt = $pdo->query("SELECT * FROM `products` ORDER BY `id` ASC");
    }
    $rows = $stmt->fetchAll();
    decorly_json(['ok' => true, 'products' => array_map('map_product_row', $rows)]);
}

if ($method === 'POST' || $method === 'PUT' || $method === 'DELETE') {
    $action = $in['action'] ?? ($method === 'DELETE' ? 'delete' : 'save');

    if ($action === 'delete') {
        $slug = trim($in['slug'] ?? '');
        $code = trim($in['id'] ?? '');
        $dbId = (int)($in['db_id'] ?? 0);
        if ($dbId > 0) {
            $stmt = $pdo->prepare("DELETE FROM `products` WHERE `id` = ? OR `slug` = ? OR `product_code` = ?");
            $stmt->execute([$dbId, $slug, $code]);
        } else {
            $stmt = $pdo->prepare("DELETE FROM `products` WHERE `slug` = ? OR `product_code` = ?");
            $stmt->execute([$slug, $code]);
        }
        $rows = $pdo->query("SELECT * FROM `products` ORDER BY `id` ASC")->fetchAll();
        decorly_json(['ok' => true, 'products' => array_map('map_product_row', $rows)]);
    }

    if ($action === 'inventory') {
        $slug = trim($in['slug'] ?? '');
        $code = trim($in['id'] ?? '');
        $stock = max(0, (int)($in['stock'] ?? 0));
        $sku = trim($in['sku'] ?? '');
        $stmt = $pdo->prepare("UPDATE `products` SET `stock` = ?, `sku` = IF(? != '', ?, `sku`) WHERE `slug` = ? OR `product_code` = ?");
        $stmt->execute([$stock, $sku, $sku, $slug, $code]);
        $rows = $pdo->query("SELECT * FROM `products` ORDER BY `id` ASC")->fetchAll();
        decorly_json(['ok' => true, 'products' => array_map('map_product_row', $rows)]);
    }

    // Single product save (create or update)
    $name = trim($in['name'] ?? 'DECORLY Furniture');
    $slug = trim($in['slug'] ?? strtolower(preg_replace('/[^a-z0-9]+/i', '-', $name)));
    $code = trim($in['id'] ?? ('prod-' . time()));
    $sku = trim($in['sku'] ?? 'DEC-101');
    $category = trim($in['category'] ?? 'Coffee Tables');
    $catSlug = trim($in['catSlug'] ?? strtolower(preg_replace('/[^a-z0-9]+/i', '-', $category)));
    $badge = trim($in['badge'] ?? 'DECORLY EDIT');
    $price = (float)($in['price'] ?? 0);
    $salePrice = (isset($in['salePrice']) && $in['salePrice'] !== '' && $in['salePrice'] !== null) ? (float)$in['salePrice'] : null;
    $stock = max(0, (int)($in['stock'] ?? 10));
    $image = trim($in['image'] ?? '');
    $gallery = is_array($in['gallery'] ?? null) ? implode(', ', $in['gallery']) : trim($in['gallery'] ?? '');
    if ($gallery === '' && $image !== '') $gallery = $image;
    $finish = trim($in['finish'] ?? 'As shown');
    $material = trim($in['material'] ?? 'Powder-Coated Steel & Tempered Glass');
    $dimensions = trim($in['dimensions'] ?? 'Standard');
    $weight = trim($in['weight'] ?? '12 kg');
    $warranty = trim($in['warranty'] ?? '1 Year Structural Warranty');
    $status = trim($in['status'] ?? 'Published');
    $featured = ($badge === 'SIGNATURE EDIT' || $badge === 'BEST SELLER' || !empty($in['featured'])) ? 1 : 0;
    $short = trim($in['short'] ?? '');
    $desc = trim($in['description'] ?? '');

    $stmt = $pdo->prepare("INSERT INTO `products` (`product_code`, `name`, `slug`, `sku`, `category_name`, `category_slug`, `badge`, `price`, `sale_price`, `stock`, `image_url`, `gallery_urls`, `finish_options`, `material`, `dimensions`, `weight`, `warranty`, `status`, `is_featured`, `short_description`, `description`)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE `name`=VALUES(`name`), `sku`=VALUES(`sku`), `category_name`=VALUES(`category_name`), `category_slug`=VALUES(`category_slug`), `badge`=VALUES(`badge`), `price`=VALUES(`price`), `sale_price`=VALUES(`sale_price`), `stock`=VALUES(`stock`), `image_url`=VALUES(`image_url`), `gallery_urls`=VALUES(`gallery_urls`), `finish_options`=VALUES(`finish_options`), `material`=VALUES(`material`), `dimensions`=VALUES(`dimensions`), `weight`=VALUES(`weight`), `warranty`=VALUES(`warranty`), `status`=VALUES(`status`), `is_featured`=VALUES(`is_featured`), `short_description`=VALUES(`short_description`), `description`=VALUES(`description`)");
    $stmt->execute([$code, $name, $slug, $sku, $category, $catSlug, $badge, $price, $salePrice, $stock, $image, $gallery, $finish, $material, $dimensions, $weight, $warranty, $status, $featured, $short, $desc]);

    $rows = $pdo->query("SELECT * FROM `products` ORDER BY `id` ASC")->fetchAll();
    decorly_json(['ok' => true, 'products' => array_map('map_product_row', $rows)]);
}
