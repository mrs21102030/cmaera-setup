<?php
require_once __DIR__ . '/config.php';
$pdo = decorly_db();
$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
$in = decorly_input();

function map_cat_row($r) {
    return [
        'id' => (int)$r['id'],
        'name' => $r['name'],
        'slug' => $r['slug'],
        'group' => $r['parent_group'],
        'subs' => $r['subcategories'],
        'status' => $r['status'],
        'image' => $r['image_url'],
        'desc' => $r['description']
    ];
}

if ($method === 'GET') {
    $rows = $pdo->query("SELECT * FROM `categories` ORDER BY `sort_order` ASC, `id` ASC")->fetchAll();
    decorly_json(['ok' => true, 'categories' => array_map('map_cat_row', $rows)]);
}

if ($method === 'POST' || $method === 'PUT') {
    $action = $in['action'] ?? 'save';
    if ($action === 'delete') {
        $slug = trim($in['slug'] ?? '');
        $stmt = $pdo->prepare("DELETE FROM `categories` WHERE `slug` = ?");
        $stmt->execute([$slug]);
        $rows = $pdo->query("SELECT * FROM `categories` ORDER BY `sort_order` ASC, `id` ASC")->fetchAll();
        decorly_json(['ok' => true, 'categories' => array_map('map_cat_row', $rows)]);
    }
    $name = trim($in['name'] ?? '');
    $slug = trim($in['slug'] ?? strtolower(preg_replace('/[^a-z0-9]+/i', '-', $name)));
    $group = trim($in['group'] ?? 'Tables');
    $subs = trim($in['subs'] ?? '');
    $status = trim($in['status'] ?? 'Active');
    $image = trim($in['image'] ?? '');
    $desc = trim($in['desc'] ?? '');

    $stmt = $pdo->prepare("INSERT INTO `categories` (`name`, `slug`, `parent_group`, `subcategories`, `status`, `image_url`, `description`)
        VALUES (?, ?, ?, ?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE `name`=VALUES(`name`), `parent_group`=VALUES(`parent_group`), `subcategories`=VALUES(`subcategories`), `status`=VALUES(`status`), `image_url`=VALUES(`image_url`), `description`=VALUES(`description`)");
    $stmt->execute([$name, $slug, $group, $subs, $status, $image, $desc]);

    $rows = $pdo->query("SELECT * FROM `categories` ORDER BY `sort_order` ASC, `id` ASC")->fetchAll();
    decorly_json(['ok' => true, 'categories' => array_map('map_cat_row', $rows)]);
}
