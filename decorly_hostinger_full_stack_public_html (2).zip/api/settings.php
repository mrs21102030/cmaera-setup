<?php
require_once __DIR__ . '/config.php';
$pdo = decorly_db();
$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
$in = decorly_input();

if ($method === 'GET') {
    $rows = $pdo->query("SELECT * FROM `store_settings`")->fetchAll();
    $out = [];
    foreach ($rows as $r) {
        $out[$r['setting_key']] = json_decode($r['setting_value'], true) ?: $r['setting_value'];
    }
    $banner = $pdo->query("SELECT * FROM `banners` ORDER BY `id` ASC LIMIT 1")->fetch();
    if ($banner) {
        $out['banner'] = [
            'eyebrow' => $banner['eyebrow'],
            'title' => $banner['title'],
            'button' => $banner['button_text'],
            'link' => $banner['button_link'],
            'image' => $banner['image_url'],
            'desc' => $banner['description'],
            'placement' => $banner['placement'],
            'status' => $banner['status']
        ];
    }
    decorly_json(['ok' => true, 'settings' => $out]);
}

if ($method === 'POST' || $method === 'PUT') {
    $key = trim($in['key'] ?? 'general');
    $val = $in['value'] ?? $in;
    if ($key === 'banner') {
        $stmt = $pdo->prepare("INSERT INTO `banners` (`id`, `eyebrow`, `title`, `button_text`, `button_link`, `image_url`, `description`, `placement`, `status`)
            VALUES (1, ?, ?, ?, ?, ?, ?, ?, ?)
            ON DUPLICATE KEY UPDATE `eyebrow`=VALUES(`eyebrow`), `title`=VALUES(`title`), `button_text`=VALUES(`button_text`), `button_link`=VALUES(`button_link`), `image_url`=VALUES(`image_url`), `description`=VALUES(`description`), `placement`=VALUES(`placement`), `status`=VALUES(`status`)");
        $stmt->execute([
            $val['eyebrow'] ?? 'THE DECORLY SIGNATURE EDIT',
            $val['title'] ?? 'Furniture made for living beautifully',
            $val['button'] ?? 'Explore collection',
            $val['link'] ?? 'shop.html',
            $val['image'] ?? '',
            $val['desc'] ?? '',
            $val['placement'] ?? 'Homepage Hero',
            $val['status'] ?? 'Published'
        ]);
        decorly_json(['ok' => true]);
    }

    $jsonVal = is_string($val) ? $val : json_encode($val, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    $stmt = $pdo->prepare("INSERT INTO `store_settings` (`setting_key`, `setting_value`) VALUES (?, ?) ON DUPLICATE KEY UPDATE `setting_value` = VALUES(`setting_value`)");
    $stmt->execute([$key, $jsonVal]);
    decorly_json(['ok' => true]);
}
