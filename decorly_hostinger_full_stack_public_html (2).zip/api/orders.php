<?php
require_once __DIR__ . '/config.php';
$pdo = decorly_db();
$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
$in = decorly_input();

function fetch_all_orders(PDO $pdo, $emailFilter = '') {
    if ($emailFilter !== '') {
        $stmt = $pdo->prepare("SELECT * FROM `orders` WHERE LOWER(`customer_email`) = ? ORDER BY `id` DESC");
        $stmt->execute([strtolower($emailFilter)]);
    } else {
        $stmt = $pdo->query("SELECT * FROM `orders` ORDER BY `id` DESC");
    }
    $orders = $stmt->fetchAll();
    $itemStmt = $pdo->prepare("SELECT * FROM `order_items` WHERE `order_id` = ? OR `order_number` = ?");
    $out = [];
    foreach ($orders as $o) {
        $itemStmt->execute([$o['id'], $o['order_number']]);
        $items = [];
        foreach ($itemStmt->fetchAll() as $it) {
            $items[] = [
                'name' => $it['product_name'],
                'slug' => $it['product_slug'],
                'image' => $it['product_image'],
                'finish' => $it['finish'],
                'qty' => (int)$it['quantity'],
                'price' => (float)$it['unit_price']
            ];
        }
        $out[] = [
            'id' => $o['order_number'],
            'db_id' => (int)$o['id'],
            'customer' => $o['customer_name'],
            'email' => $o['customer_email'],
            'phone' => $o['customer_phone'],
            'address' => $o['shipping_address'],
            'city' => $o['city'],
            'postcode' => $o['postal_code'],
            'notes' => $o['order_notes'],
            'date' => $o['order_date_label'],
            'subtotal' => (float)$o['subtotal'],
            'shipping' => (float)$o['shipping_fee'],
            'discount' => (float)$o['discount_amount'],
            'coupon' => $o['coupon_code'],
            'total' => (float)$o['total_amount'],
            'payment' => $o['payment_method'],
            'status' => $o['status'],
            'items' => $items
        ];
    }
    return $out;
}

if ($method === 'GET') {
    $email = trim($in['email'] ?? '');
    decorly_json(['ok' => true, 'orders' => fetch_all_orders($pdo, $email)]);
}

if ($method === 'POST' || $method === 'PUT') {
    $action = $in['action'] ?? 'create';
    if ($action === 'delete') {
        $ordNum = trim($in['id'] ?? $in['order_number'] ?? '');
        $pdo->prepare("DELETE FROM `order_items` WHERE `order_number` = ?")->execute([$ordNum]);
        $pdo->prepare("DELETE FROM `orders` WHERE `order_number` = ?")->execute([$ordNum]);
        decorly_json(['ok' => true, 'orders' => fetch_all_orders($pdo)]);
    }
    if ($action === 'update_status') {
        $ordNum = trim($in['id'] ?? $in['order_number'] ?? '');
        $status = trim($in['status'] ?? 'Processing');
        $stmt = $pdo->prepare("UPDATE `orders` SET `status` = ? WHERE `order_number` = ?");
        $stmt->execute([$status, $ordNum]);
        decorly_json(['ok' => true, 'orders' => fetch_all_orders($pdo)]);
    }

    // Create new order (from customer checkout or admin manual order)
    $countRow = $pdo->query("SELECT COUNT(*) AS cnt FROM `orders`")->fetch();
    $nextNum = '#DC-' . (1049 + (int)($countRow['cnt'] ?? 0));
    $ordNum = trim($in['id'] ?? $nextNum);
    $customer = trim($in['customer'] ?? 'DECORLY Customer');
    $email = strtolower(trim($in['email'] ?? 'customer@decorly.pk'));
    $phone = trim($in['phone'] ?? '');
    $address = trim($in['address'] ?? 'Standard Doorstep Delivery');
    $city = trim($in['city'] ?? 'Pakistan');
    $postcode = trim($in['postcode'] ?? '');
    $notes = trim($in['notes'] ?? '');
    $dateLabel = trim($in['date'] ?? date('d M Y'));
    $subtotal = (float)($in['subtotal'] ?? $in['total'] ?? 0);
    $shipping = (float)($in['shipping'] ?? 0);
    $discount = (float)($in['discount'] ?? 0);
    $coupon = trim($in['coupon'] ?? '');
    $total = (float)($in['total'] ?? $subtotal);
    $payment = trim($in['payment'] ?? 'Cash on Delivery (COD)');
    $status = trim($in['status'] ?? 'Processing');
    $items = is_array($in['items'] ?? null) ? $in['items'] : [];

    $pdo->beginTransaction();
    try {
        $stmt = $pdo->prepare("INSERT INTO `orders` (`order_number`, `customer_name`, `customer_email`, `customer_phone`, `shipping_address`, `city`, `postal_code`, `order_notes`, `order_date_label`, `subtotal`, `shipping_fee`, `discount_amount`, `coupon_code`, `total_amount`, `payment_method`, `status`)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON DUPLICATE KEY UPDATE `status`=VALUES(`status`), `total_amount`=VALUES(`total_amount`)");
        $stmt->execute([$ordNum, $customer, $email, $phone, $address, $city, $postcode, $notes, $dateLabel, $subtotal, $shipping, $discount, $coupon, $total, $payment, $status]);
        $orderId = (int)$pdo->lastInsertId();
        if (!$orderId) {
            $q = $pdo->prepare("SELECT `id` FROM `orders` WHERE `order_number` = ? LIMIT 1");
            $q->execute([$ordNum]);
            $orderId = (int)($q->fetch()['id'] ?? 0);
        }

        $pdo->prepare("DELETE FROM `order_items` WHERE `order_id` = ?")->execute([$orderId]);
        $itStmt = $pdo->prepare("INSERT INTO `order_items` (`order_id`, `order_number`, `product_slug`, `product_name`, `product_image`, `finish`, `quantity`, `unit_price`, `line_total`) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stockStmt = $pdo->prepare("UPDATE `products` SET `stock` = GREATEST(0, `stock` - ?) WHERE `slug` = ?");

        foreach ($items as $it) {
            $qty = max(1, (int)($it['qty'] ?? 1));
            $uPrice = (float)($it['price'] ?? $total);
            $pSlug = trim($it['slug'] ?? '');
            $itStmt->execute([
                $orderId,
                $ordNum,
                $pSlug,
                trim($it['name'] ?? 'DECORLY Furniture'),
                trim($it['image'] ?? ''),
                trim($it['finish'] ?? 'Signature Finish'),
                $qty,
                $uPrice,
                $qty * $uPrice
            ]);
            if ($pSlug !== '') {
                $stockStmt->execute([$qty, $pSlug]);
            }
        }

        // Update customer's total_spent and orders_count if registered
        $uUpd = $pdo->prepare("UPDATE `users` SET `orders_count` = `orders_count` + 1, `total_spent` = `total_spent` + ? WHERE LOWER(`email`) = ?");
        $uUpd->execute([$total, $email]);

        $pdo->commit();
    } catch (Exception $e) {
        $pdo->rollBack();
        decorly_json(['ok' => false, 'error' => $e->getMessage()], 500);
    }

    $allOrders = fetch_all_orders($pdo);
    decorly_json(['ok' => true, 'order_number' => $ordNum, 'orders' => $allOrders]);
}
