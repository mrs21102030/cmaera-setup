<?php
require_once dirname(__DIR__) . '/db.php';
header('Content-Type: application/javascript; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');

$payload = decorly_get_bootstrap_payload();
$json = json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
?>
(function(){
  var d = <?php echo $json ?: '{"ok":false}'; ?>;
  window.DECORLY_SERVER_BOOT = d;
  try {
    localStorage.removeItem('decorlyAdminProducts');
    localStorage.removeItem('decorlyAdminCategories');
    localStorage.removeItem('decorly_orders');
    localStorage.removeItem('decorlyAdminCustomers');
    localStorage.removeItem('decorly_users');
    localStorage.removeItem('decorly_profile_preview');
    localStorage.removeItem('decorly_addresses_preview');
    localStorage.removeItem('decorlyAdminCoupons');
    localStorage.removeItem('decorlyAdminReviews');
    localStorage.removeItem('decorly_enquiries');
    localStorage.removeItem('decorlyAdminBlogPosts_v1');
    if (d && d.user) {
      localStorage.setItem('decorly_current_user', JSON.stringify(d.user));
    } else {
      localStorage.removeItem('decorly_current_user');
    }
  } catch (e) {}
})();
