<?php
require_once __DIR__ . '/config.php';
$pdo = decorly_db();
$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
$in = decorly_input();

function map_coupon($r) {
    return [
        'id' => (int)$r['id'],
        'code' => $r['code'],
        'type' => $r['discount_type'],
        'value' => (float)$r['discount_value'],
        'min' => (float)$r['min_order_amount'],
        'expiry' => $r['expiry_date'],
        'status' => $r['status']
    ];
}

if ($method === 'GET') {
    $rows = $pdo->query("SELECT * FROM `coupons` ORDER BY `id` ASC")->fetchAll();
    decorly_json(['ok' => true, 'coupons' => array_map('map_coupon', $rows)]);
}

if ($method === 'POST' || $method === 'PUT') {
    $action = $in['action'] ?? 'save';
    if ($action === 'delete') {
        $code = strtoupper(trim($in['code'] ?? ''));
        $pdo->prepare("DELETE FROM `coupons` WHERE UPPER(`code`) = ?")->execute([$code]);
        $rows = $pdo->query("SELECT * FROM `coupons` ORDER BY `id` ASC")->fetchAll();
        decorly_json(['ok' => true, 'coupons' => array_map('map_coupon', $rows)]);
    }
    $code = strtoupper(trim($in['code'] ?? ''));
    $type = trim($in['type'] ?? 'percent');
    $val = (float)($in['value'] ?? 10);
    $min = (float)($in['min'] ?? 0);
    $exp = trim($in['expiry'] ?? '2026-12-31');
    $status = trim($in['status'] ?? 'Active');

    $stmt = $pdo->prepare("INSERT INTO `coupons` (`code`, `discount_type`, `discount_value`, `min_order_amount`, `expiry_date`, `status`)
        VALUES (?, ?, ?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE `discount_type`=VALUES(`discount_type`), `discount_value`=VALUES(`discount_value`), `min_order_amount`=VALUES(`min_order_amount`), `expiry_date`=VALUES(`expiry_date`), `status`=VALUES(`status`)");
    $stmt->execute([$code, $type, $val, $min, $exp, $status]);

    $rows = $pdo->query("SELECT * FROM `coupons` ORDER BY `id` ASC")->fetchAll();
    decorly_json(['ok' => true, 'coupons' => array_map('map_coupon', $rows)]);
}
