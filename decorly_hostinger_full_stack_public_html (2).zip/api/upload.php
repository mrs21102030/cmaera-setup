<?php
require_once __DIR__ . '/config.php';
$uploadDir = dirname(__DIR__) . '/uploads/';
if (!is_dir($uploadDir)) {
    @mkdir($uploadDir, 0755, true);
}

if (!empty($_FILES['file']) && $_FILES['file']['error'] === UPLOAD_ERR_OK) {
    $ext = strtolower(pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, ['jpg', 'jpeg', 'png', 'webp', 'gif', 'svg'])) {
        decorly_json(['ok' => false, 'error' => 'Unsupported image format.'], 400);
    }
    $filename = 'decorly-' . time() . '-' . bin2hex(random_bytes(4)) . '.' . $ext;
    $target = $uploadDir . $filename;
    if (move_uploaded_file($_FILES['file']['tmp_name'], $target)) {
        decorly_json(['ok' => true, 'url' => 'uploads/' . $filename]);
    }
}

$in = decorly_input();
if (!empty($in['dataUrl']) && preg_match('/^data:image\/(\w+);base64,/', $in['dataUrl'], $m)) {
    $ext = strtolower($m[1] === 'jpeg' ? 'jpg' : $m[1]);
    $raw = base64_decode(substr($in['dataUrl'], strpos($in['dataUrl'], ',') + 1));
    $filename = 'decorly-' . time() . '-' . bin2hex(random_bytes(4)) . '.' . $ext;
    if (file_put_contents($uploadDir . $filename, $raw) !== false) {
        decorly_json(['ok' => true, 'url' => 'uploads/' . $filename]);
    }
}

decorly_json(['ok' => false, 'error' => 'No valid image uploaded.'], 400);
