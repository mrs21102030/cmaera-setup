<?php
require_once __DIR__ . '/config.php';
$pdo = decorly_db();
$in = decorly_input();
$action = $in['action'] ?? ($_SERVER['REQUEST_METHOD'] === 'GET' ? 'me' : 'login');

if ($action === 'me') {
    decorly_json([
        'ok' => true,
        'user' => $_SESSION['decorly_user'] ?? null,
        'admin' => $_SESSION['decorly_admin'] ?? null
    ]);
}

if ($action === 'logout') {
    unset($_SESSION['decorly_user']);
    decorly_json(['ok' => true, 'message' => 'Signed out successfully.']);
}

if ($action === 'admin_logout') {
    unset($_SESSION['decorly_admin']);
    decorly_json(['ok' => true, 'message' => 'Admin signed out.']);
}

if ($action === 'register') {
    $first = trim($in['first'] ?? '');
    $last = trim($in['last'] ?? '');
    $fullName = trim($first . ' ' . $last);
    if ($fullName === '') $fullName = trim($in['name'] ?? 'DECORLY Buyer');
    if ($first === '') {
        $parts = explode(' ', $fullName, 2);
        $first = $parts[0] ?? 'DECORLY';
        $last = $parts[1] ?? '';
    }
    $email = strtolower(trim($in['email'] ?? ''));
    $phone = trim($in['phone'] ?? '');
    $city = trim($in['city'] ?? 'Pakistan');
    $pass = (string)($in['password'] ?? $in['pass'] ?? '');

    if (!$email || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        decorly_json(['ok' => false, 'error' => 'Please enter a valid email address.'], 200);
    }
    if (strlen($pass) < 6) {
        decorly_json(['ok' => false, 'error' => 'Password must be at least 6 characters long.'], 200);
    }

    $hash = password_hash($pass, PASSWORD_DEFAULT);
    $stmt = $pdo->prepare("INSERT INTO `users` (`first_name`, `last_name`, `full_name`, `email`, `phone`, `city`, `password_hash`, `password_plain`, `customer_type`)
                           VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'New')
                           ON DUPLICATE KEY UPDATE `first_name`=VALUES(`first_name`), `last_name`=VALUES(`last_name`), `full_name`=VALUES(`full_name`), `phone`=VALUES(`phone`), `city`=VALUES(`city`), `password_hash`=VALUES(`password_hash`), `password_plain`=VALUES(`password_plain`)");
    $stmt->execute([$first, $last, $fullName, $email, $phone, $city, $hash, $pass]);

    $idStmt = $pdo->prepare("SELECT * FROM `users` WHERE LOWER(`email`) = LOWER(?) LIMIT 1");
    $idStmt->execute([$email]);
    $u = $idStmt->fetch();

    $userPayload = [
        'id' => (int)$u['id'],
        'first' => $u['first_name'],
        'last' => $u['last_name'],
        'name' => $u['full_name'],
        'email' => $u['email'],
        'phone' => $u['phone'],
        'city' => $u['city'],
        'photo' => $u['photo_url'] ?? ''
    ];
    @session_regenerate_id(true);
    $_SESSION['decorly_user'] = $userPayload;
    decorly_json(['ok' => true, 'user' => $userPayload]);
}

if ($action === 'login') {
    $email = strtolower(trim($in['email'] ?? ''));
    $pass = (string)($in['password'] ?? $in['pass'] ?? '');
    if (!$email || $pass === '') {
        decorly_json(['ok' => false, 'error' => 'Email and password are required.'], 200);
    }

    $stmt = $pdo->prepare("SELECT * FROM `users` WHERE LOWER(TRIM(`email`)) = ? LIMIT 1");
    $stmt->execute([$email]);
    $u = $stmt->fetch();

    if (!$u) {
        decorly_json(['ok' => false, 'error' => 'No account found with this email in the database. Please create an account first.'], 200);
    }

    $hashMatch = !empty($u['password_hash']) && password_verify($pass, $u['password_hash']);
    $plainMatch = isset($u['password_plain']) && $u['password_plain'] !== '' && $u['password_plain'] === $pass;

    if (!$hashMatch && !$plainMatch) {
        decorly_json(['ok' => false, 'error' => 'Incorrect password for ' . $email . '. Please try again.'], 200);
    }

    $userPayload = [
        'id' => (int)$u['id'],
        'first' => $u['first_name'],
        'last' => $u['last_name'],
        'name' => $u['full_name'],
        'email' => $u['email'],
        'phone' => $u['phone'],
        'city' => $u['city'],
        'photo' => $u['photo_url'] ?? ''
    ];
    @session_regenerate_id(true);
    $_SESSION['decorly_user'] = $userPayload;
    decorly_json(['ok' => true, 'user' => $userPayload]);
}

if ($action === 'reset_password') {
    $email = strtolower(trim($in['email'] ?? ''));
    $newPass = (string)($in['new_password'] ?? $in['password'] ?? '');
    if (!$email || strlen($newPass) < 6) {
        decorly_json(['ok' => false, 'error' => 'Valid email and a new password (min 6 chars) are required.'], 200);
    }
    $stmt = $pdo->prepare("SELECT * FROM `users` WHERE LOWER(TRIM(`email`)) = ? LIMIT 1");
    $stmt->execute([$email]);
    $u = $stmt->fetch();
    if (!$u) {
        decorly_json(['ok' => false, 'error' => 'No registered buyer account found with that email.'], 200);
    }
    $hash = password_hash($newPass, PASSWORD_DEFAULT);
    $upd = $pdo->prepare("UPDATE `users` SET `password_hash`=?, `password_plain`=? WHERE `id`=?");
    $upd->execute([$hash, $newPass, $u['id']]);
    decorly_json(['ok' => true, 'name' => $u['full_name'], 'email' => $u['email']]);
}

if ($action === 'update_profile') {
    $sessionEmail = strtolower(trim($_SESSION['decorly_user']['email'] ?? ''));
    $email = strtolower(trim($in['email'] ?? $sessionEmail));
    $first = trim($in['first'] ?? '');
    $last = trim($in['last'] ?? '');
    $fullName = trim($first . ' ' . $last);
    $phone = trim($in['phone'] ?? '');
    $city = trim($in['city'] ?? 'Pakistan');
    $photo = $in['photo'] ?? '';

    if (!$email) {
        decorly_json(['ok' => false, 'error' => 'Email is required.'], 200);
    }

    $targetEmail = $sessionEmail ?: $email;
    $stmt = $pdo->prepare("UPDATE `users` SET `first_name`=?, `last_name`=?, `full_name`=?, `email`=?, `phone`=?, `city`=?, `photo_url`=? WHERE LOWER(`email`)=?");
    $stmt->execute([$first, $last, $fullName, $email, $phone, $city, $photo, $targetEmail]);

    if (!empty($in['new_password']) && strlen($in['new_password']) >= 6) {
        $hash = password_hash($in['new_password'], PASSWORD_DEFAULT);
        $pwStmt = $pdo->prepare("UPDATE `users` SET `password_hash`=?, `password_plain`=? WHERE LOWER(`email`)=?");
        $pwStmt->execute([$hash, $in['new_password'], $email]);
    }

    $idStmt = $pdo->prepare("SELECT * FROM `users` WHERE LOWER(`email`) = ? LIMIT 1");
    $idStmt->execute([$email]);
    $u = $idStmt->fetch();

    $userPayload = [
        'id' => (int)($u['id'] ?? 0),
        'first' => $first,
        'last' => $last,
        'name' => $fullName,
        'email' => $email,
        'phone' => $phone,
        'city' => $city,
        'photo' => $photo
    ];
    $_SESSION['decorly_user'] = $userPayload;
    decorly_json(['ok' => true, 'user' => $userPayload]);
}

if ($action === 'addresses') {
    $email = strtolower(trim($in['email'] ?? ($_SESSION['decorly_user']['email'] ?? '')));
    if (!$email) {
        decorly_json(['ok' => true, 'addresses' => []]);
    }
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $subAction = $in['sub_action'] ?? 'save';
        if ($subAction === 'delete' && !empty($in['id'])) {
            $del = $pdo->prepare("DELETE FROM `user_addresses` WHERE `id` = ? AND LOWER(`user_email`) = ?");
            $del->execute([(int)$in['id'], $email]);
        } elseif (!empty($in['street_address'])) {
            $addrId = (int)($in['id'] ?? 0);
            if ($addrId > 0) {
                $upd = $pdo->prepare("UPDATE `user_addresses` SET `label`=?, `recipient_name`=?, `phone`=?, `street_address`=?, `city`=?, `postal_code`=? WHERE `id`=? AND LOWER(`user_email`)=?");
                $upd->execute([
                    trim($in['label'] ?? 'Home'),
                    trim($in['recipient_name'] ?? ''),
                    trim($in['phone'] ?? ''),
                    trim($in['street_address'] ?? ''),
                    trim($in['city'] ?? ''),
                    trim($in['postal_code'] ?? ''),
                    $addrId,
                    $email
                ]);
            } else {
                $stmt = $pdo->prepare("INSERT INTO `user_addresses` (`user_email`, `label`, `recipient_name`, `phone`, `street_address`, `city`, `postal_code`) VALUES (?, ?, ?, ?, ?, ?, ?)");
                $stmt->execute([
                    $email,
                    trim($in['label'] ?? 'Home'),
                    trim($in['recipient_name'] ?? ''),
                    trim($in['phone'] ?? ''),
                    trim($in['street_address'] ?? ''),
                    trim($in['city'] ?? ''),
                    trim($in['postal_code'] ?? '')
                ]);
            }
        }
    }
    $q = $pdo->prepare("SELECT * FROM `user_addresses` WHERE LOWER(`user_email`) = ? ORDER BY `id` DESC");
    $q->execute([$email]);
    decorly_json(['ok' => true, 'addresses' => $q->fetchAll()]);
}

if ($action === 'admin_login') {
    $email = strtolower(trim($in['email'] ?? ''));
    $pass = (string)($in['password'] ?? $in['pass'] ?? '');
    $stmt = $pdo->prepare("SELECT * FROM `admins` WHERE LOWER(`email`) = ? LIMIT 1");
    $stmt->execute([$email]);
    $adm = $stmt->fetch();
    if (!$adm) {
        $adm = $pdo->query("SELECT * FROM `admins` ORDER BY `id` ASC LIMIT 1")->fetch();
    }

    if (!$adm || (strtolower($adm['email']) !== $email) || (!password_verify($pass, $adm['password_hash']) && $adm['password_plain_hint'] !== $pass)) {
        decorly_json(['ok' => false, 'error' => 'Invalid administrator email or password.'], 200);
    }

    $admPayload = [
        'id' => (int)$adm['id'],
        'name' => $adm['name'],
        'role' => $adm['role'],
        'email' => $adm['email'],
        'phone' => $adm['phone'],
        'initials' => $adm['initials'],
        'city' => $adm['city'],
        'bio' => $adm['bio'],
        'pass' => $adm['password_plain_hint'],
        'grad' => $adm['avatar_grad'],
        'fg' => $adm['avatar_fg'],
        'photo' => $adm['photo_url'] ?? ''
    ];
    @session_regenerate_id(true);
    $_SESSION['decorly_admin'] = $admPayload;
    decorly_json(['ok' => true, 'admin' => $admPayload]);
}

if ($action === 'admin_update_profile') {
    $name = trim($in['name'] ?? 'Store Administrator');
    $role = trim($in['role'] ?? 'Chief Store Administrator');
    $email = strtolower(trim($in['email'] ?? 'admin@decorly.com'));
    $phone = trim($in['phone'] ?? '');
    $initials = strtoupper(substr(trim($in['initials'] ?? 'DA'), 0, 2));
    $city = trim($in['city'] ?? '');
    $bio = trim($in['bio'] ?? '');
    $grad = $in['grad'] ?? 'linear-gradient(135deg,#d5b77a,#b58b4c)';
    $fg = $in['fg'] ?? '#081428';
    $photo = $in['photo'] ?? '';

    $stmt = $pdo->prepare("UPDATE `admins` SET `name`=?, `role`=?, `email`=?, `phone`=?, `initials`=?, `city`=?, `bio`=?, `avatar_grad`=?, `avatar_fg`=?, `photo_url`=? WHERE `id`=1");
    $stmt->execute([$name, $role, $email, $phone, $initials, $city, $bio, $grad, $fg, $photo]);

    if (!empty($in['pass']) && strlen($in['pass']) >= 6) {
        $hash = password_hash($in['pass'], PASSWORD_DEFAULT);
        $pw = $pdo->prepare("UPDATE `admins` SET `password_hash`=?, `password_plain_hint`=? WHERE `id`=1");
        $pw->execute([$hash, $in['pass']]);
    }

    $stmt2 = $pdo->query("SELECT * FROM `admins` WHERE `id`=1 LIMIT 1");
    $adm = $stmt2->fetch();
    $admPayload = [
        'id' => (int)$adm['id'],
        'name' => $adm['name'],
        'role' => $adm['role'],
        'email' => $adm['email'],
        'phone' => $adm['phone'],
        'initials' => $adm['initials'],
        'city' => $adm['city'],
        'bio' => $adm['bio'],
        'pass' => $adm['password_plain_hint'],
        'grad' => $adm['avatar_grad'],
        'fg' => $adm['avatar_fg'],
        'photo' => $adm['photo_url'] ?? ''
    ];
    $_SESSION['decorly_admin'] = $admPayload;
    decorly_json(['ok' => true, 'admin' => $admPayload]);
}

decorly_json(['ok' => false, 'error' => 'Unsupported auth action.'], 400);
