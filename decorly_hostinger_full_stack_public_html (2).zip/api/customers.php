<?php
require_once __DIR__ . '/config.php';
$pdo = decorly_db();
$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
$in = decorly_input();

function map_cust($r) {
    return [
        'id' => (int)$r['id'],
        'name' => $r['full_name'],
        'email' => $r['email'],
        'phone' => $r['phone'],
        'city' => $r['city'],
        'orders' => (int)$r['orders_count'],
        'spent' => (float)$r['total_spent'],
        'type' => $r['customer_type']
    ];
}

if ($method === 'GET') {
    $rows = $pdo->query("SELECT * FROM `users` ORDER BY `id` DESC")->fetchAll();
    decorly_json(['ok' => true, 'customers' => array_map('map_cust', $rows)]);
}

if ($method === 'POST' || $method === 'PUT') {
    $action = $in['action'] ?? 'save';
    if ($action === 'delete') {
        $email = strtolower(trim($in['email'] ?? ''));
        $pdo->prepare("DELETE FROM `users` WHERE LOWER(`email`) = ?")->execute([$email]);
        $rows = $pdo->query("SELECT * FROM `users` ORDER BY `id` DESC")->fetchAll();
        decorly_json(['ok' => true, 'customers' => array_map('map_cust', $rows)]);
    }
    $name = trim($in['name'] ?? 'DECORLY Customer');
    $parts = explode(' ', $name, 2);
    $first = $parts[0] ?? 'Customer';
    $last = $parts[1] ?? '';
    $email = strtolower(trim($in['email'] ?? ''));
    $phone = trim($in['phone'] ?? '');
    $city = trim($in['city'] ?? 'Pakistan');
    $type = trim($in['type'] ?? 'Returning');
    $spent = (float)($in['spent'] ?? 0);
    $orders = (int)($in['orders'] ?? 1);
    $hash = password_hash('Customer@2026', PASSWORD_DEFAULT);

    $stmt = $pdo->prepare("INSERT INTO `users` (`first_name`, `last_name`, `full_name`, `email`, `phone`, `city`, `password_hash`, `password_plain`, `customer_type`, `orders_count`, `total_spent`)
        VALUES (?, ?, ?, ?, ?, ?, ?, 'Customer@2026', ?, ?, ?)
        ON DUPLICATE KEY UPDATE `first_name`=VALUES(`first_name`), `last_name`=VALUES(`last_name`), `full_name`=VALUES(`full_name`), `phone`=VALUES(`phone`), `city`=VALUES(`city`), `customer_type`=VALUES(`customer_type`), `total_spent`=VALUES(`total_spent`)");
    $stmt->execute([$first, $last, $name, $email, $phone, $city, $hash, $type, $orders, $spent]);

    $rows = $pdo->query("SELECT * FROM `users` ORDER BY `id` DESC")->fetchAll();
    decorly_json(['ok' => true, 'customers' => array_map('map_cust', $rows)]);
}
