<?php
require_once __DIR__ . '/db.php';

$msg = '';
$err = '';
$tableStats = [];
$credFile = __DIR__ . '/api/db-credentials.php';

$currHost = defined('DB_HOST') ? DB_HOST : 'localhost';
$currPort = defined('DB_PORT') ? DB_PORT : '3306';
$currName = defined('DB_NAME') ? DB_NAME : 'decorly_db';
$currUser = defined('DB_USER') ? DB_USER : 'decorly_user';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $host = trim($_POST['db_host'] ?? 'localhost');
    $port = trim($_POST['db_port'] ?? '3306');
    $name = trim($_POST['db_name'] ?? 'decorly_db');
    $user = trim($_POST['db_user'] ?? 'decorly_user');
    $pass = $_POST['db_pass'] ?? '';

    $currHost = $host;
    $currPort = $port;
    $currName = $name;
    $currUser = $user;

    try {
        try {
            $dsn = "mysql:host={$host};port={$port};dbname={$name};charset=utf8mb4";
            $pdo = new PDO($dsn, $user, $pass, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false
            ]);
        } catch (PDOException $ex) {
            if (strpos($ex->getMessage(), 'Unknown database') !== false) {
                $rootDsn = "mysql:host={$host};port={$port};charset=utf8mb4";
                $rootPdo = new PDO($rootDsn, $user, $pass, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
                $safeDb = preg_replace('/[^a-zA-Z0-9_]/', '', $name);
                $rootPdo->exec("CREATE DATABASE IF NOT EXISTS `{$safeDb}` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
                $dsn = "mysql:host={$host};port={$port};dbname={$name};charset=utf8mb4";
                $pdo = new PDO($dsn, $user, $pass, [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES => false
                ]);
            } else {
                throw $ex;
            }
        }

        if (!is_dir(__DIR__ . '/api')) {
            @mkdir(__DIR__ . '/api', 0755, true);
        }
        $phpCred = "<?php\n"
            . "if (!defined('DB_HOST')) define('DB_HOST', " . var_export($host, true) . ");\n"
            . "if (!defined('DB_PORT')) define('DB_PORT', " . var_export($port, true) . ");\n"
            . "if (!defined('DB_NAME')) define('DB_NAME', " . var_export($name, true) . ");\n"
            . "if (!defined('DB_USER')) define('DB_USER', " . var_export($user, true) . ");\n"
            . "if (!defined('DB_PASS')) define('DB_PASS', " . var_export($pass, true) . ");\n";
        file_put_contents($credFile, $phpCred);

        $sqlFile = __DIR__ . '/database/decorly_complete_database.sql';
        $res = decorly_execute_sql_file($pdo, $sqlFile);

        $expectedTables = [
            'admins', 'users', 'user_addresses', 'categories', 'products',
            'orders', 'order_items', 'coupons', 'reviews', 'enquiries',
            'banners', 'blog_posts', 'store_settings'
        ];
        foreach ($expectedTables as $tb) {
            try {
                $cnt = (int)$pdo->query("SELECT COUNT(*) FROM `{$tb}`")->fetchColumn();
                $tableStats[$tb] = $cnt;
            } catch (Exception $te) {
                $tableStats[$tb] = 'Missing';
            }
        }

        $msg = "Database connected and all 13 MySQL tables + 36 products + 9 categories are created and active.";
    } catch (Exception $e) {
        $err = 'Database connection failed: ' . $e->getMessage();
    }
} else {
    $existingPdo = decorly_db(true, true);
    if ($existingPdo) {
        $expectedTables = [
            'admins', 'users', 'user_addresses', 'categories', 'products',
            'orders', 'order_items', 'coupons', 'reviews', 'enquiries',
            'banners', 'blog_posts', 'store_settings'
        ];
        foreach ($expectedTables as $tb) {
            try {
                $tableStats[$tb] = (int)$existingPdo->query("SELECT COUNT(*) FROM `{$tb}`")->fetchColumn();
            } catch (Exception $te) {}
        }
    }
}
?><!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>DECORLY — Production MySQL Database Setup</title>
<link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;700&family=Manrope:wght@700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/css/setup.css">
</head>
<body>
<div class="card">
  <span class="eyebrow">DECORLY PRODUCTION INSTALLER</span>
  <h1>MySQL Database &amp; 13 Tables Setup</h1>
  <p>Enter your Hostinger MySQL Database details below (from <strong>hPanel &rarr; Databases &rarr; Management</strong>) to connect the website and automatically create all 13 tables, 9 categories, and 36 products.</p>
  <?php if ($msg): ?><div class="alert ok"><?php echo htmlspecialchars($msg); ?></div><?php endif; ?>
  <?php if ($err): ?><div class="alert err"><?php echo htmlspecialchars($err); ?></div><?php endif; ?>
  <form method="post">
    <div class="row">
      <div class="field"><label>MySQL Host</label><input name="db_host" value="<?php echo htmlspecialchars($currHost); ?>" required></div>
      <div class="field"><label>Port</label><input name="db_port" value="<?php echo htmlspecialchars($currPort); ?>" required></div>
    </div>
    <div class="field"><label>MySQL Database Name (e.g. u123456789_decorly_db)</label><input name="db_name" value="<?php echo htmlspecialchars($currName); ?>" placeholder="u123456789_decorly_db" required></div>
    <div class="field"><label>MySQL Username (e.g. u123456789_decorly_user)</label><input name="db_user" value="<?php echo htmlspecialchars($currUser); ?>" placeholder="u123456789_decorly_user" required></div>
    <div class="field"><label>MySQL Password</label><input type="password" name="db_pass" placeholder="Enter your MySQL password"></div>
    <button type="submit">Connect &amp; Auto-Create All 13 Tables + 36 Products &rarr;</button>
  </form>

  <?php if (!empty($tableStats)): ?>
  <h3 class="setup-subhead">Live MySQL Database Tables Verification (13 Tables):</h3>
  <table class="tbl">
    <thead><tr><th>MySQL Table Name</th><th>Status</th><th>Records in Database</th></tr></thead>
    <tbody>
      <?php foreach ($tableStats as $tbName => $rowCount): ?>
      <tr>
        <td><code><?php echo htmlspecialchars($tbName); ?></code></td>
        <td class="status-active">&#10003; Active</td>
        <td><strong><?php echo htmlspecialchars((string)$rowCount); ?> rows</strong></td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
  <?php endif; ?>

  <div class="links">
    <a href="index.php">&#8599; Open Storefront (index.php)</a>
    <a href="admin/index.php">&#8599; Open Admin Login (admin/index.php)</a>
    <a href="admin/dashboard.php">&#8599; Open Admin Dashboard (admin/dashboard.php)</a>
  </div>
</div>
</body>
</html>
