<?php require_once __DIR__ . '/db.php'; ?>
<!DOCTYPE html>

<html lang="en"><head><meta charset="utf-8"/><meta content="width=device-width,initial-scale=1" name="viewport"/><meta content="#102346" name="theme-color"/><title>Checkout | DECORLY</title><meta content="Shipping and payment checkout design." name="description"/><link href="https://fonts.googleapis.com" rel="preconnect"/><link crossorigin="" href="https://fonts.gstatic.com" rel="preconnect"/><link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700;800&amp;family=Manrope:wght@400;500;600;700;800&amp;display=swap" rel="stylesheet"/>







  <link rel="stylesheet" href="assets/css/global.css">
  <link rel="stylesheet" href="assets/css/checkout.css">
  <script src="api/bootstrap-js.php"></script>
</head><body class="decorly-unified" data-page="checkout">
<!-- DECORLY Luxury Preloader -->
<div id="decorly-preloader" role="status" aria-live="polite" aria-label="Loading DECORLY">
  <div class="dl-ambient"></div>
  <div class="dl-emblem-wrap">
    <div class="dl-ring-outer"></div>
    <div class="dl-ring-inner"></div>
    <div class="dl-core"><span>D</span></div>
  </div>
  <div class="dl-brand">DECOR<b>LY</b></div>
  <div class="dl-tag">CURATING INSPIRED LIVING</div>
  <div class="dl-track"><div class="dl-bar" id="decorlyLoaderBar"></div></div>
  <div class="dl-pct" id="decorlyLoaderPct">0%</div>
</div>


<header class="nv decorly-site-header" id="hd"><a aria-label="DECORLY Home" class="lg" href="./"><img alt="DECORLY" height="34" src="assets/decorly-logo-light.png" width="169"/></a>
<nav class="lk"><a href="./">Home</a><a href="shop">Shop</a><div class="decorly-cat-nav" id="decorlyCatNav"><a aria-expanded="false" aria-haspopup="true" class="decorly-cat-trigger" href="categories">Categories <span aria-hidden="true">⌄</span></a><div class="decorly-cat-menu"><div class="decorly-cat-group"><a class="decorly-cat-parent" href="categories?group=tables">Tables <span>›</span></a><div class="decorly-cat-sub"><a href="category?slug=nesting-tables">Nesting Tables</a><a href="category?slug=tea-tables">Tea Tables</a><a href="category?slug=console-tables">Console Tables</a><a href="category?slug=dining-tables">Dining Tables</a><a href="category?slug=coffee-tables">Coffee Tables</a><a href="category?slug=laptop-tables">Laptop Tables</a></div></div><div class="decorly-cat-group"><a class="decorly-cat-parent" href="categories?group=racks">Racks <span>›</span></a><div class="decorly-cat-sub"><a href="category?slug=kitchen-oven-racks">Kitchen Oven Racks</a><a href="category?slug=corner-racks">Corner Racks</a></div></div><div class="decorly-cat-group"><a class="decorly-cat-parent" href="categories?group=trolleys">Trolleys <span>›</span></a><div class="decorly-cat-sub"><a href="category?slug=tea-trolleys">Tea Trolleys</a></div></div><a class="decorly-all-cat" href="categories">Explore All Categories ↗</a></div></div><a href="about">About Us</a><a href="blog">Blog</a><a href="contact">Contact</a></nav>
<form action="search" class="sf" id="searchForm" method="get"><input aria-label="Search products" id="search" name="q" placeholder="Search..." type="search"/></form>
<div class="qk"><a aria-label="Wishlist" href="wishlist" title="Wishlist">♡</a><a aria-label="Cart" href="cart" title="Cart">🛒<i id="cartCount">0</i></a></div>
 <?php $__isLogged = !empty($_SESSION['decorly_user']); ?><a aria-label="Sign In or My Account" class="decorly-header-signin-btn<?php echo $__isLogged ? ' is-signed-in' : ''; ?>" id="headerSignInBtn" href="<?php echo $__isLogged ? 'my-account' : 'login'; ?>"><?php echo $__isLogged ? 'My Account' : 'Sign In'; ?></a>
<a class="gb nb" href="shop">Shop Furniture</a><button aria-label="Menu" class="mb" id="mbtn">☰</button></header><nav class="mm decorly-site-mobile" id="mm"><a href="./">Home</a><a href="shop">Shop All Products</a><a href="categories">All Categories</a><details><summary>Tables</summary><a href="category?slug=nesting-tables">Nesting Tables</a><a href="category?slug=tea-tables">Tea Tables</a><a href="category?slug=console-tables">Console Tables</a><a href="category?slug=dining-tables">Dining Tables</a><a href="category?slug=coffee-tables">Coffee Tables</a><a href="category?slug=laptop-tables">Laptop Tables</a></details><details><summary>Racks</summary><a href="category?slug=kitchen-oven-racks">Kitchen Oven Racks</a><a href="category?slug=corner-racks">Corner Racks</a></details><details><summary>Trolleys</summary><a href="category?slug=tea-trolleys">Tea Trolleys</a></details><a href="about">About Us</a><a href="blog">Blog</a><a href="contact">Contact Us</a><a href="wishlist">Wishlist</a><a href="cart">Cart</a><a href="login">Sign In</a><a href="signup">Create Account</a><a href="faq">Help &amp; FAQ</a><form action="search" method="get" class="d-u-checkout-1"><input name="q" placeholder="Search furniture..." type="search" class="d-u-checkout-2"/></form></nav><main>
<section class="flow-hero">
  <div class="container">
    <div class="crumbs"><a href="./">Home</a> &nbsp;/&nbsp; <a href="cart">Cart</a> &nbsp;/&nbsp; Checkout</div>
    <span class="kicker">DECORLY / SECURE CHECKOUT</span>
    <h1>Checkout</h1>
    <p>Complete your delivery details and choose your preferred payment method below.</p>
  </div>
</section>
<section class="flow-section">
  <div class="container">
    <div class="stepbar"><a href="cart">01 Shopping bag</a><span class="active">02 Delivery &amp; Payment</span><span>03 Order Confirmation</span></div>
    <div class="flow-grid">
      <form class="flow-panel" id="checkoutForm">
        <h2>01. Delivery Information</h2>
        <div class="fields-2">
          <div class="field"><label for="first">First name *</label><input autocomplete="given-name" id="first" name="first" placeholder="First name" required/></div>
          <div class="field"><label for="last">Last name *</label><input autocomplete="family-name" id="last" name="last" placeholder="Last name" required/></div>
        </div>
        <div class="fields-2">
          <div class="field"><label for="email">Email address *</label><input autocomplete="email" id="email" name="email" placeholder="you@example.com" required type="email"/></div>
          <div class="field"><label for="phone">Mobile phone (for courier call) *</label><input autocomplete="tel" id="phone" name="phone" placeholder="+92 300 1234567" required type="tel"/></div>
        </div>
        <div class="field"><label for="address">Street address / House &amp; Sector *</label><input autocomplete="street-address" id="address" name="address" placeholder="House #, Street, Area / Phase" required/></div>
        <div class="fields-2">
          <div class="field"><label for="city">City *</label><input autocomplete="address-level2" id="city" name="city" placeholder="e.g. Multan, Lahore, Karachi, Islamabad" required/></div>
          <div class="field">
            <label for="province">Province / Region *</label>
            <select id="province" name="province" required>
              <option value="Punjab">Punjab</option>
              <option value="Sindh">Sindh</option>
              <option value="Islamabad Capital Territory">Islamabad Capital Territory</option>
              <option value="Khyber Pakhtunkhwa">Khyber Pakhtunkhwa</option>
              <option value="Balochistan">Balochistan</option>
              <option value="Gilgit-Baltistan">Gilgit-Baltistan</option>
              <option value="Azad Jammu & Kashmir">Azad Jammu &amp; Kashmir</option>
            </select>
          </div>
        </div>
        <div class="fields-2">
          <div class="field"><label for="postcode">Postal code (Optional)</label><input autocomplete="postal-code" id="postcode" name="postcode" placeholder="e.g. 60000 / 54000"/></div>
          <div class="field"><label for="orderNotes">Delivery instructions (Optional)</label><input id="orderNotes" name="orderNotes" placeholder="Landmark, preferred delivery timing..."/></div>
        </div>

        <h3 class="d-u-checkout-3">02. Select Payment Method</h3>
        <div id="paymentMethodsBox" class="d-u-checkout-4">
          <label class="d-u-checkout-5">
            <input type="radio" name="paymentMethod" value="Cash on Delivery (COD)" checked class="d-u-checkout-6"/>
            <div>
              <strong class="d-u-checkout-7">💵 Cash on Delivery (COD)</strong>
              <span class="d-u-checkout-8">Pay in cash at your doorstep when your DECORLY furniture arrives.</span>
            </div>
          </label>
          <label class="d-u-checkout-9">
            <input type="radio" name="paymentMethod" value="Bank Transfer (IBAN)" class="d-u-checkout-6"/>
            <div>
              <strong class="d-u-checkout-7">🏦 Direct Bank Transfer (IBAN)</strong>
              <span class="d-u-checkout-8">DECORLY FURNITURE STUDIO · IBAN: <code>PK36 MEZN 0001 2345 6789 0102</code></span>
            </div>
          </label>
          <label class="d-u-checkout-9">
            <input type="radio" name="paymentMethod" value="JazzCash / EasyPaisa" class="d-u-checkout-6"/>
            <div>
              <strong class="d-u-checkout-7">📱 JazzCash / EasyPaisa Mobile Wallet</strong>
              <span class="d-u-checkout-8">Official Merchant Account: <code>+92 300 8429000</code></span>
            </div>
          </label>
        </div>

        <label class="checkrow"><input required type="checkbox" checked/> <span>I confirm my delivery address and phone number are accurate for order dispatch.</span></label>
        <div class="d-u-checkout-10"></div>
        <button class="flow-btn gold full" id="placeOrder" type="submit">Place Order Now ↗</button>
        <p class="notice" hidden id="checkoutMessage" role="status" tabindex="-1"></p>
      </form>
      <aside class="flow-panel" id="checkoutSidebar"></aside>
    </div>
  </div>
</section>
</main>
<footer aria-label="DECORLY website footer" class="decorly-final-footer decorly-luxe-footer" id="siteFooter">
<div class="lf-top"><div class="lf-grid">
<section aria-label="DECORLY brand" class="lf-brand"><a aria-label="DECORLY homepage" class="lf-logo" href="./"><img alt="DECORLY" loading="lazy" src="assets/decorly-logo-light.png"/></a><p>Furniture for inspired living. Discover contemporary tables, trolleys and thoughtful storage for your space.</p><a class="lf-cta" href="shop">Explore furniture <span aria-hidden="true">→</span></a></section>
<nav aria-label="Explore" class="lf-links"><div aria-hidden="true" class="lf-icon">⌂</div><h3>Explore</h3><a href="./">Home <span>›</span></a><a href="shop">Shop furniture <span>›</span></a><a href="categories">All categories <span>›</span></a><a href="about">About us <span>›</span></a><a href="contact">Contact us <span>›</span></a></nav>
<nav aria-label="Collections" class="lf-links"><div aria-hidden="true" class="lf-icon">▱</div><h3>Collections</h3><a href="category?slug=coffee-tables">Coffee tables <span>›</span></a><a href="category?slug=nesting-tables">Nesting tables <span>›</span></a><a href="category?slug=tea-trolleys">Tea trolleys <span>›</span></a><a href="category?slug=corner-racks">Corner racks <span>›</span></a></nav>
<nav aria-label="Help and contact" class="lf-links"><div aria-hidden="true" class="lf-icon">♧</div><h3>Help &amp; Contact</h3><a href="faq">Help &amp; FAQs <span>›</span></a><a href="shipping-policy">Shipping policy <span>›</span></a><a href="return-refund-policy">Returns &amp; refunds <span>›</span></a><a href="privacy-policy">Privacy policy <span>›</span></a><a href="terms-conditions">Terms &amp; conditions <span>›</span></a></nav>
<section aria-label="Contact details" class="lf-contact"><h3>Get in touch</h3><p class="lf-intro">Have a question? We're here to help.</p><div class="lf-method"><span aria-hidden="true" class="lf-round">✉</span><div><small>Official Support Email</small><a href="mailto:support@decorly.pk">support@decorly.pk</a></div></div><div class="lf-method"><span aria-hidden="true" class="lf-round">☎</span><div><small>Customer Care Helpline</small><a href="tel:+923008429000">+92 300 8429000</a></div></div><div class="lf-method"><span aria-hidden="true" class="lf-round">⌖</span><div><small>Studio / location</small><span>Industrial Estate &amp; Design Studio, Multan / Lahore, Pakistan</span></div></div><div class="lf-social"><p>Follow us</p><div aria-label="DECORLY official social channels"><span aria-label="DECORLY on Instagram">◎</span><span aria-label="DECORLY on Facebook">f</span><span aria-label="DECORLY on Pinterest">p</span><span aria-label="DECORLY on YouTube">▶</span><span aria-label="DECORLY on LinkedIn">in</span></div></div></section>
</div></div><div class="lf-bottom"><div class="lf-bottom-inner"><p>© 2026 DECORLY. All rights reserved.</p><div class="lf-perks"><div><b aria-hidden="true">♧</b><span>Shipping details<small>See shipping policy</small></span></div><div><b aria-hidden="true">♢</b><span>Returns &amp; refunds<small>View our policy</small></span></div><div><b aria-hidden="true">⬡</b><span>Checkout experience<small>Payment options at checkout</small></span></div></div><p class="lf-note">A more inspired home<br/>for a brighter tomorrow.</p></div></div>
</footer>
<script src="assets/js/checkout.js"></script>
<script src="assets/js/decorly-shopping.js"></script>
</body></html>